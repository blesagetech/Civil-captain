# Civil Captain

**Attendance for government offices without fingerprint machines.**

Staff check in with the phone they already own. A screen at reception shows a QR code that changes every few minutes, so a photo of it is useless. Supervisors see who is in, HR sees who is below the 75% minimum, and nobody has to buy, ship or repair biometric hardware.

The idea comes from how a university can run attendance for thousands of students: a rotating QR code for people who are physically present, time tracking for people attending online, a visible attendance percentage, and a 75% rule that is enforced. Civil Captain applies the same ideas to government staff.

## What is inside

| For | What it does |
|---|---|
| **Staff** | Check in by scanning the reception QR (or typing a 6-digit code), check out, see attendance % against the 75% minimum and exactly how many more days are needed, request leave, correct a missed day, join online sessions. |
| **Supervisors** | See today's team (in, late, absent, on leave), review check-ins that broke an office rule, approve leave and corrections, approve new phones, show the reception screen. |
| **HR administrators** | Manage people (add, import from a spreadsheet, reset passwords), set up offices and their rules, download reports and a payroll-eligibility list, read the activity log. |
| **National administrator** | Add ministries and agencies, set public holidays and the national minimum. |
| **Honesty checks** | Rotating code, one phone per person, optional location and office-network rules. Anything suspicious is flagged for a supervisor instead of silently accepted. |
| **Online time** | Remote duty, meetings and training are tracked by time attended, like online classes. |

More detail: [`docs/HOW_IT_WORKS.md`](docs/HOW_IT_WORKS.md).

## Try it in about 5 minutes (GitHub Codespaces)

You already have a Codespace on your `civil-captain-2` repository. In it:

1. **Upload the zip.** Drag `civil-captain.zip` into the file list on the left of your Codespace (or right-click an empty area, choose *Upload*).
2. **Open the terminal** (menu *Terminal > New Terminal*) and run:
   ```bash
   unzip -o civil-captain.zip && rm civil-captain.zip
   pip install -r requirements.txt
   python run.py --demo
   ```
3. A pop-up says the app is running on port 8000. Click **Open in Browser**.
4. **Let phones open it.** In the **Ports** tab at the bottom, right-click port **8000**, choose *Port Visibility* then *Public*. Without this, a phone that is not signed in to GitHub cannot open the QR link.
5. Sign in. The login page shows one-tap demo accounts (every demo account uses the password `Civil2026`).

To keep your work, run `git add . && git commit -m "Civil Captain" && git push` in the terminal.

### A 5-minute demo you can show

1. Sign in as **Supervisor, MICT headquarters** on a laptop. Open **Screen > Show the screen**. The QR code and the 6-digit code are on the screen and count down.
2. On your phone, sign in as **Employee, MICT headquarters**. Scan the QR with the camera app. Tap **Confirm check-in**. The supervisor's *Team* page now shows the person as in.
3. Sign in as **Employee, Mbarara office** and check in from anywhere. The Mbarara office has the location rule switched on, so the check-in is sent to the supervisor for review. To see it, sign in as `sup.mbarara` (type that username, same demo password) or as HR (`hr.mict`) and open **Review**.
4. As the supervisor, open **Review** and accept or reject the flagged check-ins and the leave request. Watch the person's percentage change.
5. As HR (`hr.mict`), open **More > Reports and downloads** and download the *payroll eligibility* list. Open **Offices** and change the rules for an office.
6. The demo data uses fictional people. For real use, start **without** `--demo` (see below).

> The demo data is created relative to the day you first start the app. If you want fresh demo data, stop the app and delete `data/civilcaptain.db`.

## Starting for real use

```bash
python run.py
```

On first start the app creates one national administrator account and prints the password **once** in the terminal. Sign in, choose a new password, then add your ministries, offices and people. For a real deployment on the internet read [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) first, and walk through [`docs/GO_LIVE_CHECKLIST.md`](docs/GO_LIVE_CHECKLIST.md) before real staff use it.

## Run the automated tests

```bash
python -m unittest discover -s tests
```

49 tests cover the QR generator (decoded with a real QR reader when OpenCV is installed), the attendance maths, check-in rules, who can see whom, leave, corrections, online sessions, reports and security behaviour. They take about a minute because passwords are hashed slowly on purpose.

## Folder map

```
run.py              start the app (python run.py --demo)
wsgi.py             entry point for production servers (gunicorn wsgi:app)
manage.py           admin tools: reset a password, back up the database
app/                the server (Python + Flask + SQLite)
  calc.py           attendance maths, no database (easy to read and test)
  codes.py          the rotating QR/6-digit code
  qrmatrix.py       a small QR code generator, no extra libraries
  logic.py          check-in rules, summaries, leave, online sessions
  api/              the web API, split by who uses it
static/             the web app (plain HTML, CSS and JavaScript, no build step)
tests/              automated tests
docs/               how it works, deployment, go-live checklist, security and privacy, user guide, project brief
Dockerfile, docker-compose.yml, Procfile, .env.example     deployment files
```

## Good to know

- **Python 3.10 or newer.** The only libraries are Flask (and gunicorn for production).
- **Database:** one SQLite file in `data/`. It is fast enough for a pilot of several thousand staff. For a national roll-out plan to move to PostgreSQL (see the deployment guide).
- **No biometric data and no tracking.** Location is read once at check-in or check-out, only for offices that turn the location rule on, and is never tracked in between.
- **It is not magic.** No software-only system can stop every cheat. The honest list of limits is in [`docs/HOW_IT_WORKS.md`](docs/HOW_IT_WORKS.md#what-it-cannot-do).
