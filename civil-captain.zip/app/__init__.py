"""Civil Captain: attendance for government offices without biometric hardware."""
import logging
from pathlib import Path

from flask import Flask, jsonify, request, send_file, send_from_directory
from werkzeug.exceptions import HTTPException

from .config import Config
from .db import close_db, init_db, q1
from .security import ApiError

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
ASSET_EXT = {".js", ".css", ".svg", ".png", ".ico", ".webmanifest", ".txt"}


def create_app(**overrides):
    cfg = Config(**overrides)
    app = Flask(__name__, static_folder=None)
    app.config["CC"] = cfg
    app.json.sort_keys = False
    init_db(cfg.DB_PATH)
    app.teardown_appcontext(close_db)

    from .api import bp
    app.register_blueprint(bp)

    @app.errorhandler(ApiError)
    def api_error(e):
        return jsonify({"error": e.message, **e.extra}), e.status

    @app.errorhandler(HTTPException)
    def http_error(e):
        if request.path.startswith("/api/"):
            return jsonify(error=e.description or e.name), e.code
        return e

    @app.errorhandler(Exception)
    def crash(e):
        app.logger.exception("Unhandled error")
        return jsonify(error="Something went wrong on our side. Try again in a moment."), 500

    def page(**_kw):
        resp = send_file(STATIC_DIR / "index.html", max_age=0)
        resp.headers["Cache-Control"] = "no-cache"
        return resp

    app.add_url_rule("/", "home_page", page)
    app.add_url_rule("/display", "display_page", page)
    app.add_url_rule("/c/<path:token>", "scan_page", page)

    @app.get("/healthz")
    def healthz():
        q1("SELECT 1 AS ok")
        return jsonify(status="ok")

    @app.get("/<path:name>")
    def assets(name):
        if name.startswith("api/") or Path(name).suffix.lower() not in ASSET_EXT:
            return jsonify(error="Not found."), 404
        resp = send_from_directory(STATIC_DIR, name)
        resp.headers["Cache-Control"] = "no-cache"
        return resp

    @app.after_request
    def secure(resp):
        h = resp.headers
        h["X-Content-Type-Options"] = "nosniff"
        h["X-Frame-Options"] = "DENY"
        h["Referrer-Policy"] = "no-referrer"
        h["Permissions-Policy"] = "geolocation=(self), camera=(self), microphone=()"
        h["Content-Security-Policy"] = ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                                        "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; "
                                        "form-action 'self'")
        if request.path.startswith("/api/"):
            h["Cache-Control"] = "no-store"
        if cfg.COOKIE_SECURE:
            h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return resp

    with app.app_context():
        bootstrap(cfg)
    if not app.debug and not cfg.TESTING:
        logging.getLogger("werkzeug").setLevel(logging.WARNING)
    return app


def bootstrap(cfg):
    """First run: create the national admin (or the demo data) when the database is empty."""
    from .seed import create_first_admin, seed_demo
    if q1("SELECT COUNT(*) AS c FROM users")["c"] == 0:
        if cfg.DEMO:
            seed_demo()
        else:
            create_first_admin(cfg)
