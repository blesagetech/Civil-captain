from flask import Blueprint

bp = Blueprint("api", __name__, url_prefix="/api")

from . import auth, staff, team, admin, online, reports  # noqa: E402,F401
