import csv
import io
import re

from flask import g, jsonify, request

from . import bp
from .. import calc, clock, codes, logic
from ..db import q, q1, run
from ..security import (ApiError, audit, auth, body, choice, client_ip, day_text, hash_password, integer, number,
                        org_allowed, team_scope, temp_password, text)
from .team import MANAGERS

ADMINS = ("org_admin", "super_admin")
ROLES = ("employee", "supervisor", "org_admin", "super_admin")
POLICIES = ("off", "flag", "block")
USERNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._@-]{2,59}$")


def opt_int(d, key, label):
    v = d.get(key)
    if v in (None, "", 0, "0"):
        return None
    return integer(d, key, label, 1)


# ------------------------------------------------------------------ organisations
@bp.get("/orgs")
@auth(*MANAGERS)
def orgs_list():
    if g.user["role"] == "super_admin":
        return jsonify(orgs=q("SELECT * FROM orgs ORDER BY name"))
    return jsonify(orgs=q("SELECT * FROM orgs WHERE id=?", (g.user["org_id"],)))


@bp.post("/orgs")
@auth("super_admin")
def orgs_create():
    d = body()
    name, code = text(d, "name", "Name", 120), text(d, "code", "Short code", 20).upper()
    if not re.fullmatch(r"[A-Z0-9_-]{2,20}", code):
        raise ApiError("The short code can use letters, numbers, - and _ only (2 to 20 characters).")
    if q1("SELECT 1 AS x FROM orgs WHERE name=? OR code=?", (name, code)):
        raise ApiError("An organisation with that name or code already exists.")
    oid = run("INSERT INTO orgs(name,code,created_at) VALUES (?,?,?)", (name, code, clock.now()))
    audit("org_created", name)
    return jsonify(ok=True, id=oid), 201


@bp.put("/orgs/<int:oid>")
@auth("super_admin")
def orgs_update(oid):
    d = body()
    if not q1("SELECT 1 AS x FROM orgs WHERE id=?", (oid,)):
        raise ApiError("Organisation not found.", 404)
    name = text(d, "name", "Name", 120)
    if q1("SELECT 1 AS x FROM orgs WHERE name=? AND id<>?", (name, oid)):
        raise ApiError("Another organisation already has that name.")
    run("UPDATE orgs SET name=? WHERE id=?", (name, oid))
    audit("org_updated", name)
    return jsonify(ok=True)


# ------------------------------------------------------------------ offices (stations)
def station_json(st, full):
    out = {k: st[k] for k in ("id", "org_id", "name", "district", "active")}
    if full:
        out.update({k: st[k] for k in ("work_start", "work_end", "grace_min", "work_days", "qr_interval", "lat", "lng",
                                       "radius_m", "allowed_cidrs", "ip_policy", "geo_policy", "device_policy", "display_key")})
    return out


def clean_station(d):
    name = text(d, "name", "Office name", 100)
    ws, we = text(d, "work_start", "Start time", 5, default="08:00"), text(d, "work_end", "Finish time", 5, default="17:00")
    if not (clock.valid_hhmm(ws) and clock.valid_hhmm(we)):
        raise ApiError("Times must look like 08:00.")
    if clock.hm_to_min(we) <= clock.hm_to_min(ws):
        raise ApiError("Finish time must be after start time.")
    wd = d.get("work_days", [1, 2, 3, 4, 5])
    if isinstance(wd, str):
        wd = [x for x in wd.split(",") if x.strip()]
    try:
        wd = sorted({int(x) for x in wd})
    except (TypeError, ValueError):
        raise ApiError("Working days are not valid.")
    if not wd or any(x < 1 or x > 7 for x in wd):
        raise ApiError("Choose at least one working day.")
    lat, lng = number(d, "lat", "Latitude", -90, 90), number(d, "lng", "Longitude", -180, 180)
    if (lat is None) != (lng is None):
        raise ApiError("Enter both latitude and longitude, or leave both empty.")
    cidrs = text(d, "allowed_cidrs", "Network addresses", 500, required=False)
    logic.parse_cidrs(cidrs)
    f = {"name": name, "district": text(d, "district", "District", 60, required=False), "work_start": ws, "work_end": we,
         "grace_min": integer(d, "grace_min", "Grace period", 0, 120, default=15), "work_days": ",".join(map(str, wd)),
         "qr_interval": integer(d, "qr_interval", "Code rotation (seconds)", 30, 900, default=300), "lat": lat, "lng": lng,
         "radius_m": integer(d, "radius_m", "Office radius (metres)", 20, 5000, default=150), "allowed_cidrs": cidrs,
         "ip_policy": choice(d, "ip_policy", "Network rule", POLICIES, "off"),
         "geo_policy": choice(d, "geo_policy", "Location rule", POLICIES, "off"),
         "device_policy": choice(d, "device_policy", "Phone rule", POLICIES, "flag")}
    if f["geo_policy"] != "off" and lat is None:
        raise ApiError("Add the office latitude and longitude to use location checks.")
    if f["ip_policy"] != "off" and not cidrs:
        raise ApiError("Add the office network addresses to use network checks.")
    return f


@bp.get("/stations")
@auth(*MANAGERS)
def stations_list():
    me = g.user
    org = request.args.get("org_id", "")
    if me["role"] == "super_admin":
        rows = q("SELECT * FROM stations WHERE (?='' OR org_id=?) ORDER BY name", (org, org if org.isdigit() else -1))
    else:
        rows = q("SELECT * FROM stations WHERE org_id=? ORDER BY name", (me["org_id"],))
    return jsonify(stations=[station_json(s, me["role"] in ADMINS) for s in rows])


@bp.post("/stations")
@auth(*ADMINS)
def stations_create():
    d, me = body(), g.user
    org_id = me["org_id"] if me["role"] != "super_admin" else integer(d, "org_id", "Organisation", 1)
    if not q1("SELECT 1 AS x FROM orgs WHERE id=?", (org_id,)):
        raise ApiError("Organisation not found.", 404)
    f = clean_station(d)
    if q1("SELECT 1 AS x FROM stations WHERE org_id=? AND name=?", (org_id, f["name"])):
        raise ApiError("This organisation already has an office with that name.")
    cols = list(f)
    sid = run(f"INSERT INTO stations(org_id,{','.join(cols)},qr_secret,display_key,created_at) VALUES (?,{','.join('?' * len(cols))},?,?,?)",
              (org_id, *[f[c] for c in cols], codes.new_secret(), codes.new_display_key(), clock.now()))
    audit("station_created", f["name"])
    return jsonify(ok=True, id=sid), 201


@bp.put("/stations/<int:sid>")
@auth(*ADMINS)
def stations_update(sid):
    st = q1("SELECT * FROM stations WHERE id=?", (sid,))
    if not st or not org_allowed(g.user, st["org_id"]):
        raise ApiError("Office not found.", 404)
    d = body()
    f = clean_station(d)
    if q1("SELECT 1 AS x FROM stations WHERE org_id=? AND name=? AND id<>?", (st["org_id"], f["name"], sid)):
        raise ApiError("This organisation already has an office with that name.")
    active = 1 if d.get("active", True) else 0
    cols = list(f)
    run(f"UPDATE stations SET {','.join(c + '=?' for c in cols)}, active=? WHERE id=?", (*[f[c] for c in cols], active, sid))
    audit("station_updated", f["name"], f"active={active}")
    return jsonify(ok=True)


@bp.post("/stations/<int:sid>/rotate-key")
@auth(*ADMINS)
def stations_rotate(sid):
    st = q1("SELECT * FROM stations WHERE id=?", (sid,))
    if not st or not org_allowed(g.user, st["org_id"]):
        raise ApiError("Office not found.", 404)
    run("UPDATE stations SET display_key=?, qr_secret=? WHERE id=?", (codes.new_display_key(), codes.new_secret(), sid))
    audit("station_key_rotated", st["name"])
    return jsonify(ok=True)


@bp.get("/stations/<int:sid>/code")
@auth(*MANAGERS)
def station_code(sid):
    st = q1("SELECT * FROM stations WHERE id=? AND active=1", (sid,))
    if not st or not org_allowed(g.user, st["org_id"]):
        raise ApiError("Office not found.", 404)
    return jsonify(codes.payload(st, clock.now()))


@bp.get("/my-ip")
@auth(*ADMINS)
def my_ip():
    return jsonify(ip=client_ip())


@bp.get("/display")
def display_by_key():
    st = q1("SELECT * FROM stations WHERE display_key=? AND active=1", (request.args.get("key", ""),))
    if not st:
        raise ApiError("This display link is not valid any more. Ask your administrator for a new one.", 404)
    return jsonify(codes.payload(st, clock.now()))


# ------------------------------------------------------------------ people
def target_user(me, uid):
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    if not u or (me["role"] != "super_admin" and (u["org_id"] != me["org_id"] or u["role"] == "super_admin")):
        raise ApiError("Person not found.", 404)
    return u


def clean_user(d, me, existing=None):
    assignable = ROLES if me["role"] == "super_admin" else ROLES[:3]
    if existing:
        username = existing["username"]
    else:
        username = text(d, "username", "Username", 60)
        if not USERNAME_RE.match(username):
            raise ApiError("Username: 3 to 60 characters; letters, numbers and . _ - @ only.")
    role = choice(d, "role", "Role", assignable, existing["role"] if existing else "employee")
    email = text(d, "email", "Email", 120, required=False)
    if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ApiError("That email address is not valid.")
    f = {"username": username, "full_name": text(d, "full_name", "Full name", 100),
         "job_title": text(d, "job_title", "Job title", 100, required=False),
         "phone": text(d, "phone", "Phone", 30, required=False), "email": email, "role": role,
         "org_id": None, "station_id": None, "supervisor_id": None}
    sd = text(d, "start_date", "Start date", 10, required=False)
    if sd:
        day_text(d, "start_date", "Start date")
    f["start_date"] = sd or (existing["start_date"] if existing else clock.day_of(clock.now(), logic.offset()))
    if role == "super_admin":
        return f
    f["org_id"] = me["org_id"] if me["role"] != "super_admin" else integer(d, "org_id", "Organisation", 1,
                                                                            default=existing["org_id"] if existing else None)
    if not q1("SELECT 1 AS x FROM orgs WHERE id=?", (f["org_id"],)):
        raise ApiError("Organisation not found.")
    f["station_id"] = opt_int(d, "station_id", "Office")
    if f["station_id"] and not q1("SELECT 1 AS x FROM stations WHERE id=? AND org_id=?", (f["station_id"], f["org_id"])):
        raise ApiError("That office belongs to a different organisation.")
    f["supervisor_id"] = opt_int(d, "supervisor_id", "Supervisor")
    if f["supervisor_id"]:
        if existing and f["supervisor_id"] == existing["id"]:
            raise ApiError("A person cannot supervise themselves.")
        if not q1("SELECT 1 AS x FROM users WHERE id=? AND org_id=? AND active=1 AND role IN ('supervisor','org_admin')",
                  (f["supervisor_id"], f["org_id"])):
            raise ApiError("Choose a supervisor from the same organisation.")
    return f


def create_user(me, d):
    f = clean_user(d, me)
    if q1("SELECT 1 AS x FROM users WHERE username=?", (f["username"],)):
        raise ApiError(f"The username '{f['username']}' is already taken.")
    pw = temp_password()
    uid = run("INSERT INTO users(org_id,station_id,supervisor_id,username,full_name,job_title,phone,email,role,pw_hash,"
              "must_change_pw,start_date,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?)",
              (f["org_id"], f["station_id"], f["supervisor_id"], f["username"], f["full_name"], f["job_title"], f["phone"],
               f["email"], f["role"], hash_password(pw), f["start_date"], clock.now()))
    audit("user_created", f["username"], f"role={f['role']}")
    return uid, pw


@bp.get("/users")
@auth(*ADMINS)
def users_list():
    me = g.user
    sql, args = team_scope(me, "u")
    if request.args.get("role"):
        roles = [r for r in request.args["role"].split(",") if r in ROLES]
        sql += f" AND u.role IN ({','.join('?' * len(roles))})" if roles else " AND 0=1"
        args += roles
    if request.args.get("station_id", "").isdigit():
        sql, args = sql + " AND u.station_id=?", args + [int(request.args["station_id"])]
    if request.args.get("q"):
        like = f"%{request.args['q'].strip()[:60]}%"
        sql, args = sql + " AND (u.full_name LIKE ? OR u.username LIKE ?)", args + [like, like]
    total = q1(f"SELECT COUNT(*) AS c FROM users u WHERE {sql}", args)["c"]
    limit = min(int(request.args.get("limit", 300) or 300), 1000)
    offset = max(int(request.args.get("offset", 0) or 0), 0)
    rows = q("SELECT u.id,u.username,u.full_name,u.job_title,u.phone,u.email,u.role,u.org_id,u.station_id,u.supervisor_id,"
             "u.start_date,u.active,u.last_login,u.must_change_pw,s.name AS station_name,o.name AS org_name,"
             "sv.full_name AS supervisor_name FROM users u LEFT JOIN stations s ON s.id=u.station_id "
             "LEFT JOIN orgs o ON o.id=u.org_id LEFT JOIN users sv ON sv.id=u.supervisor_id "
             f"WHERE {sql} ORDER BY u.full_name LIMIT ? OFFSET ?", [*args, limit, offset])
    return jsonify(users=rows, total=total)


@bp.post("/users")
@auth(*ADMINS)
def users_create():
    uid, pw = create_user(g.user, body())
    return jsonify(ok=True, id=uid, temp_password=pw), 201


@bp.put("/users/<int:uid>")
@auth(*ADMINS)
def users_update(uid):
    d, me = body(), g.user
    u = target_user(me, uid)
    f = clean_user(d, me, existing=u)
    active = 1 if d.get("active", True) else 0
    if uid == me["id"] and (not active or f["role"] != u["role"]):
        raise ApiError("You can't deactivate your own account or change your own role.")
    run("UPDATE users SET org_id=?,station_id=?,supervisor_id=?,full_name=?,job_title=?,phone=?,email=?,role=?,start_date=?,active=? WHERE id=?",
        (f["org_id"], f["station_id"], f["supervisor_id"], f["full_name"], f["job_title"], f["phone"], f["email"], f["role"],
         f["start_date"], active, uid))
    if not active:
        run("DELETE FROM auth_sessions WHERE user_id=?", (uid,))
    audit("user_updated", u["username"], f"role={f['role']} active={active}")
    return jsonify(ok=True)


@bp.post("/users/<int:uid>/reset-password")
@auth(*ADMINS)
def users_reset(uid):
    u = target_user(g.user, uid)
    pw = temp_password()
    run("UPDATE users SET pw_hash=?, must_change_pw=1 WHERE id=?", (hash_password(pw), uid))
    run("DELETE FROM auth_sessions WHERE user_id=?", (uid,))
    audit("password_reset", u["username"])
    return jsonify(ok=True, temp_password=pw)


@bp.post("/users/import")
@auth(*ADMINS)
def users_import():
    d, me = body(), g.user
    raw = text(d, "csv", "CSV text", 2_000_000)
    org_id = me["org_id"] if me["role"] != "super_admin" else integer(d, "org_id", "Organisation", 1)
    reader = csv.DictReader(io.StringIO(raw.lstrip("\ufeff")))
    if not reader.fieldnames or "username" not in [h.strip().lower() for h in reader.fieldnames]:
        raise ApiError("The first row must be column names, including 'username' and 'full_name'.")
    stations = {s["name"].lower(): s["id"] for s in q("SELECT id,name FROM stations WHERE org_id=?", (org_id,))}
    created, errors = [], []
    for n, row in enumerate(reader, start=2):
        if n > 2001:
            errors.append({"line": n, "message": "Stopped: a single import can have 2000 rows at most."})
            break
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        if not any(row.values()):
            continue
        try:
            station = row.get("station", "")
            if station and station.lower() not in stations:
                raise ApiError(f"Office '{station}' does not exist. Create it first.")
            sup = row.get("supervisor", "")
            sup_row = q1("SELECT id FROM users WHERE username=? AND org_id=?", (sup, org_id)) if sup else None
            if sup and not sup_row:
                raise ApiError(f"Supervisor '{sup}' was not found. List supervisors before their staff.")
            uid, pw = create_user(me, {
                "username": row.get("username"), "full_name": row.get("full_name") or row.get("name"),
                "job_title": row.get("job_title"), "phone": row.get("phone"), "email": row.get("email"),
                "role": (row.get("role") or "employee").lower(), "start_date": row.get("start_date"), "org_id": org_id,
                "station_id": stations.get(station.lower()), "supervisor_id": sup_row["id"] if sup_row else None})
            created.append({"username": row["username"], "full_name": row.get("full_name") or row.get("name"), "temp_password": pw})
        except ApiError as e:
            errors.append({"line": n, "username": row.get("username", ""), "message": e.message})
    audit("users_imported", f"{len(created)} created", f"{len(errors)} errors")
    return jsonify(ok=True, created=created, errors=errors)


# ------------------------------------------------------------------ holidays, settings, audit
@bp.get("/holidays")
@auth(*MANAGERS)
def holidays_list():
    year = request.args.get("year") or clock.day_of(clock.now(), logic.offset())[:4]
    if not re.fullmatch(r"\d{4}", year):
        raise ApiError("Choose a year like 2026.")
    return jsonify(year=year, holidays=q("SELECT * FROM holidays WHERE day LIKE ? ORDER BY day", (year + "-%",)))


@bp.post("/holidays")
@auth("super_admin")
def holidays_add():
    d = body()
    day, name = day_text(d, "day", "Date"), text(d, "name", "Holiday name", 80)
    run("INSERT OR REPLACE INTO holidays(day,name) VALUES (?,?)", (day, name))
    audit("holiday_saved", day, name)
    return jsonify(ok=True), 201


@bp.delete("/holidays/<day>")
@auth("super_admin")
def holidays_delete(day):
    run("DELETE FROM holidays WHERE day=?", (day,))
    audit("holiday_deleted", day)
    return jsonify(ok=True)


@bp.post("/holidays/seed")
@auth("super_admin")
def holidays_seed():
    year = integer(body(), "year", "Year", 2000, 2100)
    for day, name in calc.uganda_holidays(year).items():
        run("INSERT OR IGNORE INTO holidays(day,name) VALUES (?,?)", (day, name))
    audit("holidays_seeded", year)
    return jsonify(ok=True)


@bp.get("/settings")
@auth(*MANAGERS)
def settings_get():
    return jsonify(logic.settings())


@bp.put("/settings")
@auth("super_admin")
def settings_put():
    d = body()
    th = integer(d, "threshold_pct", "Attendance threshold", 1, 100)
    sm = integer(d, "session_min_pct", "Online session minimum", 1, 100)
    run("UPDATE settings SET value=? WHERE key='threshold_pct'", (str(th),))
    run("UPDATE settings SET value=? WHERE key='session_min_pct'", (str(sm),))
    audit("settings_changed", "", f"threshold={th} session_min={sm}")
    return jsonify(ok=True)


@bp.get("/audit")
@auth(*ADMINS)
def audit_list():
    limit = min(int(request.args.get("limit", 200) or 200), 1000)
    if g.user["role"] == "super_admin":
        rows = q("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))
    else:
        rows = q("SELECT a.* FROM audit a JOIN users u ON u.id=a.actor_id WHERE u.org_id=? ORDER BY a.id DESC LIMIT ?",
                 (g.user["org_id"], limit))
    return jsonify(entries=rows)
