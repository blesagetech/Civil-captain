from flask import g, jsonify

from . import bp
from .. import clock, logic
from ..db import q1, run
from ..security import (ApiError, _DUMMY, add_fail, audit, auth, body, cfg, check_password_strength, clear_cookie,
                        clear_fails, client_ip, hash_password, load_session, purge_attempts, recent_fails, set_cookie, start_session,
                        text, verify_password)


def me_payload(u, csrf):
    org = q1("SELECT name FROM orgs WHERE id=?", (u["org_id"],)) if u["org_id"] else None
    st = q1("SELECT name FROM stations WHERE id=?", (u["station_id"],)) if u["station_id"] else None
    c = cfg()
    return {
        "user": {"id": u["id"], "username": u["username"], "full_name": u["full_name"], "role": u["role"],
                 "job_title": u["job_title"], "org_id": u["org_id"], "org_name": org["name"] if org else "",
                 "station_id": u["station_id"], "station_name": st["name"] if st else "",
                 "must_change_pw": bool(u["must_change_pw"]), "start_date": u["start_date"]},
        "csrf": csrf,
        "settings": logic.settings(),
        "app_name": c.APP_NAME,
        "offset_min": c.UTC_OFFSET_MIN,
        "server_time": clock.now(),
    }


@bp.get("/config")
def public_config():
    c = cfg()
    out = {"app_name": c.APP_NAME, "demo": c.DEMO, "offset_min": c.UTC_OFFSET_MIN}
    if c.DEMO:
        from ..seed import DEMO_LOGINS, DEMO_PASSWORD
        out["demo_password"] = DEMO_PASSWORD
        out["demo_logins"] = [{"username": u, "label": label} for u, label in DEMO_LOGINS]
    return jsonify(out)


@bp.post("/login")
def login():
    d = body()
    username = text(d, "username", "Username", 80)
    password = d.get("password")
    if not isinstance(password, str) or not password:
        raise ApiError("Enter your password.")
    ku, ki = f"u:{username.lower()}", f"ip:{client_ip()}"
    if recent_fails(ku, 900) >= 5 or recent_fails(ki, 900) >= 40:
        raise ApiError("Too many failed sign-in attempts. Wait 15 minutes and try again.", 429)
    u = q1("SELECT * FROM users WHERE username=?", (username,))
    ok = False
    if u and u["active"]:
        ok = verify_password(password, u["pw_hash"])
    else:
        verify_password(password, _DUMMY)  # same cost whether or not the user exists
    if not ok:
        add_fail(ku)
        add_fail(ki)
        purge_attempts()
        audit("login_failed", username)
        raise ApiError("Wrong username or password.", 401)
    clear_fails(ku)
    token, csrf = start_session(u["id"])
    run("UPDATE users SET last_login=? WHERE id=?", (clock.now(), u["id"]))
    resp = jsonify(me_payload(u, csrf))
    set_cookie(resp, token)
    return resp


@bp.post("/logout")
@auth(pending_pw_ok=True)
def logout():
    run("DELETE FROM auth_sessions WHERE token_hash=?", (g.sess["token_hash"],))
    resp = jsonify(ok=True)
    clear_cookie(resp)
    return resp


@bp.get("/me")
def me():
    user, sess = load_session()  # signed-out visitors get user=null rather than an error
    if not user:
        return jsonify(user=None)
    return jsonify(me_payload(user, sess["csrf"]))


@bp.post("/password")
@auth(pending_pw_ok=True)
def change_password():
    d = body()
    key = f"pw:{g.user['id']}"
    if recent_fails(key, 900) >= 5:
        raise ApiError("Too many wrong attempts. Wait 15 minutes and try again.", 429)
    current, new = d.get("current"), d.get("new")
    if not isinstance(current, str) or not verify_password(current, g.user["pw_hash"]):
        add_fail(key)
        raise ApiError("Your current password is wrong.", 403)
    check_password_strength(new, g.user["username"])
    if new == current:
        raise ApiError("Choose a password that is different from the current one.")
    run("UPDATE users SET pw_hash=?, must_change_pw=0 WHERE id=?", (hash_password(new), g.user["id"]))
    run("DELETE FROM auth_sessions WHERE user_id=? AND token_hash<>?", (g.user["id"], g.sess["token_hash"]))
    clear_fails(key)
    audit("password_changed", g.user["username"])
    return jsonify(ok=True)
