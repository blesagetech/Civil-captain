import re

from flask import g, jsonify

from . import bp
from .. import clock, logic
from ..db import q, q1, run
from ..security import ApiError, audit, auth, body, choice, day_text, integer, org_allowed, text
from .team import MANAGERS

KINDS = ("remote_duty", "meeting", "training")


def _json(s, att, ts):
    return {"id": s["id"], "title": s["title"], "kind": s["kind"], "starts_at": s["starts_at"], "ends_at": s["ends_at"],
            "min_pct": s["min_pct"], "join_url": s["join_url"], "station_id": s["station_id"],
            "station_name": s.get("station_name") or "", **logic.session_state(s, att, ts)}


@bp.get("/online")
@auth()
def online_mine():
    u, ts = g.user, clock.now()
    rows = q("SELECT s.*, st.name AS station_name FROM online_sessions s LEFT JOIN stations st ON st.id=s.station_id "
             "WHERE s.org_id=? AND (s.station_id IS NULL OR s.station_id=?) AND s.ends_at>=? AND s.starts_at<=? "
             "ORDER BY s.starts_at DESC", (u["org_id"], u["station_id"], ts - 14 * 86400, ts + 45 * 86400))
    mine = {r["session_id"]: r for r in q("SELECT * FROM online_attendance WHERE user_id=?", (u["id"],))}
    return jsonify(sessions=[_json(s, mine.get(s["id"]), ts) for s in rows], server_time=ts)


@bp.post("/online/<int:sid>/beat")
@auth()
def online_beat(sid):
    return jsonify(ok=True, **logic.beat(g.user, sid))


@bp.get("/admin/online")
@auth(*MANAGERS)
def online_admin_list():
    me, ts = g.user, clock.now()
    where, args = ("1=1", []) if me["role"] == "super_admin" else ("s.org_id=?", [me["org_id"]])
    rows = q("SELECT s.*, st.name AS station_name, o.name AS org_name, "
             "(SELECT COUNT(*) FROM online_attendance a WHERE a.session_id=s.id) AS joined, "
             "(SELECT COUNT(*) FROM online_attendance a WHERE a.session_id=s.id AND a.seconds*100 >= s.min_pct*(s.ends_at-s.starts_at)) AS qualified, "
             "(SELECT COUNT(*) FROM users u WHERE u.org_id=s.org_id AND u.active=1 AND u.role<>'super_admin' "
             " AND (s.station_id IS NULL OR u.station_id=s.station_id)) AS audience "
             f"FROM online_sessions s LEFT JOIN stations st ON st.id=s.station_id LEFT JOIN orgs o ON o.id=s.org_id "
             f"WHERE {where} AND s.starts_at>=? ORDER BY s.starts_at DESC LIMIT 100", [*args, ts - 45 * 86400])
    return jsonify(sessions=rows, server_time=ts)


@bp.post("/admin/online")
@auth(*MANAGERS)
def online_admin_create():
    d, me = body(), g.user
    org_id = me["org_id"] if me["role"] != "super_admin" else integer(d, "org_id", "Organisation", 1)
    title = text(d, "title", "Title", 120)
    kind = choice(d, "kind", "Type", KINDS)
    day = day_text(d, "day", "Date")
    start, end = text(d, "start", "Start time", 5), text(d, "end", "End time", 5)
    if not (clock.valid_hhmm(start) and clock.valid_hhmm(end)):
        raise ApiError("Times must look like 09:00.")
    off = logic.offset()
    s_ts, e_ts = clock.to_ts(day, start, off), clock.to_ts(day, end, off)
    if e_ts <= s_ts:
        raise ApiError("The end time must be after the start time.")
    if e_ts - s_ts > 12 * 3600:
        raise ApiError("A session can last 12 hours at most.")
    station_id = d.get("station_id") or None
    if station_id:
        st = q1("SELECT * FROM stations WHERE id=?", (int(station_id),))
        if not st or st["org_id"] != org_id or not org_allowed(me, st["org_id"]):
            raise ApiError("Office not found in this organisation.", 404)
    url = text(d, "join_url", "Meeting link", 300, required=False)
    if url and not re.match(r"^https://[^\s]+$", url):
        raise ApiError("The meeting link must start with https://")
    min_pct = integer(d, "min_pct", "Minimum attendance", 10, 100, default=logic.settings()["session_min_pct"])
    sid = run("INSERT INTO online_sessions(org_id,station_id,title,kind,starts_at,ends_at,min_pct,join_url,created_by,created_at) "
              "VALUES (?,?,?,?,?,?,?,?,?,?)", (org_id, station_id, title, kind, s_ts, e_ts, min_pct, url, me["id"], clock.now()))
    audit("online_session_created", sid, f"{title} {day} {start}-{end}")
    return jsonify(ok=True, id=sid), 201


@bp.get("/admin/online/<int:sid>")
@auth(*MANAGERS)
def online_admin_detail(sid):
    s = q1("SELECT * FROM online_sessions WHERE id=?", (sid,))
    if not s or not org_allowed(g.user, s["org_id"]):
        raise ApiError("Session not found.", 404)
    sql = ("SELECT u.id, u.full_name, u.job_title, st.name AS station_name, a.seconds, a.first_join FROM users u "
           "LEFT JOIN stations st ON st.id=u.station_id LEFT JOIN online_attendance a ON a.session_id=? AND a.user_id=u.id "
           "WHERE u.org_id=? AND u.active=1 AND u.role<>'super_admin'")
    args = [sid, s["org_id"]]
    if s["station_id"]:
        sql += " AND u.station_id=?"
        args.append(s["station_id"])
    people = q(sql + " ORDER BY u.full_name", args)
    dur = max(1, s["ends_at"] - s["starts_at"])
    for p in people:
        secs = p["seconds"] or 0
        p["pct"] = min(100, round(secs * 100 / dur))
        p["attended"] = secs * 100 >= s["min_pct"] * dur
    return jsonify(session=s, people=people)


@bp.delete("/admin/online/<int:sid>")
@auth(*MANAGERS)
def online_admin_delete(sid):
    s = q1("SELECT * FROM online_sessions WHERE id=?", (sid,))
    if not s or not org_allowed(g.user, s["org_id"]):
        raise ApiError("Session not found.", 404)
    if g.user["role"] == "supervisor" and s["created_by"] != g.user["id"]:
        raise ApiError("You can only delete sessions you created.", 403)
    if q1("SELECT 1 AS x FROM online_attendance WHERE session_id=?", (sid,)):
        raise ApiError("People already joined this session, so it can't be deleted.", 409)
    run("DELETE FROM online_sessions WHERE id=?", (sid,))
    audit("online_session_deleted", sid, s["title"])
    return jsonify(ok=True)
