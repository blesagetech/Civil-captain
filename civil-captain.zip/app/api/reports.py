import csv
import io

from flask import Response, g, request

from . import bp
from .. import clock, logic
from ..db import q
from ..security import ApiError, audit, auth, team_scope
from .team import MANAGERS, int_arg, range_args


def _cell(v):
    """Stop spreadsheet formula injection: a cell starting with = + - @ is read as a formula."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return "" if v is None else v


def _csv(filename, header, rows):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(header)
    for r in rows:
        w.writerow([_cell(v) for v in r])
    return Response("\ufeff" + buf.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"', "Cache-Control": "no-store"})


@bp.get("/reports/summary.csv")
@auth(*MANAGERS)
def summary_csv():
    start, end = range_args()
    users = logic.tracked_users(g.user, int_arg("station_id"), int_arg("org_id"))
    sm = logic.summaries(users, start, end)
    th = logic.settings()["threshold_pct"]
    rows = []
    for u in users:
        s = sm[u["id"]]
        rows.append([u["org_name"], u["station_name"], u["username"], u["full_name"], u["job_title"], s["attended"],
                     s["expected"], s["pct"], {"ok": "Meets minimum", "below": "Below minimum", "na": "No expected days"}[s["status"]],
                     s["late"], s["missing_checkout"], s["flagged"], s["hours"]])
    audit("report_summary", f"{start}..{end}", f"{len(rows)} people")
    return _csv(f"attendance-summary_{start}_{end}.csv",
                ["Organisation", "Office", "Username", "Name", "Job title", "Days attended", "Days expected",
                 f"Attendance % (minimum {th}%)", "Standing", "Late days", "Missing check-outs", "Awaiting review", "Hours worked"], rows)


@bp.get("/reports/records.csv")
@auth(*MANAGERS)
def records_csv():
    start, end = range_args()
    sql, args = team_scope(g.user, "u")
    if int_arg("station_id"):
        sql, args = sql + " AND a.station_id=?", args + [int_arg("station_id")]
    off = logic.offset()
    rows = []
    for r in q("SELECT a.*, u.username, u.full_name, s.name AS station_name FROM attendance a JOIN users u ON u.id=a.user_id "
               "LEFT JOIN stations s ON s.id=a.station_id "
               f"WHERE a.day BETWEEN ? AND ? AND {sql} ORDER BY a.day, u.full_name", [start, end, *args]):
        rows.append([r["day"], r["username"], r["full_name"], r["station_name"], clock.hhmm(r["check_in"], off),
                     clock.hhmm(r["check_out"], off) if r["check_out"] else "", r["status"], r["method"], r["review"],
                     r["flags"], r["distance_m"], r["note"]])
    audit("report_records", f"{start}..{end}", f"{len(rows)} rows")
    return _csv(f"attendance-records_{start}_{end}.csv",
                ["Date", "Username", "Name", "Office", "Check-in", "Check-out", "Status", "Method", "Review", "Flags",
                 "Distance from office (m)", "Note"], rows)


@bp.get("/reports/eligibility.csv")
@auth(*MANAGERS)
def eligibility_csv():
    month = request.args.get("month") or clock.day_of(clock.now(), logic.offset())[:7]
    try:
        start, end = clock.month_bounds(month)
    except (ValueError, IndexError):
        raise ApiError("Choose a month like 2026-10.")
    users = logic.tracked_users(g.user, int_arg("station_id"), int_arg("org_id"))
    sm = logic.summaries(users, start, end)
    th = logic.settings()["threshold_pct"]
    rows = []
    for u in users:
        s = sm[u["id"]]
        eligible = s["status"] != "below"
        final = "Yes" if (end < clock.day_of(clock.now(), logic.offset())) else "No (month still open)"
        rows.append([u["org_name"], u["station_name"], u["username"], u["full_name"], s["attended"], s["expected"], s["pct"],
                     "Eligible" if eligible else "Below minimum - refer to HR", final])
    audit("report_eligibility", month, f"{len(rows)} people")
    return _csv(f"payroll-eligibility_{month}.csv",
                ["Organisation", "Office", "Username", "Name", "Days attended", "Days expected",
                 f"Attendance % (minimum {th}%)", "Payroll eligibility", "Month closed"], rows)
