from flask import g, jsonify, request

from . import bp
from .. import clock, codes, logic
from ..db import q, q1, run
from ..security import (ApiError, add_fail, audit, auth, body, choice, client_ip, day_text, device_id, number,
                        recent_fails, text)

LEAVE_TYPES = ("annual", "sick", "maternity", "paternity", "study", "compassionate", "official_duty", "other")


def _station(user):
    return q1("SELECT * FROM stations WHERE id=?", (user["station_id"],)) if user["station_id"] else None


def _ctx(d):
    return {"ip": client_ip(), "lat": number(d, "lat", "Latitude", -90, 90), "lng": number(d, "lng", "Longitude", -180, 180),
            "accuracy": number(d, "accuracy", "Accuracy", 0, 1000000), "device_id": device_id(d),
            "ua": request.user_agent.string or ""}


@bp.get("/my/home")
@auth()
def my_home():
    u = g.user
    ts, off = clock.now(), logic.offset()
    day = clock.day_of(ts, off)
    summary = logic.summaries([u], *clock.month_bounds(day[:7]), with_days=True)[u["id"]]
    today = next((d for d in summary["days"] if d["day"] == day), None)
    rec = q1("SELECT * FROM attendance WHERE user_id=? AND day=?", (u["id"], day))
    pending = q1("SELECT COUNT(*) AS c FROM requests WHERE user_id=? AND status='pending'", (u["id"],))["c"]
    return jsonify(day=day, month=day[:7], server_time=ts, station=logic.public_station(_station(u)),
                   record=logic.record_json(rec), today_status=today["status"] if today else None,
                   summary=summary, pending_requests=pending)


@bp.get("/my/month")
@auth()
def my_month():
    month = request.args.get("month", "")
    try:
        start, end = clock.month_bounds(month)
    except (ValueError, IndexError):
        raise ApiError("Choose a month like 2026-10.")
    return jsonify(month=month, summary=logic.summaries([g.user], start, end, with_days=True)[g.user["id"]])


@bp.get("/checkin/preview")
@auth()
def checkin_preview():
    try:
        st = codes.verify_token(request.args.get("token", ""), clock.now())
    except ApiError as e:
        return jsonify(valid=False, reason=e.extra.get("reason", "bad_code"), message=e.message)
    if st["org_id"] != g.user["org_id"]:
        return jsonify(valid=False, reason="other_org", message="This code belongs to a different organisation.")
    return jsonify(valid=True, station=logic.public_station(st))


@bp.post("/checkin")
@auth()
def api_checkin():
    u, d, ts = g.user, body(), clock.now()
    fail_key = f"c:{u['id']}"
    if recent_fails(fail_key, 600) >= 8:
        raise ApiError("Too many wrong codes. Wait a few minutes and try again.", 429)
    token = text(d, "token", "Code", 120, required=False)
    code = text(d, "code", "Code", 20, required=False)
    try:
        if token:
            st, via = codes.verify_token(token, ts), "qr"
            if st["org_id"] != u["org_id"]:
                raise ApiError("This code belongs to a different organisation.", 403)
        elif code:
            st, via = _station(u), "code"
            if not st:
                raise ApiError("You are not assigned to an office yet. Ask your HR office to assign you.", 409)
            if not codes.verify_code(st, code, ts):
                raise ApiError("That code is wrong or has expired. Check the number on the office screen.", 400,
                               reason="bad_code")
        else:
            raise ApiError("Scan the QR code, or type the 6-digit code from the office screen.")
    except ApiError as e:
        if e.extra.get("reason") in ("bad_code", "expired"):
            add_fail(fail_key)
        raise
    rec = logic.checkin(u, st, via, _ctx(d))
    return jsonify(ok=True, record=rec, station=logic.public_station(st))


@bp.post("/checkout")
@auth()
def api_checkout():
    return jsonify(ok=True, record=logic.checkout(g.user, _ctx(body())))


@bp.get("/my/requests")
@auth()
def my_requests():
    rows = q("SELECT r.*, d.full_name AS decided_by_name FROM requests r LEFT JOIN users d ON d.id=r.decided_by "
             "WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 80", (g.user["id"],))
    return jsonify(requests=rows, leave_types=LEAVE_TYPES)


@bp.post("/my/requests")
@auth()
def my_requests_create():
    d = body()
    kind = choice(d, "kind", "Request type", ("leave", "correction"))
    start = day_text(d, "start_day", "Date" if kind == "correction" else "First day")
    end = day_text(d, "end_day", "Last day") if kind == "leave" else start
    reason = text(d, "reason", "Reason", 500)
    leave_type = choice(d, "leave_type", "Leave type", LEAVE_TYPES) if kind == "leave" else ""
    claim_in = text(d, "claim_in", "Arrival time", 5, required=False)
    claim_out = text(d, "claim_out", "Departure time", 5, required=False)
    rid = logic.create_request(g.user, kind, start, end, reason, leave_type, claim_in, claim_out)
    audit("request_created", rid, f"{kind} {start}..{end}")
    return jsonify(ok=True, id=rid), 201


@bp.post("/my/requests/<int:rid>/cancel")
@auth()
def my_requests_cancel(rid):
    r = q1("SELECT * FROM requests WHERE id=? AND user_id=?", (rid, g.user["id"]))
    if not r:
        raise ApiError("Request not found.", 404)
    if r["status"] != "pending":
        raise ApiError("Only requests that are still waiting can be cancelled.", 409)
    run("UPDATE requests SET status='cancelled', decided_at=? WHERE id=?", (clock.now(), rid))
    return jsonify(ok=True)


@bp.get("/my/devices")
@auth()
def my_devices():
    rows = q("SELECT id, label, approved, first_seen, last_seen FROM devices WHERE user_id=? ORDER BY first_seen",
             (g.user["id"],))
    return jsonify(devices=rows)
