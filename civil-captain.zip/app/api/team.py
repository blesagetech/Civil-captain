from collections import Counter
from datetime import timedelta

from flask import g, jsonify, request

from . import bp
from .. import clock, logic
from ..db import q, q1, run
from ..security import (ApiError, audit, auth, body, choice, day_text, team_scope, text, user_in_scope)

MANAGERS = ("supervisor", "org_admin", "super_admin")


def int_arg(name):
    v = request.args.get(name, "")
    return int(v) if v.isdigit() else None


def range_args():
    """Report period. 'preset=this|last' is worked out here with the server's calendar, never the phone's."""
    today = clock.day_of(clock.now(), logic.offset())
    preset = request.args.get("preset", "")
    if preset == "last":
        return clock.month_bounds((clock.parse_day(today[:7] + "-01") - timedelta(days=1)).strftime("%Y-%m"))
    if preset == "this":
        return clock.month_bounds(today[:7])[0], today
    start, end = request.args.get("from") or clock.month_bounds(today[:7])[0], request.args.get("to") or today
    try:
        clock.parse_day(start)
        clock.parse_day(end)
    except ValueError:
        raise ApiError("Dates must look like 2026-10-31.")
    if end < start:
        raise ApiError("The end date is before the start date.")
    if (clock.parse_day(end) - clock.parse_day(start)).days > 400:
        raise ApiError("Choose a period of 13 months or less.")
    return start, end


@bp.get("/team/today")
@auth(*MANAGERS)
def team_today():
    me = g.user
    day = clock.day_of(clock.now(), logic.offset())
    users = logic.tracked_users(me, int_arg("station_id"), int_arg("org_id"))
    sm = logic.summaries(users, *clock.month_bounds(day[:7]), with_days=True)
    rows, counts = [], Counter()
    for u in users:
        s = sm[u["id"]]
        item = next(d for d in s["days"] if d["day"] == day)
        state = item["status"]
        counts[state] += 1
        if item.get("review") == "pending":
            counts["flagged"] += 1
        rows.append({"user_id": u["id"], "full_name": u["full_name"], "job_title": u["job_title"],
                     "station_name": u["station_name"] or "", "state": state, "check_in": item.get("check_in"),
                     "check_out": item.get("check_out"), "flags": logic.flag_list(item.get("flags")),
                     "review": item.get("review"), "pct": s["pct"], "month_status": s["status"],
                     "need_more": s["need_more"], "outlook": s["outlook"]})
    return jsonify(day=day, rows=rows, counts=counts, total=len(rows))


@bp.get("/team/summary")
@auth(*MANAGERS)
def team_summary():
    start, end = range_args()
    users = logic.tracked_users(g.user, int_arg("station_id"), int_arg("org_id"))
    sm = logic.summaries(users, start, end)
    rows = []
    for u in users:
        s = sm[u["id"]]
        rows.append({"user_id": u["id"], "full_name": u["full_name"], "username": u["username"], "job_title": u["job_title"],
                     "station_name": u["station_name"] or "", "org_name": u["org_name"] or "", **{
                         k: s[k] for k in ("attended", "expected", "pct", "status", "outlook", "late", "flagged",
                                           "missing_checkout", "hours")}})
    return jsonify(**{"from": start, "to": end}, threshold=logic.settings()["threshold_pct"], rows=rows)


@bp.get("/team/user/<int:uid>/month")
@auth(*MANAGERS)
def team_user_month(uid):
    u = user_in_scope(g.user, uid)
    month = request.args.get("month") or clock.day_of(clock.now(), logic.offset())[:7]
    try:
        start, end = clock.month_bounds(month)
    except (ValueError, IndexError):
        raise ApiError("Choose a month like 2026-10.")
    return jsonify(month=month, user={"id": u["id"], "full_name": u["full_name"], "job_title": u["job_title"]},
                   summary=logic.summaries([u], start, end, with_days=True)[u["id"]])


@bp.get("/review")
@auth(*MANAGERS)
def review():
    sql, args = team_scope(g.user, "u")
    flagged = q("SELECT a.id, a.user_id, a.day, a.check_in, a.check_out, a.flags, a.distance_m, a.status, "
                "u.full_name, s.name AS station_name FROM attendance a JOIN users u ON u.id=a.user_id "
                f"LEFT JOIN stations s ON s.id=a.station_id WHERE a.review='pending' AND {sql} "
                "ORDER BY a.day DESC, a.check_in DESC LIMIT 200", args)
    for r in flagged:
        r["flags"] = logic.flag_list(r["flags"])
    requests_ = q("SELECT r.*, u.full_name FROM requests r JOIN users u ON u.id=r.user_id "
                  f"WHERE r.status='pending' AND {sql} ORDER BY r.created_at LIMIT 200", args)
    devices = q("SELECT d.id, d.label, d.first_seen, u.id AS user_id, u.full_name FROM devices d "
                f"JOIN users u ON u.id=d.user_id WHERE d.approved=0 AND {sql} ORDER BY d.first_seen DESC LIMIT 200", args)
    return jsonify(flagged=flagged, requests=requests_, devices=devices)


@bp.post("/review/attendance/<int:rid>")
@auth(*MANAGERS)
def review_attendance(rid):
    d = body()
    decision = choice(d, "decision", "Decision", ("approve", "reject"))
    rec = q1("SELECT * FROM attendance WHERE id=?", (rid,))
    if not rec:
        raise ApiError("Record not found.", 404)
    owner = user_in_scope(g.user, rec["user_id"])
    note = text(d, "note", "Note", 200, required=False)
    run("UPDATE attendance SET review=?, note=CASE WHEN ?<>'' THEN ? ELSE note END WHERE id=?",
        ("approved" if decision == "approve" else "rejected", note, note, rid))
    audit(f"attendance_{decision}", rid, f"{owner['username']} {rec['day']} flags={rec['flags']}")
    return jsonify(ok=True)


@bp.post("/review/request/<int:rid>")
@auth(*MANAGERS)
def review_request(rid):
    d = body()
    decision = choice(d, "decision", "Decision", ("approve", "reject"))
    req = q1("SELECT * FROM requests WHERE id=?", (rid,))
    if not req:
        raise ApiError("Request not found.", 404)
    user_in_scope(g.user, req["user_id"])
    logic.decide_request(g.user, req, decision, text(d, "note", "Note", 200, required=False))
    return jsonify(ok=True)


@bp.post("/review/device/<int:did>")
@auth(*MANAGERS)
def review_device(did):
    d = body()
    decision = choice(d, "decision", "Decision", ("approve", "revoke"))
    dev = q1("SELECT * FROM devices WHERE id=?", (did,))
    if not dev:
        raise ApiError("Phone not found.", 404)
    owner = user_in_scope(g.user, dev["user_id"])
    run("UPDATE devices SET approved=? WHERE id=?", (1 if decision == "approve" else 2, did))
    audit(f"device_{decision}", did, owner["username"])
    return jsonify(ok=True)


@bp.post("/attendance/manual")
@auth(*MANAGERS)
def manual_entry():
    d = body()
    user = user_in_scope(g.user, int(d.get("user_id") or 0))
    day = day_text(d, "day", "Date")
    today = clock.day_of(clock.now(), logic.offset())
    if day > today:
        raise ApiError("You can't enter attendance for a future day.")
    if day < user["start_date"]:
        raise ApiError(f"{user['full_name']} starts on {user['start_date']}.")
    in_t = text(d, "check_in", "Arrival time", 5)
    out_t = text(d, "check_out", "Departure time", 5, required=False)
    if not clock.valid_hhmm(in_t) or (out_t and not clock.valid_hhmm(out_t)):
        raise ApiError("Times must look like 08:30.")
    station = q1("SELECT * FROM stations WHERE id=?", (user["station_id"],)) if user["station_id"] else None
    note = text(d, "note", "Reason", 200)
    rid = logic.write_attendance(user, station, day, in_t, out_t or None, "manual", note, g.user["id"])
    audit("attendance_manual", rid, f"{user['username']} {day} {in_t}-{out_t or ''}: {note}")
    return jsonify(ok=True, id=rid)
