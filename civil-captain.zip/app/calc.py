"""Attendance maths. No database here, so it is easy to test.

A day is *expected* when it is a working day for the person's station, not a public holiday,
not approved leave and not before the person's start date. Attendance % = attended / expected
over the days that are already over (today counts once checked in, or after work hours end).
"""
from datetime import date, timedelta


def parse(d):
    y, m, dd = d.split("-")
    return date(int(y), int(m), int(dd))


def days(a, b):
    d, e = parse(a), parse(b)
    while d <= e:
        yield d.isoformat()
        d += timedelta(days=1)


def compute(start, end, *, today, now_min, hire, work_days, work_end_min, att, leave, holidays,
            remote, threshold, with_days=True):
    """
    att:      {day: attendance row}        leave: set of days     holidays: {day: name}
    remote:   set of days with a qualifying remote-duty session
    returns   dict with attended/expected/pct/status/outlook/need_more/remaining + optional per-day list
    """
    out = []
    attended = expected = remaining = late = flagged = missing = secs = 0
    for d in days(start, end):
        wd = parse(d).isoweekday()
        row = att.get(d)
        item = {"day": d, "wd": wd}
        if d < hire:
            item["status"] = "before"
        elif d in holidays:
            item["status"], item["note"] = "holiday", holidays[d]
        elif wd not in work_days:
            item["status"] = "off"
        elif d in leave:
            item["status"] = "leave"
        else:
            ok, closed = False, True
            if row and row["review"] != "rejected":
                st, ok = row["status"], True
            elif d in remote:
                st, ok = "remote", True
            elif row:
                st = "rejected"
            elif d > today:
                st, closed = "upcoming", False
            elif d == today and now_min < work_end_min:
                st, closed = "pending", False
            else:
                st = "absent"
            item["status"] = st
            if ok:
                attended += 1
                expected += 1
            elif closed:
                expected += 1
            else:
                remaining += 1
            if st == "late":
                late += 1
        if row:
            item.update(check_in=row["check_in"], check_out=row["check_out"], flags=row["flags"],
                        review=row["review"], method=row["method"], record_id=row["id"])
            if row["review"] == "pending":
                flagged += 1
            if row["check_in"] and row["check_out"]:
                secs += max(0, row["check_out"] - row["check_in"])
            over = d < today or (d == today and now_min >= work_end_min)
            if not row["check_out"] and over and row["review"] != "rejected":
                item["missing_checkout"] = True
                missing += 1
        if with_days:
            out.append(item)

    total = expected + remaining
    pct = round(attended * 100 / expected, 1) if expected else None
    status = "na" if not expected else ("ok" if attended * 100 >= threshold * expected else "below")
    need_total = -(-threshold * total // 100)  # ceil
    need_more = max(0, need_total - attended)
    if total == 0:
        outlook = "na"
    elif need_more == 0:
        outlook = "secured"
    elif need_more <= remaining:
        outlook = "achievable"
    else:
        outlook = "lost"
    res = {"from": start, "to": end, "attended": attended, "expected": expected, "remaining": remaining,
           "pct": pct, "status": status, "outlook": outlook, "need_more": need_more, "late": late,
           "flagged": flagged, "missing_checkout": missing, "hours": round(secs / 3600, 1),
           "threshold": threshold}
    if with_days:
        res["days"] = out
    return res


def easter(year):
    """Gregorian Easter Sunday."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def uganda_holidays(year):
    """Fixed-date public holidays plus Good Friday / Easter Monday.
    Eid al-Fitr and Eid al-Adha follow the moon sighting, so the national admin adds them when announced."""
    fixed = [("01-01", "New Year's Day"), ("01-26", "NRM Liberation Day"), ("02-16", "Archbishop Janani Luwum Day"),
             ("03-08", "International Women's Day"), ("05-01", "Labour Day"), ("06-03", "Martyrs' Day"),
             ("06-09", "National Heroes' Day"), ("10-09", "Independence Day"), ("12-25", "Christmas Day"),
             ("12-26", "Boxing Day")]
    out = {f"{year}-{md}": name for md, name in fixed}
    e = easter(year)
    out[(e - timedelta(days=2)).isoformat()] = "Good Friday"
    out[(e + timedelta(days=1)).isoformat()] = "Easter Monday"
    return out
