"""Time helpers. Moments are stored as UTC epoch seconds; "days" are local calendar days (YYYY-MM-DD)."""
import time
from datetime import datetime, timedelta, timezone

_fake = None  # tests can freeze the clock


def now():
    return int(_fake if _fake is not None else time.time())


def set_fake(ts):
    global _fake
    _fake = ts


def local_dt(ts, offset_min):
    return (datetime.fromtimestamp(ts, timezone.utc) + timedelta(minutes=offset_min)).replace(tzinfo=None)


def day_of(ts, offset_min):
    return local_dt(ts, offset_min).strftime("%Y-%m-%d")


def minutes_of_day(ts, offset_min):
    d = local_dt(ts, offset_min)
    return d.hour * 60 + d.minute


def hhmm(ts, offset_min):
    return local_dt(ts, offset_min).strftime("%H:%M")


def parse_day(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def hm_to_min(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def valid_hhmm(s):
    try:
        h, m = s.split(":")
        return len(s) == 5 and 0 <= int(h) <= 23 and 0 <= int(m) <= 59
    except (ValueError, AttributeError):
        return False


def to_ts(day, hhmm_text, offset_min):
    """Local day + 'HH:MM' -> UTC epoch seconds."""
    d = parse_day(day)
    h, m = hhmm_text.split(":")
    local = datetime(d.year, d.month, d.day, int(h), int(m))
    return int((local - timedelta(minutes=offset_min)).replace(tzinfo=timezone.utc).timestamp())


def month_bounds(month):
    """'2026-10' -> ('2026-10-01', '2026-10-31')."""
    y, m = month.split("-")
    y, m = int(y), int(m)
    first = datetime(y, m, 1).date()
    nxt = datetime(y + (m == 12), (m % 12) + 1, 1).date()
    return first.isoformat(), (nxt - timedelta(days=1)).isoformat()
