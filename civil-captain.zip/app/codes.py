"""Rotating check-in codes.

Every station has a secret. In each time window (default 5 minutes) the station screen shows:
  * a QR code that opens  <site>/c/<token>   (token = station id . window . signature)
  * a 6-digit code people can type if they cannot scan
Both are HMAC-signed with the station secret, so they cannot be guessed or made in advance.
The previous window's code still works for a few seconds after rotation (GRACE) so nobody
is unlucky at the moment of change.
"""
import base64
import hashlib
import hmac
import re
import secrets

from . import qrmatrix
from .db import q1
from .security import ApiError, public_origin

GRACE = 20  # seconds the previous code stays valid after the screen rotates
_TOKEN_RE = re.compile(r"^(\d{1,9})\.(\d{1,12})\.([a-z2-7]{16})$")


def new_secret():
    return secrets.token_hex(32)


def new_display_key():
    return secrets.token_urlsafe(32)


def _mac(secret_hex, msg):
    return hmac.new(bytes.fromhex(secret_hex), msg.encode(), hashlib.sha256).digest()


def make_token(station_id, secret_hex, window):
    sig = base64.b32encode(_mac(secret_hex, f"qr|{station_id}|{window}")[:10]).decode().rstrip("=").lower()
    return f"{station_id}.{window}.{sig}"


def make_code(secret_hex, window):
    n = int.from_bytes(_mac(secret_hex, f"code|{window}")[:4], "big") & 0x7FFFFFFF
    return f"{n % 1000000:06d}"


def _window_ok(window, ts, interval):
    cur = ts // interval
    return window == cur or (window == cur - 1 and ts - cur * interval <= GRACE)


def verify_token(token, ts):
    """Return the station row for a valid, current token. Raises ApiError otherwise."""
    m = _TOKEN_RE.match(token or "")
    if not m:
        raise ApiError("That code is not valid. Scan the code on the office screen.", 400, reason="bad_code")
    sid, window = int(m.group(1)), int(m.group(2))
    st = q1("SELECT * FROM stations WHERE id=?", (sid,))
    if not st:
        raise ApiError("That code is not valid. Scan the code on the office screen.", 400, reason="bad_code")
    expected = make_token(sid, st["qr_secret"], window)
    if not hmac.compare_digest(expected, token):
        raise ApiError("That code is not valid. Scan the code on the office screen.", 400, reason="bad_code")
    if not _window_ok(window, ts, st["qr_interval"]):
        raise ApiError("That code has expired. Scan the code that is on the screen now.", 400, reason="expired")
    return st


def verify_code(station, code, ts):
    code = (code or "").strip().replace(" ", "")
    if not re.fullmatch(r"\d{6}", code):
        return False
    cur = ts // station["qr_interval"]
    windows = [cur]
    if ts - cur * station["qr_interval"] <= GRACE:
        windows.append(cur - 1)
    return any(hmac.compare_digest(make_code(station["qr_secret"], w), code) for w in windows)


def payload(station, ts, origin=None):
    """What a station screen needs right now."""
    interval = station["qr_interval"]
    window = ts // interval
    token = make_token(station["id"], station["qr_secret"], window)
    url = f"{origin or public_origin()}/c/{token}"
    return {
        "station": {"id": station["id"], "name": station["name"], "district": station["district"]},
        "url": url,
        "svg": qrmatrix.to_svg(qrmatrix.encode(url, "M"), border=4),
        "code": make_code(station["qr_secret"], window),
        "interval": interval,
        "expires_in": (window + 1) * interval - ts,
        "server_time": ts,
    }
