"""Settings come from environment variables (all prefixed CC_). See .env.example."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_env_file():
    """Read KEY=value lines from a .env file next to run.py (real environment variables win)."""
    f = BASE_DIR / ".env"
    if not f.is_file():
        return
    for line in f.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file()


def _bool(value, default=False):
    if value is None or value == "":
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on")


class Config:
    def __init__(self, **overrides):
        env = os.environ.get
        self.APP_NAME = env("CC_APP_NAME", "Civil Captain")
        self.DB_PATH = env("CC_DB_PATH", str(BASE_DIR / "data" / "civilcaptain.db"))
        # Public address of the site, e.g. https://attendance.example.go.ug (optional).
        self.PUBLIC_URL = env("CC_PUBLIC_URL", "").rstrip("/")
        # Uganda is UTC+3 all year (no daylight saving).
        self.UTC_OFFSET_MIN = int(env("CC_UTC_OFFSET_MIN", "180"))
        # Only turn on when running behind a reverse proxy you control (Nginx, Caddy, Render...).
        self.TRUST_PROXY = _bool(env("CC_TRUST_PROXY"))
        self.PROXY_HOPS = max(1, int(env("CC_PROXY_HOPS", "1")))
        self.COOKIE_SECURE = _bool(env("CC_COOKIE_SECURE"), self.PUBLIC_URL.startswith("https://"))
        self.SESSION_DAYS = int(env("CC_SESSION_DAYS", "14"))
        self.DEMO = _bool(env("CC_DEMO"))
        self.ADMIN_USERNAME = env("CC_ADMIN_USERNAME", "admin")
        self.ADMIN_PASSWORD = env("CC_ADMIN_PASSWORD", "")
        self.TESTING = False
        for key, value in overrides.items():
            setattr(self, key, value)
