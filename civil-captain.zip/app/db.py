"""SQLite database: schema + tiny helpers. One connection per request, autocommit."""
import os
import sqlite3

from flask import current_app, g

# Safe to run twice (several server workers may start together).
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT OR IGNORE INTO settings VALUES ('threshold_pct','75'), ('session_min_pct','75');

CREATE TABLE IF NOT EXISTS orgs (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  code TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS stations (
  id INTEGER PRIMARY KEY,
  org_id INTEGER NOT NULL REFERENCES orgs(id),
  name TEXT NOT NULL,
  district TEXT NOT NULL DEFAULT '',
  work_start TEXT NOT NULL DEFAULT '08:00',
  work_end TEXT NOT NULL DEFAULT '17:00',
  grace_min INTEGER NOT NULL DEFAULT 15,
  work_days TEXT NOT NULL DEFAULT '1,2,3,4,5',
  qr_interval INTEGER NOT NULL DEFAULT 300,
  qr_secret TEXT NOT NULL,
  display_key TEXT NOT NULL UNIQUE,
  lat REAL, lng REAL,
  radius_m INTEGER NOT NULL DEFAULT 150,
  allowed_cidrs TEXT NOT NULL DEFAULT '',
  ip_policy TEXT NOT NULL DEFAULT 'off' CHECK (ip_policy IN ('off','flag','block')),
  geo_policy TEXT NOT NULL DEFAULT 'off' CHECK (geo_policy IN ('off','flag','block')),
  device_policy TEXT NOT NULL DEFAULT 'flag' CHECK (device_policy IN ('off','flag','block')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  UNIQUE (org_id, name)
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  org_id INTEGER REFERENCES orgs(id),
  station_id INTEGER REFERENCES stations(id),
  supervisor_id INTEGER REFERENCES users(id),
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  full_name TEXT NOT NULL,
  job_title TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL CHECK (role IN ('super_admin','org_admin','supervisor','employee')),
  pw_hash TEXT NOT NULL,
  must_change_pw INTEGER NOT NULL DEFAULT 1,
  start_date TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  last_login INTEGER
);
CREATE INDEX IF NOT EXISTS idx_users_org ON users(org_id);
CREATE INDEX IF NOT EXISTS idx_users_sup ON users(supervisor_id);
CREATE INDEX IF NOT EXISTS idx_users_station ON users(station_id);

CREATE TABLE IF NOT EXISTS auth_sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  ip TEXT NOT NULL DEFAULT '',
  ua TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_auth_user ON auth_sessions(user_id);

CREATE TABLE IF NOT EXISTS login_attempts (id INTEGER PRIMARY KEY, key TEXT NOT NULL, at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_attempts ON login_attempts(key, at);

CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_hash TEXT NOT NULL,
  label TEXT NOT NULL DEFAULT '',
  approved INTEGER NOT NULL DEFAULT 0,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  UNIQUE (user_id, device_hash)
);

CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  station_id INTEGER REFERENCES stations(id),
  day TEXT NOT NULL,
  check_in INTEGER NOT NULL,
  check_out INTEGER,
  method TEXT NOT NULL DEFAULT 'qr',
  status TEXT NOT NULL DEFAULT 'present' CHECK (status IN ('present','late')),
  flags TEXT NOT NULL DEFAULT '',
  review TEXT NOT NULL DEFAULT 'ok' CHECK (review IN ('ok','pending','approved','rejected')),
  ip TEXT NOT NULL DEFAULT '',
  lat REAL, lng REAL, accuracy REAL, distance_m REAL,
  device_id INTEGER REFERENCES devices(id),
  note TEXT NOT NULL DEFAULT '',
  created_by INTEGER REFERENCES users(id),
  created_at INTEGER NOT NULL,
  UNIQUE (user_id, day)
);
CREATE INDEX IF NOT EXISTS idx_att_day ON attendance(day);
CREATE INDEX IF NOT EXISTS idx_att_review ON attendance(review);

CREATE TABLE IF NOT EXISTS holidays (day TEXT PRIMARY KEY, name TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL CHECK (kind IN ('leave','correction')),
  leave_type TEXT NOT NULL DEFAULT '',
  start_day TEXT NOT NULL,
  end_day TEXT NOT NULL,
  claim_in TEXT NOT NULL DEFAULT '',
  claim_out TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
  decided_by INTEGER REFERENCES users(id),
  decided_at INTEGER,
  decision_note TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_req_user ON requests(user_id, status);

CREATE TABLE IF NOT EXISTS online_sessions (
  id INTEGER PRIMARY KEY,
  org_id INTEGER NOT NULL REFERENCES orgs(id),
  station_id INTEGER REFERENCES stations(id),
  title TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('remote_duty','meeting','training')),
  starts_at INTEGER NOT NULL,
  ends_at INTEGER NOT NULL,
  min_pct INTEGER NOT NULL DEFAULT 75,
  join_url TEXT NOT NULL DEFAULT '',
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS online_attendance (
  session_id INTEGER NOT NULL REFERENCES online_sessions(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  first_join INTEGER NOT NULL,
  last_beat INTEGER NOT NULL,
  seconds INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (session_id, user_id)
);

CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY,
  at INTEGER NOT NULL,
  actor_id INTEGER,
  actor_name TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL,
  target TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  ip TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_audit_at ON audit(at);
"""


def connect(path):
    conn = sqlite3.connect(path, timeout=30, isolation_level=None)  # autocommit
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def init_db(path):
    folder = os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    conn = connect(path)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        if conn.execute("PRAGMA user_version").fetchone()[0] < 1:
            conn.executescript(SCHEMA)
            conn.execute("PRAGMA user_version=1")
    finally:
        conn.close()


def db():
    if "db" not in g:
        g.db = connect(current_app.config["CC"].DB_PATH)
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def q(sql, args=()):
    return [dict(r) for r in db().execute(sql, args).fetchall()]


def q1(sql, args=()):
    r = db().execute(sql, args).fetchone()
    return dict(r) if r else None


def run(sql, args=()):
    return db().execute(sql, args).lastrowid
