"""Business rules that sit between the HTTP layer and the database."""
import hashlib
import ipaddress
import math
import re
import sqlite3

from . import calc, clock
from .db import q, q1, run
from .security import ApiError, audit, cfg

BEAT_MAX_GAP = 75  # seconds: a longer silence than this is not counted as attending


def offset():
    return cfg().UTC_OFFSET_MIN


def settings():
    d = {"threshold_pct": 75, "session_min_pct": 75}
    for r in q("SELECT key, value FROM settings"):
        try:
            d[r["key"]] = int(r["value"])
        except ValueError:
            pass
    return d


def flag_list(s):
    return [f for f in (s or "").split(",") if f]


def work_days(station):
    raw = station["work_days"] if station else "1,2,3,4,5"
    return {int(x) for x in raw.split(",") if x.strip().isdigit()}


def public_station(st):
    if not st:
        return None
    return {k: st[k] for k in ("id", "name", "district", "work_start", "work_end", "grace_min",
                               "geo_policy", "ip_policy", "device_policy", "qr_interval")}


# ------------------------------------------------------------------ network / location checks
def haversine_m(lat1, lng1, lat2, lng2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lng2 - lng1) / 2) ** 2
    return 2 * 6371000.0 * math.asin(math.sqrt(a))


def parse_cidrs(text_value):
    nets = []
    for part in re.split(r"[,\s;]+", (text_value or "").strip()):
        if part:
            try:
                nets.append(ipaddress.ip_network(part, strict=False))
            except ValueError:
                raise ApiError(f"'{part}' is not a valid network address (example: 41.210.10.0/24).")
    return nets


def ip_allowed(ip, cidrs_text):
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if addr.version == 6 and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    try:
        return any(addr in n for n in parse_cidrs(cidrs_text) if n.version == addr.version)
    except ApiError:
        return False


def evaluate_policy(user, station, ctx, day):
    """Apply the station's network, location and phone rules.
    Returns (flags, evidence). Raises ApiError when a rule is set to 'block' and fails."""
    flags = []
    ev = {"ip": ctx.get("ip") or "", "lat": None, "lng": None, "accuracy": None, "distance_m": None, "device_id": None}

    if station["ip_policy"] != "off" and (station["allowed_cidrs"] or "").strip():
        if not ip_allowed(ctx.get("ip", ""), station["allowed_cidrs"]):
            if station["ip_policy"] == "block":
                raise ApiError("You are not on the office network. Connect to the office Wi-Fi and try again.",
                               403, reason="ip_outside")
            flags.append("ip_outside")

    if station["geo_policy"] != "off" and station["lat"] is not None and station["lng"] is not None:
        lat, lng, acc = ctx.get("lat"), ctx.get("lng"), ctx.get("accuracy")
        if lat is None or lng is None:
            if station["geo_policy"] == "block":
                raise ApiError("Share your phone's location to check in at this office.", 403, reason="no_location")
            flags.append("no_location")
        else:
            dist = haversine_m(lat, lng, station["lat"], station["lng"])
            ev.update(lat=lat, lng=lng, accuracy=acc, distance_m=round(dist))
            if dist > station["radius_m"] + min(acc or 0, 100):
                if station["geo_policy"] == "block":
                    raise ApiError(f"You are about {round(dist)} m from {station['name']}. Move closer and try again.",
                                   403, reason="geo_outside")
                flags.append("geo_outside")

    if station["device_policy"] != "off":
        did = ctx.get("device_id")
        if not did:
            if station["device_policy"] == "block":
                raise ApiError("This page could not identify your phone. Reload and try again.", 400, reason="no_device")
            flags.append("no_device")
        else:
            dh = hashlib.sha256(did.encode()).hexdigest()
            t = clock.now()
            row = q1("SELECT * FROM devices WHERE user_id=? AND device_hash=?", (user["id"], dh))
            if not row:
                has_ok = q1("SELECT 1 AS x FROM devices WHERE user_id=? AND approved=1", (user["id"],))
                dev_id = run("INSERT INTO devices(user_id,device_hash,label,approved,first_seen,last_seen) VALUES (?,?,?,?,?,?)",
                             (user["id"], dh, (ctx.get("ua") or "")[:120], 0 if has_ok else 1, t, t))
                approved = not has_ok
            else:
                dev_id, approved = row["id"], row["approved"] == 1
                run("UPDATE devices SET last_seen=? WHERE id=?", (t, dev_id))
            ev["device_id"] = dev_id
            if not approved:
                if station["device_policy"] == "block":
                    raise ApiError("This phone is not registered to your account. Ask your supervisor to approve it.",
                                   403, reason="new_device")
                flags.append("new_device")
            if q1("SELECT 1 AS x FROM attendance a JOIN devices d ON d.id=a.device_id "
                  "WHERE d.device_hash=? AND a.day=? AND a.user_id<>?", (dh, day, user["id"])):
                if station["device_policy"] == "block":
                    raise ApiError("This phone was already used to check in someone else today.", 403, reason="shared_device")
                flags.append("shared_device")
    return flags, ev


# ------------------------------------------------------------------ check in / out
def record_json(r):
    if not r:
        return None
    return {"id": r["id"], "day": r["day"], "check_in": r["check_in"], "check_out": r["check_out"],
            "status": r["status"], "flags": flag_list(r["flags"]), "review": r["review"], "method": r["method"]}


def checkin(user, station, via, ctx):
    ts, off = clock.now(), offset()
    day = clock.day_of(ts, off)
    if not station["active"]:
        raise ApiError("This office is switched off. Contact your HR office.", 403)
    existing = q1("SELECT * FROM attendance WHERE user_id=? AND day=?", (user["id"], day))
    if existing:
        raise ApiError(f"You already checked in today at {clock.hhmm(existing['check_in'], off)}.", 409, already=True)
    flags, ev = evaluate_policy(user, station, ctx, day)
    late = clock.minutes_of_day(ts, off) > clock.hm_to_min(station["work_start"]) + station["grace_min"]
    store_geo = station["geo_policy"] != "off"
    try:
        rid = run("INSERT INTO attendance(user_id,station_id,day,check_in,method,status,flags,review,ip,lat,lng,accuracy,"
                  "distance_m,device_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (user["id"], station["id"], day, ts, via, "late" if late else "present", ",".join(flags),
                   "pending" if flags else "ok", ev["ip"], ev["lat"] if store_geo else None,
                   ev["lng"] if store_geo else None, ev["accuracy"] if store_geo else None,
                   ev["distance_m"], ev["device_id"], ts))
    except sqlite3.IntegrityError:
        raise ApiError("You already checked in today.", 409, already=True)
    return record_json(q1("SELECT * FROM attendance WHERE id=?", (rid,)))


def checkout(user, ctx):
    ts, off = clock.now(), offset()
    day = clock.day_of(ts, off)
    rec = q1("SELECT * FROM attendance WHERE user_id=? AND day=?", (user["id"], day))
    if not rec:
        raise ApiError("You have not checked in today.", 409)
    if rec["check_out"]:
        raise ApiError(f"You already checked out at {clock.hhmm(rec['check_out'], off)}.", 409)
    if ts - rec["check_in"] < 60:
        raise ApiError("You just checked in. Wait a minute before checking out.", 409)
    station = q1("SELECT * FROM stations WHERE id=?", (rec["station_id"],))
    flags, _ev = evaluate_policy(user, station, ctx, day)
    merged = flag_list(rec["flags"]) + [f for f in flags if f not in flag_list(rec["flags"])]
    review = "pending" if (flags and rec["review"] == "ok") else rec["review"]
    run("UPDATE attendance SET check_out=?, flags=?, review=? WHERE id=?", (ts, ",".join(merged), review, rec["id"]))
    return record_json(q1("SELECT * FROM attendance WHERE id=?", (rec["id"],)))


# ------------------------------------------------------------------ summaries
def load_ctx(user_ids, start, end):
    """Bulk-load everything calc.compute needs for many people."""
    att, leave, remote = {}, {}, {}
    ids = list(user_ids)
    holidays = {r["day"]: r["name"] for r in q("SELECT * FROM holidays WHERE day BETWEEN ? AND ?", (start, end))}
    if not ids:
        return att, leave, holidays, remote
    off = offset()
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        marks = ",".join("?" * len(chunk))
        for r in q(f"SELECT * FROM attendance WHERE user_id IN ({marks}) AND day BETWEEN ? AND ?", [*chunk, start, end]):
            att.setdefault(r["user_id"], {})[r["day"]] = r
        for r in q(f"SELECT user_id,start_day,end_day FROM requests WHERE kind='leave' AND status='approved' "
                   f"AND user_id IN ({marks}) AND start_day<=? AND end_day>=?", [*chunk, end, start]):
            for d in calc.days(max(r["start_day"], start), min(r["end_day"], end)):
                leave.setdefault(r["user_id"], set()).add(d)
        lo, hi = clock.to_ts(start, "00:00", off), clock.to_ts(end, "23:59", off)
        for r in q(f"SELECT oa.user_id, os.starts_at, os.ends_at, os.min_pct, oa.seconds FROM online_attendance oa "
                   f"JOIN online_sessions os ON os.id=oa.session_id WHERE os.kind='remote_duty' "
                   f"AND oa.user_id IN ({marks}) AND os.starts_at BETWEEN ? AND ?", [*chunk, lo, hi]):
            dur = r["ends_at"] - r["starts_at"]
            if dur > 0 and r["seconds"] * 100 >= r["min_pct"] * dur:
                remote.setdefault(r["user_id"], set()).add(clock.day_of(r["starts_at"], off))
    return att, leave, holidays, remote


def summaries(users, start, end, with_days=False):
    """calc.compute for a list of user rows. Returns {user_id: result}."""
    if not users:
        return {}
    att, leave, holidays, remote = load_ctx([u["id"] for u in users], start, end)
    stations = {s["id"]: s for s in q("SELECT * FROM stations")}
    th = settings()["threshold_pct"]
    ts, off = clock.now(), offset()
    today, now_min = clock.day_of(ts, off), clock.minutes_of_day(ts, off)
    out = {}
    for u in users:
        st = stations.get(u["station_id"])
        out[u["id"]] = calc.compute(
            start, end, today=today, now_min=now_min, hire=u["start_date"], work_days=work_days(st),
            work_end_min=clock.hm_to_min(st["work_end"]) if st else 17 * 60, att=att.get(u["id"], {}),
            leave=leave.get(u["id"], set()), holidays=holidays, remote=remote.get(u["id"], set()),
            threshold=th, with_days=with_days)
    return out


def tracked_users(me, station_id=None, org_id=None):
    """People a manager can see in reports: active, not the national super admin."""
    from .security import team_scope
    sql, args = team_scope(me)
    sql = f"u.active=1 AND u.role<>'super_admin' AND {sql}"
    if station_id:
        sql += " AND u.station_id=?"
        args = [*args, station_id]
    if org_id and me["role"] == "super_admin":
        sql += " AND u.org_id=?"
        args = [*args, org_id]
    return q("SELECT u.*, s.name AS station_name, o.name AS org_name FROM users u "
             "LEFT JOIN stations s ON s.id=u.station_id LEFT JOIN orgs o ON o.id=u.org_id "
             f"WHERE {sql} ORDER BY u.full_name", args)


# ------------------------------------------------------------------ leave & corrections
def create_request(user, kind, start_day, end_day, reason, leave_type="", claim_in="", claim_out=""):
    today = clock.day_of(clock.now(), offset())
    if end_day < start_day:
        raise ApiError("The end date is before the start date.")
    if kind == "correction":
        if start_day != end_day:
            raise ApiError("A correction is for a single day.")
        if start_day > today:
            raise ApiError("You can only correct a day that has already started.")
        if (today > start_day) and (clock.parse_day(today) - clock.parse_day(start_day)).days > 30:
            raise ApiError("Corrections must be sent within 30 days. Ask your supervisor to enter it.")
        if not claim_in or not clock.valid_hhmm(claim_in):
            raise ApiError("Enter the time you arrived, like 08:10.")
        if claim_out and not clock.valid_hhmm(claim_out):
            raise ApiError("Enter the time you left like 17:00, or leave it empty.")
        if q1("SELECT 1 AS x FROM attendance WHERE user_id=? AND day=? AND check_out IS NOT NULL", (user["id"], start_day)):
            raise ApiError("That day already has a complete attendance record.")
    else:
        if (clock.parse_day(end_day) - clock.parse_day(start_day)).days > 180:
            raise ApiError("Leave can cover at most 180 days in one request.")
        clash = q1("SELECT 1 AS x FROM requests WHERE user_id=? AND kind='leave' AND status IN ('pending','approved') "
                   "AND start_day<=? AND end_day>=?", (user["id"], end_day, start_day))
        if clash:
            raise ApiError("You already have leave requested or approved for some of those days.")
    if q1("SELECT 1 AS x FROM requests WHERE user_id=? AND kind=? AND status='pending' AND start_day=? AND end_day=?",
          (user["id"], kind, start_day, end_day)):
        raise ApiError("You already sent this request. It is waiting for review.")
    return run("INSERT INTO requests(user_id,kind,leave_type,start_day,end_day,claim_in,claim_out,reason,created_at) "
               "VALUES (?,?,?,?,?,?,?,?,?)",
               (user["id"], kind, leave_type, start_day, end_day, claim_in, claim_out, reason, clock.now()))


def write_attendance(user, station, day, in_hhmm, out_hhmm, method, note, actor_id):
    """Create or complete an attendance record by hand (approved corrections, supervisor entry)."""
    off = offset()
    check_in = clock.to_ts(day, in_hhmm, off)
    check_out = clock.to_ts(day, out_hhmm, off) if out_hhmm else None
    if check_out is not None and check_out <= check_in:
        raise ApiError("Check-out must be after check-in.")
    late = station is not None and clock.hm_to_min(in_hhmm) > clock.hm_to_min(station["work_start"]) + station["grace_min"]
    row = q1("SELECT * FROM attendance WHERE user_id=? AND day=?", (user["id"], day))
    t = clock.now()
    if row:
        flags = flag_list(row["flags"])
        if "manual" not in flags:
            flags.append("manual")
        run("UPDATE attendance SET check_in=?, check_out=?, method=?, status=?, flags=?, review='approved', note=?, created_by=? WHERE id=?",
            (check_in, check_out, method, "late" if late else "present", ",".join(flags), note, actor_id, row["id"]))
        return row["id"]
    return run("INSERT INTO attendance(user_id,station_id,day,check_in,check_out,method,status,flags,review,note,created_by,created_at) "
               "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
               (user["id"], station["id"] if station else None, day, check_in, check_out, method,
                "late" if late else "present", "manual", "approved", note, actor_id, t))


def decide_request(me, req, decision, note):
    if req["status"] != "pending":
        raise ApiError("That request was already decided.", 409)
    status = "approved" if decision == "approve" else "rejected"
    if status == "approved" and req["kind"] == "correction":
        owner = q1("SELECT * FROM users WHERE id=?", (req["user_id"],))
        station = q1("SELECT * FROM stations WHERE id=?", (owner["station_id"],)) if owner["station_id"] else None
        existing = q1("SELECT * FROM attendance WHERE user_id=? AND day=?", (owner["id"], req["start_day"]))
        in_hhmm = req["claim_in"] or (clock.hhmm(existing["check_in"], offset()) if existing else "")
        if not in_hhmm:
            raise ApiError("This request has no arrival time.")
        write_attendance(owner, station, req["start_day"], in_hhmm, req["claim_out"] or None, "correction",
                         f"Correction approved: {req['reason']}"[:200], me["id"])
    run("UPDATE requests SET status=?, decided_by=?, decided_at=?, decision_note=? WHERE id=?",
        (status, me["id"], clock.now(), note, req["id"]))
    audit(f"request_{status}", req["id"], f"{req['kind']} {req['start_day']}..{req['end_day']} user {req['user_id']}", actor=me)


# ------------------------------------------------------------------ online sessions (duration tracking)
def session_visible(user, s):
    return s["org_id"] == user["org_id"] and (s["station_id"] is None or s["station_id"] == user["station_id"])


def session_state(s, att, ts):
    dur = max(1, s["ends_at"] - s["starts_at"])
    secs = att["seconds"] if att else 0
    pct = min(100, round(secs * 100 / dur))
    return {"seconds": secs, "pct": pct, "attended": secs * 100 >= s["min_pct"] * dur,
            "phase": "upcoming" if ts < s["starts_at"] else ("live" if ts <= s["ends_at"] else "ended")}


def beat(user, sid):
    s = q1("SELECT * FROM online_sessions WHERE id=?", (sid,))
    if not s or not session_visible(user, s):
        raise ApiError("Session not found.", 404)
    ts = clock.now()
    if ts < s["starts_at"]:
        raise ApiError("This session has not started yet.", 409)
    if ts > s["ends_at"] + 60:
        raise ApiError("This session has ended.", 409)
    row = q1("SELECT * FROM online_attendance WHERE session_id=? AND user_id=?", (sid, user["id"]))
    if not row:
        run("INSERT OR IGNORE INTO online_attendance(session_id,user_id,first_join,last_beat,seconds) VALUES (?,?,?,?,0)",
            (sid, user["id"], ts, ts))
        row = q1("SELECT * FROM online_attendance WHERE session_id=? AND user_id=?", (sid, user["id"]))
    else:
        gap = ts - row["last_beat"]
        add = gap if 0 < gap <= BEAT_MAX_GAP else 0
        add = max(0, min(add, min(ts, s["ends_at"]) - max(row["last_beat"], s["starts_at"])))
        secs = min(s["ends_at"] - s["starts_at"], row["seconds"] + add)
        run("UPDATE online_attendance SET last_beat=?, seconds=? WHERE session_id=? AND user_id=?", (ts, secs, sid, user["id"]))
        row = {**row, "seconds": secs}
    return session_state(s, row, ts)
