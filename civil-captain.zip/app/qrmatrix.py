"""Small dependency-free QR Code encoder: byte mode, versions 1-10, error correction L/M/Q/H.

encode(text) -> list of rows of booleans (True = dark module).  to_svg(matrix) -> SVG string.
"""

# (error-correction codewords per block, [(number of blocks, data codewords per block), ...]) for versions 1..10
_BLOCKS = {
    "L": [None, (7, [(1, 19)]), (10, [(1, 34)]), (15, [(1, 55)]), (20, [(1, 80)]), (26, [(1, 108)]),
          (18, [(2, 68)]), (20, [(2, 78)]), (24, [(2, 97)]), (30, [(2, 116)]), (18, [(2, 68), (2, 69)])],
    "M": [None, (10, [(1, 16)]), (16, [(1, 28)]), (26, [(1, 44)]), (18, [(2, 32)]), (24, [(2, 43)]),
          (16, [(4, 27)]), (18, [(4, 31)]), (22, [(2, 38), (2, 39)]), (22, [(3, 36), (2, 37)]), (26, [(4, 43), (1, 44)])],
    "Q": [None, (13, [(1, 13)]), (22, [(1, 22)]), (18, [(2, 17)]), (26, [(2, 24)]), (18, [(2, 15), (2, 16)]),
          (24, [(4, 19)]), (18, [(2, 14), (4, 15)]), (22, [(4, 18), (2, 19)]), (20, [(4, 16), (4, 17)]), (24, [(6, 19), (2, 20)])],
    "H": [None, (17, [(1, 9)]), (28, [(1, 16)]), (22, [(2, 13)]), (16, [(4, 9)]), (22, [(2, 11), (2, 12)]),
          (28, [(4, 15)]), (26, [(4, 13), (1, 14)]), (26, [(4, 14), (2, 15)]), (24, [(4, 12), (4, 13)]), (28, [(6, 15), (2, 16)])],
}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38],
          8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}
_REMAINDER = {1: 0, 2: 7, 3: 7, 4: 7, 5: 7, 6: 7, 7: 0, 8: 0, 9: 0, 10: 0}
_ECC_BITS = {"L": 1, "M": 0, "Q": 3, "H": 2}

# ---- Reed-Solomon over GF(256), primitive polynomial 0x11D
_EXP, _LOG = [0] * 512, [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i], _LOG[_x] = _x, _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _mul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _generator(degree):
    g = [1]
    for i in range(degree):
        nxt = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            nxt[j] ^= c
            nxt[j + 1] ^= _mul(c, _EXP[i])
        g = nxt
    return g


def _remainder(data, gen):
    n = len(gen) - 1
    rem = [0] * n
    for b in data:
        factor = b ^ rem[0]
        rem = rem[1:] + [0]
        for i in range(n):
            rem[i] ^= _mul(gen[i + 1], factor)
    return rem


def total_data_codewords(ecc, version):
    return sum(n * d for n, d in _BLOCKS[ecc][version][1])


def _format_bits(ecc, mask):
    data = (_ECC_BITS[ecc] << 3) | mask
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    return ((data << 10) | rem) ^ 0x5412


def _version_bits(version):
    rem = version
    for _ in range(12):
        rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
    return (version << 12) | rem


def _format_positions(n):
    p = [(8, i, i) for i in range(6)] + [(8, 7, 6), (8, 8, 7), (7, 8, 8)]
    p += [(14 - i, 8, i) for i in range(9, 15)]
    p += [(n - 1 - i, 8, i) for i in range(8)]
    p += [(8, n - 15 + i, i) for i in range(8, 15)]
    return p


_MASKS = [
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (y // 2 + x // 3) % 2 == 0,
    lambda x, y: (x * y) % 2 + (x * y) % 3 == 0,
    lambda x, y: ((x * y) % 2 + (x * y) % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + (x * y) % 3) % 2 == 0,
]


def _penalty(m):
    n, score = len(m), 0
    strings = ["".join("1" if v else "0" for v in row) for row in m]
    strings += ["".join("1" if m[y][x] else "0" for y in range(n)) for x in range(n)]
    for s in strings:
        run = 1
        for i in range(1, n + 1):
            if i < n and s[i] == s[i - 1]:
                run += 1
            else:
                if run >= 5:
                    score += 3 + run - 5
                run = 1
        for pat in ("10111010000", "00001011101"):
            at = s.find(pat)
            while at != -1:
                score += 40
                at = s.find(pat, at + 1)
    for y in range(n - 1):
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(sum(r) for r in m)
    total = n * n
    score += max(0, (abs(dark * 20 - total * 10) + total - 1) // total - 1) * 10
    return score


def encode(text, ecc="M"):
    data = text.encode("utf-8")
    version = None
    for v in range(1, 11):
        cc_bits = 8 if v < 10 else 16
        if 4 + cc_bits + 8 * len(data) <= 8 * total_data_codewords(ecc, v):
            version = v
            break
    if version is None:
        raise ValueError("Text is too long for this QR code generator.")
    ec_len, groups = _BLOCKS[ecc][version]
    cap_bits = 8 * total_data_codewords(ecc, version)

    bits = []

    def put(val, n):
        bits.extend((val >> i) & 1 for i in range(n - 1, -1, -1))

    put(0b0100, 4)
    put(len(data), 8 if version < 10 else 16)
    for b in data:
        put(b, 8)
    put(0, min(4, cap_bits - len(bits)))
    put(0, (-len(bits)) % 8)
    pad = 0
    while len(bits) < cap_bits:
        put((0xEC, 0x11)[pad % 2], 8)
        pad += 1
    words = [int("".join(map(str, bits[k:k + 8])), 2) for k in range(0, len(bits), 8)]

    blocks, pos = [], 0
    for count, size in groups:
        for _ in range(count):
            blocks.append(words[pos:pos + size])
            pos += size
    gen = _generator(ec_len)
    ecs = [_remainder(b, gen) for b in blocks]
    seq = []
    for i in range(max(len(b) for b in blocks)):
        seq += [b[i] for b in blocks if i < len(b)]
    for i in range(ec_len):
        seq += [e[i] for e in ecs]
    stream = [(w >> k) & 1 for w in seq for k in range(7, -1, -1)] + [0] * _REMAINDER[version]

    n = 17 + 4 * version
    mod = [[False] * n for _ in range(n)]
    fixed = [[False] * n for _ in range(n)]

    def setf(x, y, v):
        mod[y][x] = v
        fixed[y][x] = True

    for cx, cy in ((0, 0), (n - 7, 0), (0, n - 7)):  # finder patterns + separators
        for dy in range(-1, 8):
            for dx in range(-1, 8):
                x, y = cx + dx, cy + dy
                if 0 <= x < n and 0 <= y < n:
                    setf(x, y, max(abs(dx - 3), abs(dy - 3)) not in (2, 4))
    for i in range(8, n - 8):  # timing patterns
        setf(i, 6, i % 2 == 0)
        setf(6, i, i % 2 == 0)
    centers = _ALIGN[version]
    for cy in centers:  # alignment patterns
        for cx in centers:
            if (cx == 6 and cy == 6) or (cx == 6 and cy == centers[-1]) or (cx == centers[-1] and cy == 6):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)
    fmt_pos = _format_positions(n)
    for x, y, _i in fmt_pos:
        fixed[y][x] = True
    setf(8, n - 8, True)  # always-dark module
    ver_bits = _version_bits(version) if version >= 7 else None
    if ver_bits is not None:
        for i in range(18):
            a, b = n - 11 + i % 3, i // 3
            setf(a, b, bool((ver_bits >> i) & 1))
            setf(b, a, bool((ver_bits >> i) & 1))

    i = 0  # data placement: zig-zag from bottom-right
    x, upward = n - 1, True
    while x > 0:
        if x == 6:
            x -= 1
        for k in range(n):
            y = n - 1 - k if upward else k
            for xx in (x, x - 1):
                if not fixed[y][xx]:
                    mod[y][xx] = bool(stream[i]) if i < len(stream) else False
                    i += 1
        upward = not upward
        x -= 2

    best, best_score = None, None
    for mask in range(8):
        m = [row[:] for row in mod]
        fn = _MASKS[mask]
        for y in range(n):
            for x in range(n):
                if not fixed[y][x] and fn(x, y):
                    m[y][x] = not m[y][x]
        fb = _format_bits(ecc, mask)
        for x, y, bit in fmt_pos:
            m[y][x] = bool((fb >> bit) & 1)
        score = _penalty(m)
        if best_score is None or score < best_score:
            best, best_score = m, score
    return best


def to_svg(matrix, border=4, dark="#000000", light="#ffffff"):
    n = len(matrix)
    size = n + 2 * border
    parts = []
    for y, row in enumerate(matrix):
        x = 0
        while x < n:
            if row[x]:
                start = x
                while x < n and row[x]:
                    x += 1
                parts.append(f"M{start + border},{y + border}h{x - start}v1h-{x - start}z")
            else:
                x += 1
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" shape-rendering="crispEdges" '
            f'role="img" aria-label="Check-in QR code"><rect width="{size}" height="{size}" fill="{light}"/>'
            f'<path d="{"".join(parts)}" fill="{dark}"/></svg>')
