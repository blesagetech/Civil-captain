"""Passwords, login sessions, CSRF, rate limiting, audit log and request validation."""
import hashlib
import hmac
import os
import re
import secrets
from functools import wraps

from flask import current_app, g, has_request_context, request

from . import clock
from .db import q, q1, run


class ApiError(Exception):
    def __init__(self, message, status=400, **extra):
        super().__init__(message)
        self.message, self.status, self.extra = message, status, extra


def cfg():
    return current_app.config["CC"]


# ---------------------------------------------------------------- passwords
_SCRYPT = dict(n=2 ** 14, r=8, p=1, dklen=32)
_COMMON = {"password", "password1", "12345678", "123456789", "qwerty123", "admin123", "welcome1",
           "letmein123", "uganda123", "kampala123", "changeme1", "password123"}
_ALPHABET = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def hash_password(pw):
    salt = os.urandom(16)
    digest = hashlib.scrypt(pw.encode(), salt=salt, **_SCRYPT)
    return f"scrypt${salt.hex()}${digest.hex()}"


_DUMMY = hash_password("timing-equaliser")


def verify_password(pw, stored):
    try:
        scheme, salt, digest = stored.split("$")
        if scheme != "scrypt":
            return False
        calc = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), **_SCRYPT)
        return hmac.compare_digest(calc.hex(), digest)
    except (ValueError, TypeError):
        return False


def check_password_strength(pw, username=""):
    if not isinstance(pw, str) or len(pw) < 8:
        raise ApiError("Use at least 8 characters.")
    if len(pw) > 128:
        raise ApiError("That password is too long (128 characters at most).")
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        raise ApiError("Include at least one letter and one number.")
    if pw.lower() in _COMMON or (username and pw.lower() == username.lower()):
        raise ApiError("That password is too easy to guess. Choose another.")


def temp_password():
    while True:
        pw = "".join(secrets.choice(_ALPHABET) for _ in range(10))
        if re.search(r"\d", pw) and re.search(r"[A-Za-z]", pw):
            return pw


# ---------------------------------------------------------------- request info
def client_ip():
    c = cfg()
    xff = request.headers.get("X-Forwarded-For", "")
    if c.TRUST_PROXY and xff:
        parts = [p.strip() for p in xff.split(",") if p.strip()]
        if parts:
            return parts[-c.PROXY_HOPS] if len(parts) >= c.PROXY_HOPS else parts[0]
    return request.remote_addr or ""


def public_origin():
    c = cfg()
    if c.PUBLIC_URL:
        return c.PUBLIC_URL
    if c.TRUST_PROXY:
        proto = request.headers.get("X-Forwarded-Proto", request.scheme).split(",")[0].strip()
        host = request.headers.get("X-Forwarded-Host", request.host).split(",")[0].strip()
    else:
        proto, host = request.scheme, request.host
    return f"{proto}://{host}"


# ---------------------------------------------------------------- sessions
COOKIE = "cc_sid"


def _h(token):
    return hashlib.sha256(token.encode()).hexdigest()


def start_session(user_id):
    token, csrf, t = secrets.token_urlsafe(32), secrets.token_urlsafe(24), clock.now()
    run("DELETE FROM auth_sessions WHERE expires_at < ?", (t,))
    run("INSERT INTO auth_sessions(token_hash,user_id,csrf,created_at,expires_at,last_seen,ip,ua) VALUES (?,?,?,?,?,?,?,?)",
        (_h(token), user_id, csrf, t, t + cfg().SESSION_DAYS * 86400, t, client_ip(),
         (request.user_agent.string or "")[:200]))
    return token, csrf


def set_cookie(resp, token):
    resp.set_cookie(COOKIE, token, max_age=cfg().SESSION_DAYS * 86400, httponly=True,
                    samesite="Lax", secure=cfg().COOKIE_SECURE, path="/")


def clear_cookie(resp):
    resp.delete_cookie(COOKIE, path="/")


def load_session():
    token = request.cookies.get(COOKIE)
    if not token:
        return None, None
    s = q1("SELECT * FROM auth_sessions WHERE token_hash=?", (_h(token),))
    t = clock.now()
    if not s or s["expires_at"] < t:
        return None, None
    u = q1("SELECT * FROM users WHERE id=? AND active=1", (s["user_id"],))
    if not u:
        return None, None
    if t - s["last_seen"] > 3600:
        run("UPDATE auth_sessions SET last_seen=?, expires_at=? WHERE token_hash=?",
            (t, t + cfg().SESSION_DAYS * 86400, s["token_hash"]))
    return u, s


def auth(*roles, pending_pw_ok=False):
    """Require a signed-in user (optionally with one of `roles`). Checks CSRF on writes."""
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            user, sess = load_session()
            if not user:
                raise ApiError("Please sign in.", 401)
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                sent = request.headers.get("X-CSRF-Token", "")
                if not hmac.compare_digest(sent, sess["csrf"]):
                    raise ApiError("Your session check failed. Reload the page and try again.", 403)
            if user["must_change_pw"] and not pending_pw_ok:
                raise ApiError("Choose a new password first.", 403, must_change_pw=True)
            if roles and user["role"] not in roles:
                raise ApiError("You don't have access to this.", 403)
            g.user, g.sess = user, sess
            return fn(*a, **kw)
        return wrapper
    return deco


# ---------------------------------------------------------------- rate limiting (stored in the DB so it works across workers)
def recent_fails(key, window):
    return q1("SELECT COUNT(*) AS c FROM login_attempts WHERE key=? AND at>?", (key, clock.now() - window))["c"]


def add_fail(key):
    run("INSERT INTO login_attempts(key,at) VALUES (?,?)", (key, clock.now()))


def clear_fails(key):
    run("DELETE FROM login_attempts WHERE key=?", (key,))


def purge_attempts():
    run("DELETE FROM login_attempts WHERE at<?", (clock.now() - 86400,))


# ---------------------------------------------------------------- audit
def audit(action, target="", detail="", actor=None):
    u = actor or getattr(g, "user", None)
    run("INSERT INTO audit(at,actor_id,actor_name,action,target,detail,ip) VALUES (?,?,?,?,?,?,?)",
        (clock.now(), u["id"] if u else None, u["username"] if u else "", action,
         str(target)[:100], str(detail)[:500], client_ip() if has_request_context() else ""))


# ---------------------------------------------------------------- scope: who may see whom
def team_scope(me, alias="u"):
    r = me["role"]
    if r == "super_admin":
        return "1=1", []
    if r == "org_admin":
        return f"{alias}.org_id=?", [me["org_id"]]
    if r == "supervisor":
        return f"{alias}.supervisor_id=?", [me["id"]]
    return "0=1", []


def user_in_scope(me, uid):
    sql, args = team_scope(me)
    u = q1(f"SELECT u.* FROM users u WHERE u.id=? AND {sql}", [uid, *args])
    if not u:
        raise ApiError("Person not found.", 404)
    return u


def org_allowed(me, org_id):
    return me["role"] == "super_admin" or (me["org_id"] is not None and me["org_id"] == org_id)


# ---------------------------------------------------------------- input validation
def body():
    d = request.get_json(silent=True)
    if not isinstance(d, dict):
        raise ApiError("Send the request as JSON.", 400)
    return d


def text(d, key, label, maxlen=200, required=True, default=""):
    v = d.get(key, default)
    if v is None:
        v = default
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        v = str(v)
    if not isinstance(v, str):
        raise ApiError(f"{label} is not valid.")
    v = v.strip()
    if required and not v:
        raise ApiError(f"{label} is required.")
    if len(v) > maxlen:
        raise ApiError(f"{label} is too long (max {maxlen} characters).")
    return v


def integer(d, key, label, lo=None, hi=None, default=None):
    v = d.get(key, default)
    if v is None or v == "":
        if default is None:
            raise ApiError(f"{label} is required.")
        return default
    try:
        v = int(v)
    except (TypeError, ValueError):
        raise ApiError(f"{label} must be a whole number.")
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise ApiError(f"{label} must be between {lo} and {hi}.")
    return v


def number(d, key, label, lo, hi, required=False):
    v = d.get(key)
    if v is None or v == "":
        if required:
            raise ApiError(f"{label} is required.")
        return None
    try:
        v = float(v)
    except (TypeError, ValueError):
        raise ApiError(f"{label} must be a number.")
    if not (lo <= v <= hi):
        raise ApiError(f"{label} must be between {lo} and {hi}.")
    return v


def day_text(d, key, label):
    v = text(d, key, label, 10)
    try:
        clock.parse_day(v)
    except ValueError:
        raise ApiError(f"{label} must be a date like 2026-10-31.")
    return v


def choice(d, key, label, options, default=None):
    v = d.get(key, default)
    if v not in options:
        raise ApiError(f"{label} must be one of: {', '.join(options)}.")
    return v


_DEVICE_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


def device_id(d):
    v = d.get("device_id")
    return v if isinstance(v, str) and _DEVICE_RE.match(v) else None
