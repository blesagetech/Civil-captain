"""First-run setup (real use) and demo data (CC_DEMO=1). Demo data is fictional."""
import random
import sqlite3
from datetime import timedelta

from flask import current_app

from . import calc, clock, codes
from .db import db, q1, run
from .security import ApiError, check_password_strength, hash_password, temp_password

DEMO_PASSWORD = "Civil2026"
DEMO_LOGINS = [("admin", "National administrator"), ("hr.mict", "HR officer, MICT"),
               ("sup.mict", "Supervisor, MICT headquarters"), ("sarah.nakato", "Employee, MICT headquarters"),
               ("peter.mugisha", "Employee, Mbarara office")]


def seed_holidays(year):
    for y in (year - 1, year, year + 1):
        for day, name in calc.uganda_holidays(y).items():
            run("INSERT OR IGNORE INTO holidays(day,name) VALUES (?,?)", (day, name))


def create_first_admin(cfg):
    pw = cfg.ADMIN_PASSWORD
    generated = not pw
    if generated:
        pw = temp_password()
    else:
        try:
            check_password_strength(pw, cfg.ADMIN_USERNAME)
        except ApiError as e:
            raise SystemExit(f"CC_ADMIN_PASSWORD is not accepted: {e.message}")
    t = clock.now()
    try:
        run("INSERT INTO users(username,full_name,job_title,role,pw_hash,must_change_pw,start_date,created_at) "
            "VALUES (?,?,?,?,?,1,?,?)", (cfg.ADMIN_USERNAME, "National Administrator", "System administrator", "super_admin",
                                          hash_password(pw), clock.day_of(t, cfg.UTC_OFFSET_MIN), t))
    except sqlite3.IntegrityError:
        return  # another worker created the administrator a moment ago
    seed_holidays(int(clock.day_of(t, cfg.UTC_OFFSET_MIN)[:4]))
    if getattr(cfg, "TESTING", False):
        return
    bar = "=" * 62
    print(f"\n{bar}\n  First run: administrator account created\n  Username: {cfg.ADMIN_USERNAME}"
          + (f"\n  Password: {pw}   (shown once; you must change it at first sign-in)" if generated
             else "\n  Password: the value of CC_ADMIN_PASSWORD (change it at first sign-in)") + f"\n{bar}\n", flush=True)


def seed_demo():
    cfg = current_app.config["CC"]
    off = cfg.UTC_OFFSET_MIN
    rnd = random.Random(2026)
    t = clock.now()
    today = clock.day_of(t, off)
    seed_holidays(int(today[:4]))
    holidays = {r["day"] for r in db().execute("SELECT day FROM holidays").fetchall()}
    pw = hash_password(DEMO_PASSWORD)
    d0 = clock.parse_day(today)

    def day(n):  # n days from today
        return (d0 + timedelta(days=n)).isoformat()

    def recent_workdays(count):  # the last `count` working days before today, newest first
        out, k = [], 0
        while len(out) < count:
            k -= 1
            if clock.parse_day(day(k)).isoweekday() <= 5 and day(k) not in holidays:
                out.append(day(k))
        return out

    db().execute("BEGIN IMMEDIATE")
    if db().execute("SELECT COUNT(*) FROM users").fetchone()[0]:  # another worker got here first
        db().execute("ROLLBACK")
        return
    org = lambda name, code: run("INSERT INTO orgs(name,code,created_at) VALUES (?,?,?)", (name, code, t))
    mict = org("Ministry of ICT and National Guidance", "MICT")
    mlhud = org("Ministry of Lands, Housing and Urban Development", "MLHUD")

    def station(org_id, name, district, lat, lng, geo="off"):
        return run("INSERT INTO stations(org_id,name,district,lat,lng,geo_policy,device_policy,qr_secret,display_key,created_at) "
                   "VALUES (?,?,?,?,?,?,'flag',?,?,?)", (org_id, name, district, lat, lng, geo, codes.new_secret(),
                                                          codes.new_display_key(), t))
    mict_hq = station(mict, "MICT Headquarters", "Kampala", 0.3136, 32.5811)
    mbarara = station(mict, "Mbarara Regional Office", "Mbarara", 0.6071, 30.6545, geo="flag")
    mlhud_hq = station(mlhud, "MLHUD Headquarters", "Kampala", 0.3136, 32.5811)
    gulu = station(mlhud, "Gulu Zonal Land Office", "Gulu", 2.7746, 32.2990)

    start = day(-75)
    people = {}

    def user(username, name, title, role, org_id, st, sup, profile, phone=""):
        uid = run("INSERT INTO users(org_id,station_id,supervisor_id,username,full_name,job_title,phone,role,pw_hash,"
                  "must_change_pw,start_date,created_at) VALUES (?,?,?,?,?,?,?,?,?,0,?,?)",
                  (org_id, st, sup, username, name, title, phone, role, pw, start, t))
        people[username] = {"id": uid, "station": st, "profile": profile}
        return uid

    run("INSERT INTO users(username,full_name,job_title,role,pw_hash,must_change_pw,start_date,created_at) "
        "VALUES ('admin','National Administrator','System administrator','super_admin',?,0,?,?)", (pw, start, t))
    hr_mict = user("hr.mict", "Nabukenya Rose", "HR Officer", "org_admin", mict, mict_hq, None, "reliable", "0772 000 101")
    sup_mict = user("sup.mict", "Ssekandi Moses", "Head, ICT Infrastructure", "supervisor", mict, mict_hq, hr_mict, "reliable")
    sup_mbr = user("sup.mbarara", "Tumwebaze Alex", "Regional ICT Coordinator", "supervisor", mict, mbarara, hr_mict, "reliable")
    for u, n, j, p in [("sarah.nakato", "Nakato Sarah", "ICT Officer", "reliable"),
                       ("james.okello", "Okello James", "Systems Administrator", "average"),
                       ("grace.atim", "Atim Grace", "Network Engineer", "risk"),
                       ("brian.tumusiime", "Tumusiime Brian", "Software Developer", "poor"),
                       ("joan.namuli", "Namuli Joan", "Records Assistant", "reliable"),
                       ("david.ochieng", "Ochieng David", "Data Analyst", "average")]:
        user(u, n, j, "employee", mict, mict_hq, sup_mict, p)
    for u, n, j, p in [("peter.mugisha", "Mugisha Peter", "ICT Support Officer", "average"),
                       ("esther.kyomuhendo", "Kyomuhendo Esther", "Records Officer", "reliable"),
                       ("isaac.byaruhanga", "Byaruhanga Isaac", "Network Technician", "risk")]:
        user(u, n, j, "employee", mict, mbarara, sup_mbr, p)
    hr_mlhud = user("hr.mlhud", "Auma Patricia", "HR Officer", "org_admin", mlhud, mlhud_hq, None, "reliable")
    sup_ml = user("sup.mlhud", "Wasswa Daniel", "Senior Land Officer", "supervisor", mlhud, mlhud_hq, hr_mlhud, "reliable")
    sup_gulu = user("sup.gulu", "Opio Francis", "Zonal Land Officer", "supervisor", mlhud, gulu, hr_mlhud, "reliable")
    for u, n, j, st, sup, p in [("ruth.nansubuga", "Nansubuga Ruth", "Land Registrar", mlhud_hq, sup_ml, "reliable"),
                                ("moses.lubega", "Lubega Moses", "Records Clerk", mlhud_hq, sup_ml, "average"),
                                ("harriet.akello", "Akello Harriet", "Surveyor", gulu, sup_gulu, "average"),
                                ("simon.odong", "Odong Simon", "Land Clerk", gulu, sup_gulu, "risk")]:
        user(u, n, j, "employee", mlhud, st, sup, p)

    # approved leave in the past, plus requests waiting for a decision
    leave_days = {}

    def leave(username, a, b, kind, why, status="approved"):
        p = people[username]
        sup = db().execute("SELECT supervisor_id FROM users WHERE id=?", (p["id"],)).fetchone()[0]
        run("INSERT INTO requests(user_id,kind,leave_type,start_day,end_day,reason,status,decided_by,decided_at,created_at) "
            "VALUES (?,'leave',?,?,?,?,?,?,?,?)", (p["id"], kind, day(a), day(b), why, status,
                                                  sup if status == "approved" else None, t if status == "approved" else None, t))
        if status == "approved":
            for n in range(a, b + 1):
                leave_days.setdefault(username, set()).add(day(n))
    leave("esther.kyomuhendo", -20, -16, "annual", "Annual leave")
    leave("ruth.nansubuga", -9, -8, "sick", "Clinic visit and recovery")
    leave("sarah.nakato", 7, 8, "annual", "Family matter", status="pending")

    corr_day, remote_day, past = recent_workdays(3)
    run("INSERT INTO requests(user_id,kind,start_day,end_day,claim_in,claim_out,reason,created_at) VALUES (?,?,?,?,?,?,?,?)",
        (people["grace.atim"]["id"], "correction", corr_day, corr_day, "08:05", "17:10",
         "My phone battery died and I could not check in. I was at my desk all day.", t))

    TIMES = {"reliable": 0.97, "average": 0.88, "risk": 0.72, "poor": 0.58}
    late_rate = {"reliable": 0.08, "average": 0.18, "risk": 0.28, "poor": 0.3}
    ws = 8 * 60
    d = clock.parse_day(start)
    yesterday = clock.parse_day(day(-1))
    while d <= yesterday:
        ds = d.isoformat()
        if d.isoweekday() <= 5 and ds not in holidays:
            for username, p in people.items():
                if ds in leave_days.get(username, ()) or (username, ds) in {("grace.atim", corr_day), ("brian.tumusiime", remote_day)}:
                    continue
                if rnd.random() >= TIMES[p["profile"]]:
                    continue
                late = rnd.random() < late_rate[p["profile"]]
                in_min = rnd.randint(ws + 16, ws + 85) if late else rnd.randint(ws - 25, ws + 14)
                out_min = rnd.randint(16 * 60 + 50, 18 * 60 + 10)
                miss = rnd.random() < 0.03
                run("INSERT INTO attendance(user_id,station_id,day,check_in,check_out,method,status,flags,review,created_at) "
                    "VALUES (?,?,?,?,?,?,?,'','ok',?)",
                    (p["id"], p["station"], ds, clock.to_ts(ds, f"{in_min // 60:02d}:{in_min % 60:02d}", off),
                     None if miss else clock.to_ts(ds, f"{out_min // 60:02d}:{out_min % 60:02d}", off), "qr",
                     "late" if late else "present", t))
        d += timedelta(days=1)

    # a few records waiting in the supervisors' review queue
    for username, flag, dist, n in [("peter.mugisha", "geo_outside", 1850, 2), ("james.okello", "new_device", None, 1)]:
        run("UPDATE attendance SET flags=?, review='pending', distance_m=? WHERE id IN "
            "(SELECT id FROM attendance WHERE user_id=? ORDER BY day DESC LIMIT ?)", (flag, dist, people[username]["id"], n))

    def session(org_id, st, title, kind, s_ts, e_ts, by):
        return run("INSERT INTO online_sessions(org_id,station_id,title,kind,starts_at,ends_at,min_pct,created_by,created_at) "
                   "VALUES (?,?,?,?,?,?,75,?,?)", (org_id, st, title, kind, s_ts, e_ts, by, t))

    def joined(sid, username, s_ts, e_ts, share):
        secs = int((e_ts - s_ts) * share)
        run("INSERT INTO online_attendance(session_id,user_id,first_join,last_beat,seconds) VALUES (?,?,?,?,?)",
            (sid, people[username]["id"], s_ts, e_ts, secs))

    s_ts, e_ts = clock.to_ts(remote_day, "08:00", off), clock.to_ts(remote_day, "17:00", off)
    rid = session(mict, mict_hq, "Remote duty: field assignment", "remote_duty", s_ts, e_ts, sup_mict)
    joined(rid, "brian.tumusiime", s_ts, e_ts, 0.93)
    s_ts, e_ts = clock.to_ts(past, "10:00", off), clock.to_ts(past, "12:00", off)
    tid = session(mlhud, None, "Digital land registry training", "training", s_ts, e_ts, sup_ml)
    for username, share in (("ruth.nansubuga", 0.98), ("moses.lubega", 0.62), ("harriet.akello", 0.85), ("simon.odong", 0.4)):
        joined(tid, username, s_ts, e_ts, share)
    session(mict, None, "Weekly staff meeting", "meeting", t - 600, t + 3000, sup_mict)  # live right now
    tomorrow = day(1)
    session(mict, mict_hq, "Cybersecurity awareness session", "training", clock.to_ts(tomorrow, "10:00", off),
            clock.to_ts(tomorrow, "12:00", off), hr_mict)
    run("INSERT INTO audit(at,actor_id,actor_name,action,detail) VALUES (?,NULL,'system','demo_seeded','Fictional demo data')", (t,))
    db().execute("COMMIT")
    print(f"\n  Demo data created. Every demo account uses the password: {DEMO_PASSWORD}\n", flush=True)
