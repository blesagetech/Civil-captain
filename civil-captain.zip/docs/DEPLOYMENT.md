# Deployment guide

Civil Captain is one small web application plus one database file. That makes it easy to host almost anywhere. This guide covers a demo, a pilot server, and what to plan for a national roll-out.

> Everything in the application itself (server, web pages, tests) was run and tested. The Docker and hosting files below are written carefully but could **not** be run in the environment this project was built in, so treat your first deployment as a rehearsal and read the logs.

## 1. Settings

Settings are environment variables. You can also put them in a file called `.env` next to `run.py` (copy `.env.example`). Real environment variables override the file.

| Setting | Default | Meaning |
|---|---|---|
| `CC_PUBLIC_URL` | (empty) | The public address with `https://`, for example `https://attendance.example.go.ug`. **Set this in production** so the QR codes link to the right place and cookies are marked *Secure*. |
| `CC_TRUST_PROXY` | off | Set to `1` only when a reverse proxy you control sits in front of the app. It lets the app see each person's real internet address (needed for the network rule and sign-in rate limits). If it is on without a proxy, people could fake their address. |
| `CC_PROXY_HOPS` | `1` | How many proxies are in front of the app. |
| `CC_DB_PATH` | `data/civilcaptain.db` | Where the database lives. Put it on a disk that survives restarts. |
| `CC_ADMIN_USERNAME` | `admin` | First-run national administrator. |
| `CC_ADMIN_PASSWORD` | random | First-run password. If empty, a random one is printed once in the server log. It must be changed at first sign-in either way. |
| `CC_SESSION_DAYS` | `14` | Days a phone stays signed in after last use. |
| `CC_UTC_OFFSET_MIN` | `180` | Minutes ahead of UTC (Uganda is UTC+3 all year). |
| `CC_APP_NAME` | `Civil Captain` | Name shown on screens. |
| `CC_DEMO` | off | Fill an empty database with fictional demo data. **Never on a real system.** |

## 2. The demo (GitHub Codespaces)

See the README. It uses the built-in development server, which is fine for a demonstration and not for real use.

## 3. A pilot server with Docker (recommended)

You need a Linux server (a small one is enough to start: 1 CPU, 1 GB of memory), a domain name pointing at it, and Docker with Compose installed.

```bash
# 1. put the project on the server (git clone, or upload the zip and unzip it)
cd civil-captain

# 2. choose your settings
cp .env.example .env
nano .env        # set CC_PUBLIC_URL=https://attendance.example.go.ug and CC_TRUST_PROXY=1

# 3. start it
docker compose up -d --build

# 4. read the first-run administrator password
docker compose logs civil-captain | grep -A3 "First run"
```

The app now listens on port 8000 **inside** the server. Put HTTPS in front of it (next section). People must never reach port 8000 over plain http.

### HTTPS with Caddy (easiest)

Caddy gets and renews free certificates by itself. Install Caddy on the same server and use this `/etc/caddy/Caddyfile`:

```
attendance.example.go.ug {
    reverse_proxy 127.0.0.1:8000
}
```

Then `sudo systemctl reload caddy`. Make sure `CC_TRUST_PROXY=1` and `CC_PUBLIC_URL=https://attendance.example.go.ug` are set. Government sites usually need a certificate from the organisation's own process. In that case use whatever reverse proxy your IT team already runs (Nginx or Apache) and pass these headers: `X-Forwarded-For`, `X-Forwarded-Proto`, `Host`.

### Hosting platforms that run a `Procfile`

The included `Procfile` works on platforms that support it. Two cautions:

* **The database must be on a persistent disk.** Many free tiers wipe the disk on every restart, which would delete all attendance. Check your platform's persistent storage options and point `CC_DB_PATH` at it.
* Use only one app instance (or one machine) with SQLite.

### Without Docker

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
gunicorn wsgi:app --bind 127.0.0.1:8000 --workers 2 --worker-class gthread --threads 8
```

Run it under `systemd` so it restarts if the server reboots.

## 4. Backups and restore (do this before real use)

Attendance records are official records. Back them up every day and test a restore.

```bash
# safe while the app is running (uses SQLite's backup feature)
python manage.py backup /backups/civil-captain-$(date +%F).db

# with Docker
docker compose exec civil-captain python manage.py backup /data/backup-$(date +%F).db
```

Copy backups to a different machine or storage. To restore: stop the app, replace `civilcaptain.db` with the backup, delete any `civilcaptain.db-wal` and `civilcaptain.db-shm` files next to it, start the app.

Locked out? An administrator forgot the password: `python manage.py reset-password admin` prints a temporary one.

## 5. Updating

1. Back up the database.
2. Replace the code (git pull, or unzip the new version over the old one, keeping the `data/` folder and `.env`).
3. `docker compose up -d --build` (or restart gunicorn).
4. Open `https://your-site/healthz`. It should say `{"status":"ok"}`.

The database structure is created automatically on first start. A later version that changes it will include migration notes.

## 6. Monitoring

* `GET /healthz` returns `ok` when the app and database respond. Point any uptime checker at it.
* Logs go to the console (`docker compose logs -f`). Keep them for at least 90 days.
* Watch free disk space. The database grows by a few megabytes per thousand staff per month.

## 7. Sizing and growing

* A small server comfortably runs a pilot of a few thousand staff. The busiest moment is the 08:00 rush: a check-in is one small write, so even hundreds per minute are fine on SQLite.
* Passwords are hashed slowly on purpose (about 60 ms of CPU per sign-in). If many thousands of people sign in at the same minute, add CPU and workers. Staying signed in for 14 days keeps this rare.
* **For a national roll-out** (tens or hundreds of thousands of staff, several servers) plan to move the data to **PostgreSQL**. All database access goes through a small set of functions in `app/db.py` and plain SQL in `app/logic.py` and `app/api/`, so the move is a contained piece of work. Do not run several servers against one SQLite file.
* Behind a load balancer, set `CC_TRUST_PROXY=1` and the right `CC_PROXY_HOPS`.

## 8. Before real staff use it

Work through [`GO_LIVE_CHECKLIST.md`](GO_LIVE_CHECKLIST.md). In particular: HTTPS on, `CC_DEMO` off, default passwords changed, daily backups tested, and a privacy notice given to staff.
