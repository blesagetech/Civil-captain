# Go-live checklist

The conditions to meet **before** real staff use Civil Captain. Tick each box with a date and a name. Items marked **(blocker)** should stop the launch if they are not done.

> This is a practical checklist, not legal advice. Have a lawyer or the ministry's legal officer confirm the legal items for your situation.

## 1. Mandate and approvals

- [ ] **(blocker)** A named sponsor (a commissioner, permanent secretary, HR director or similar) has approved a **pilot** in writing, with a start date, an end date and success measures (section 8).
- [ ] The pilot office, its head, and its HR officer have agreed to take part.
- [ ] You have asked the national IT authority (NITA-U) and the Ministry of Public Service what approvals, standards or hosting rules apply to a government system, and written down the answers.
- [ ] Public service rules on attendance and discipline have been read. HR agrees how "below 75%" will be handled in practice (the system only flags; people decide).
- [ ] Staff representatives or unions have been told what the system records and how it will be used.

## 2. Law and privacy (Data Protection and Privacy Act, 2019)

- [ ] **(blocker)** Someone is named as responsible for personal data (the "data controller") and for this system's day-to-day privacy.
- [ ] You have checked whether the organisation and the system must be **registered with the Personal Data Protection Office** (under NITA-U) and, if so, it is done.
- [ ] A short **privacy notice** has been given to every user (a template is in [`SECURITY_AND_PRIVACY.md`](SECURITY_AND_PRIVACY.md)). It says what is collected (name, job title, check-in times, and location only at check-in for offices that use the location rule), why, who sees it, how long it is kept.
- [ ] A **data protection impact assessment** (or the organisation's equivalent risk review) has been done and signed.
- [ ] A **retention period** has been decided (for example: keep attendance records for the period the public service requires, then archive or delete) and the person who will do it is named.
- [ ] You know where the data is stored (country, provider). Government data hosting rules have been checked.
- [ ] There is a process for staff to **ask for their data to be corrected** (the correction request in the app, plus HR).
- [ ] A **breach response plan** exists: who is told, how fast, and who tells the regulator and staff.

## 3. Security

- [ ] **(blocker)** The site runs only over **HTTPS**, and `CC_PUBLIC_URL` is set to the https address.
- [ ] **(blocker)** `CC_DEMO` is **off** and no demo data or demo accounts exist (check the People page).
- [ ] **(blocker)** The first administrator password has been changed and is stored in a password manager, not on paper or chat.
- [ ] Every administrator and HR officer has their **own** account. Nobody shares the national account.
- [ ] `CC_TRUST_PROXY` is on only if a proxy really sits in front, and the number of proxies (`CC_PROXY_HOPS`) is right. Test on a practice office with the network rule set to *review*: a check-in from the office Wi-Fi is clean, one from mobile data is flagged *Not on the office network*.
- [ ] The server is patched, has a firewall allowing only 80/443 and administration from known addresses, and no one outside IT has shell access.
- [ ] The database file and backups are readable only by the service account.
- [ ] An independent person has tried to break it (a basic penetration test, or at minimum the checks in section 6). Findings are fixed or accepted in writing.
- [ ] The reception "TV link" is shared only with the person who sets up the screen, and you know how to change it (Offices > edit the office > *Change the TV link and code secret*).
- [ ] Staff know the rules: never share your password; never forward the QR; report a lost phone to HR at once so the password can be reset (this signs the phone out everywhere).

## 4. Data and hosting

- [ ] **(blocker)** **Daily backups** run automatically, are copied off the server, and a **restore has been tested** on another machine.
- [ ] Disk space alarms are set. Someone checks the uptime monitor (`/healthz`).
- [ ] The people list is ready: username, full name, job title, office, supervisor, start date. Staff are imported with the CSV importer and the temporary passwords are handed out privately (never by group chat).
- [ ] Each person has a **supervisor** chosen. Without one, nobody sees that person's attendance.
- [ ] Every office has its **working hours, grace minutes and working days** correct, and its **QR rotation** chosen.
- [ ] Public holidays for the year are loaded, including Eid dates once announced.

## 5. Office readiness

- [ ] Each pilot office has a **screen** at reception (a TV, tablet or old laptop) that stays on during working hours and shows the code page in full screen.
- [ ] The screen has stable internet. If the office internet is unreliable, the supervisor knows the fallback: enter the day by hand (the person's page > *Enter attendance by hand*) or staff send a correction request.
- [ ] If you use the **location rule**: the office position was set while standing at the entrance (Offices > edit > *Use my position now*) and the allowed distance was tested from inside and outside the building.
- [ ] If you use the **network rule**: the office internet address was added, and you confirmed staff do **not** check in over mobile data.
- [ ] Rules start gentle: **phone = review, location = review, network = off.** Tighten to *refuse* only after a few weeks of clean data.

## 6. Technical acceptance tests

Run these on real phones before the pilot and write down pass/fail.

| # | Test | Pass |
|---|---|---|
| 1 | New person receives a temporary password, signs in, is forced to choose a new password | [ ] |
| 2 | Scan the reception QR with the **default camera** on Android and on iPhone: check-in works | [ ] |
| 3 | Same on a **signed-out** phone: sign in, then the check-in continues | [ ] |
| 4 | Type the 6-digit code instead: works. Type a wrong code 8 times: blocked for a few minutes | [ ] |
| 5 | Use an **old photo** of the QR after the rotation time: refused | [ ] |
| 6 | Check in a second time on the same day: refused with a clear message | [ ] |
| 7 | Arrive after opening plus grace: marked **late** | [ ] |
| 8 | Check out within a minute: refused; later: works | [ ] |
| 9 | Location rule: check in from outside the allowed distance: refused or sent to review (as configured) | [ ] |
| 10 | Phone rule: sign in on a second phone: flagged. Supervisor approves it in **Review**: next check-in is clean | [ ] |
| 11 | Leave: request, approve, see those days stop counting; reject another and see it still counts | [ ] |
| 12 | Correction request approved: the day appears as attended | [ ] |
| 13 | Reject a flagged check-in: the percentage drops accordingly | [ ] |
| 14 | A supervisor cannot see people who are not on their team. HR cannot see another ministry | [ ] |
| 15 | The attendance percentage shown to a person matches a hand calculation for that person | [ ] |
| 16 | Reports download and open correctly in Excel (names with accents, no broken columns) | [ ] |
| 17 | Online session: join, keep the page open, see the time count up; close the page for 3 minutes, see the gap not counted | [ ] |
| 18 | Back up, delete the test database, restore, and confirm everything is back | [ ] |
| 19 | Sign out, then use the browser Back button: no data is shown | [ ] |
| 20 | The site works on the slowest phone and network used in the pilot office | [ ] |

Also run the automated tests (`python -m unittest discover -s tests`). All must pass.

## 7. People and change management

- [ ] A one-page **how to check in** guide with screenshots has been printed for the office and shared digitally ([`USER_GUIDE.md`](USER_GUIDE.md) has the text).
- [ ] A short training session (30 minutes) was held for all pilot staff, and a longer one (1 hour) for supervisors and HR.
- [ ] A **help person** is named in each office for the first two weeks, plus a support phone number or chat for problems.
- [ ] Staff without a smartphone have a fallback agreed (for example a shared office phone or tablet, or supervisor entry).
- [ ] The first week is a **soft launch**: the system records, nobody is penalised, and issues are fixed daily.
- [ ] Supervisors know that flagged check-ins are a **prompt to ask**, not proof of cheating.

## 8. Pilot plan and success measures

Suggested shape (adjust to your sponsor's wishes):

| Phase | Length | What |
|---|---|---|
| 0. Rehearsal | 1 week | Team of volunteers; finish the acceptance tests |
| 1. One office | 4 weeks | All staff of one office; soft launch in week 1 |
| 2. One ministry | 8 weeks | Add offices; review rules and settings |
| 3. Report | 2 weeks | Results to the sponsor; decide whether to expand |

Decide in advance what "it works" means. Suggestions:

- [ ] At least 95% of check-ins succeed first time.
- [ ] Median time to check in is under 20 seconds.
- [ ] Fewer than 5% of check-ins are flagged after the first two weeks.
- [ ] Supervisors clear the **Review** queue within 2 working days.
- [ ] Records match a manual spot check of the register in at least 95% of sampled days.
- [ ] Uptime is at least 99% during working hours.
- [ ] Staff satisfaction survey: most people say it is easier than the old way.
- [ ] Total cost per person is known (see the project brief) and lower than the alternative.

## 9. Operations after launch

- [ ] Someone owns **support**, **backups**, **updates** and **user accounts** (new joiners, leavers, transfers). Leavers must be deactivated the day they leave (People page > the person > untick *active*).
- [ ] Monthly: HR reviews the below-minimum list and the activity log.
- [ ] Quarterly: restore test, security update, review of rules and flagged-event patterns.
- [ ] A **rollback plan** exists: if the system fails, offices go back to the paper register that day and supervisors enter the days afterwards.
- [ ] There is a **change process**: who approves a change of rules (for example moving from *review* to *refuse*).

## 10. Final sign-off

| Role | Name | Date | Signature |
|---|---|---|---|
| System owner | | | |
| Data protection lead | | | |
| IT / security | | | |
| HR lead | | | |
| Pilot office head | | | |
