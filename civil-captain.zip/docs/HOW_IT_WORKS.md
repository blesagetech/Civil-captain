# How Civil Captain works

## The idea, borrowed from a university

| A university does this | Civil Captain does this for government staff |
|---|---|
| Lecturer shares a QR code that changes every 5 minutes | The reception screen shows a QR code that changes every 5 minutes (you can choose 1, 2, 5 or 10) |
| Staff email only works from inside the campus | Optional **network rule**: check in only from the office internet |
| Online classes track how long a student stayed | **Online sessions** track minutes attended for remote duty, meetings and training |
| The portal always shows the attendance percentage | Every person sees their percentage and what they still need to reach the minimum |
| Below 75%: not allowed to sit the exam | Below 75%: flagged for HR and listed on the **payroll-eligibility report**. Nothing is stopped automatically |

## Who uses it

| Role | Sees | Can do |
|---|---|---|
| **Employee** | Their own attendance only | Check in and out, request leave, correct a day, join online sessions |
| **Supervisor** | The people assigned to them as supervisor | Everything above, plus review flagged check-ins, decide requests, approve phones, enter attendance by hand, plan online sessions, show the reception screen |
| **HR administrator** | Everyone in their ministry or agency | Everything a supervisor can for anyone in the organisation, plus manage people, offices, reports, activity log |
| **National administrator** | Everything | Everything, plus ministries, public holidays, the national minimum |

A supervisor only sees the people who have that supervisor chosen on their record. HR sets this when adding a person or importing a spreadsheet.

## A normal day

1. Staff arrive. A screen at reception shows the QR code and a 6-digit code (supervisors open **Screen**, or HR opens the TV link on a dedicated screen).
2. A person points their phone camera at the QR. The link opens Civil Captain (they sign in once, and the phone remembers them for 14 days). They tap **Confirm check-in**.
3. The server checks the code, then the office's rules (below), then records the time. Anyone arriving more than the grace period (default 15 minutes) after opening is marked **late**. Late still counts as attended; it is shown so supervisors can see patterns.
4. When leaving they tap **Check out**.
5. Supervisors see the team list update. Anything unusual waits in **Review**.

If the camera will not scan, type the 6-digit code under the QR instead.

## The rotating code

Each office has its own secret. In every time window (5 minutes by default) the screen shows:

* a QR code containing a link ending in `/c/<token>`, and
* a 6-digit code.

Both are signed with the office secret, so they cannot be guessed or prepared in advance. The previous code still works for 20 seconds after a change, so nobody is unlucky at the moment of rotation. A photo of the screen is useless a few minutes later. Entering a wrong or expired code 8 times within 10 minutes pauses check-in for that person for a few minutes, so the 6-digit code cannot be guessed.

The screen needs no sign-in when opened with the **TV link** (an unguessable address). Anyone holding that link can see the live code, so share it only inside the office and change it from **Offices** if it leaks.

## The office rules (honesty checks)

Each office has three optional rules. Each rule can be **Off**, **Allow but send to the supervisor to review**, or **Refuse the check-in**.

| Rule | What it checks | Good setting to start with |
|---|---|---|
| **Phone** | Each person is tied to their own phone. The first phone is trusted. A different phone, or one phone used by two people on the same day, is caught | *Review* |
| **Location** | The phone's location is read once at check-in and compared with the office position and allowed distance | *Review* at first, *Refuse* once you trust it |
| **Network** | The check-in must come from the office internet address | *Off* unless the office has its own fixed internet connection. It fails for staff on mobile data |

* A **reviewed** check-in counts as attended straight away so staff are not punished for slow reviews. If the supervisor does **not accept** it, it stops counting.
* Location is only stored for offices that switch the location rule on. Offices that leave it off throw the location away.
* Phone checks use a random ID kept in the browser. A person can clear it, but then the phone looks new and is caught by the rule.

## Attendance and the 75% minimum

For each person and each day, one of these applies:

| Day type | Counts as expected? |
|---|---|
| A working day for their office with no holiday and no approved leave | **Yes** |
| Weekend or non-working day, public holiday, approved leave, or before their first day | No |

A person has **attended** an expected day when they have an accepted check-in (late is fine) or took part in a remote-duty session for long enough.

**Attendance % = days attended ÷ days expected**, counting only days that are over. Today counts once the person has checked in, or after the office closes.

### Example: October 2026

October has 22 weekdays, minus 9 October (Independence Day) = **21 expected days**. For 75% a person needs 75% × 21 = 15.75, so **16 days**.

After the first 8 working days Nakato has attended 6. The screen says: *"Attend at least 10 of the next 15 working days to reach 75%."* Once she has 16 attended days it says she has *secured* the minimum for the month. If she can no longer reach it, the screen says so and HR sees her on the month-end report.

The minimum (default 75%) is set nationally. The check is done with whole numbers, so exactly 15 of 20 days (75.0%) meets the minimum and 14 of 20 does not.

### What happens below the minimum

Nothing happens automatically. The person sees a clear message, the supervisor and HR see them marked *Below minimum*, and the **payroll eligibility** download lists them for HR to review before payroll is approved. The decision stays with people.

## Leave, corrections and manual entries

* **Leave**: a person requests dates and a type. When the supervisor approves, those days stop counting as expected days. Overlapping requests are refused.
* **Correction**: for a day someone was at work but could not check in (dead battery, no data). They enter the arrival and departure times and a reason. When the supervisor approves, a record is created and marked *correction*.
* **Entered by hand**: a supervisor or HR can enter a day directly (for example during an office network outage). A reason is required and the entry is written to the activity log under their name.
* **Public holidays**: kept by the national administrator. Easter holidays are calculated; Eid dates follow the moon, so they are added when announced.

## Online sessions and remote duty

A supervisor plans a session (title, type, date, times, minimum share, optional meeting link) for a whole organisation or one office. While a person keeps the session page open, a signal is sent every 30 seconds and their time is counted. A gap of more than 75 seconds is not counted, and sending signals faster earns nothing extra.

* **Meeting** and **training**: reported as *reached the minimum* or *below*.
* **Remote duty**: if someone reaches the minimum, that day counts as attended even without an office check-in. Use it for field work or working from home.

This proves the session page was open, not that the person was listening. The page also asks the phone to keep its screen awake.

## Reports and records

* **Team today**: counts and a list, worst problems first.
* **Reports**: a summary for any period, every individual check-in, and payroll eligibility for a month. All three download as CSV files that open in Excel.
* **Activity log**: user changes, password resets, decisions, report downloads. It cannot be edited from the app.

## What it cannot do

Being honest about this is part of doing it well.

| Possible cheat | What stops it | What remains |
|---|---|---|
| Photographing the QR and sending it to a colleague at home | Code changes every few minutes. Phone rule catches a new phone. Location and network rules catch someone who is not at the office | A colleague inside the office can still send a live photo to someone just outside, within minutes. The location rule makes this hard; a short rotation (1 minute) makes it harder |
| Sharing a phone or password | Phone rule flags a phone used by two people the same day | Two people who deliberately share one phone every day on different days |
| Faking GPS with a "mock location" app | Combined with the other rules, a faker still needs a valid live code and the right phone | A determined technical person can fake GPS on their own phone. A web page cannot detect it reliably |
| Hiring someone to check in with your phone | Nothing in software can tell | This needs people-level controls: spot checks and supervisors who know their team |
| Office internet or electricity down | Supervisors can enter the day by hand, or staff send a correction | Entries by hand are only as honest as the supervisor, which is why they are logged |

Software-only attendance is **cheaper and easier to roll out** than biometric devices, but it is **not as hard to cheat** as a fingerprint reader that is watched by a guard. The design therefore flags suspicious patterns for human review instead of pretending to be perfect. Use it with supervisors who care, and with spot checks.

Other known limits:

* QR codes are read by the phone's own camera app. The in-app camera scanner works only in browsers that support it (Chrome on Android); typing the code always works.
* The app needs internet at the moment of check-in. There is no offline queue in this version.
* A person who changes phone needs a supervisor to approve the new phone (if the office uses the phone rule).
* Working-day logic assumes people work within one calendar day (no night shifts across midnight).
* One office per person (they can check in at other offices of their own organisation).
* SQLite is the database. Plan a move to PostgreSQL before a very large roll-out.
