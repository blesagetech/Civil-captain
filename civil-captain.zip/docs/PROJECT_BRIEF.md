# Project brief: Civil Captain

*A one-page summary you can adapt for a sponsor, a competition panel or a funder. Fill in the bracketed parts with real figures; none are guessed here.*

## The problem

Government needs to know that staff are at work, consistently. Past attempts that relied on biometric fingerprint devices struggled because the hardware is expensive to buy, install, power, connect and maintain in every office, especially outside the capital. Where devices fail, there is no record at all, and paper registers are easy to fill in afterwards.

## The idea

Use what already works elsewhere: a university tracks attendance with a QR code that changes every few minutes for people in the room, tracks time spent for people online, shows every person their attendance percentage, and enforces a 75% minimum.

**Civil Captain** applies the same pattern to government offices:

* A screen at reception shows a QR code that changes every few minutes.
* Staff check in with the phone they already own.
* Optional checks (one phone per person, office location, office internet) flag suspicious check-ins for a supervisor. Nothing suspicious is silently accepted and nothing is silently refused unless the office chooses to.
* Everyone sees their attendance percentage and what they still need to reach the minimum. Supervisors see their team. HR sees who is below the minimum and downloads a payroll-eligibility list. People, not the software, make the decisions.
* Online sessions and remote duty are tracked by minutes attended.

## What exists today

A working system, tested end to end:

* Staff, supervisor, HR and national-administrator screens that work on a phone.
* Rotating QR and 6-digit codes, a reception screen that fits a TV or tablet, and the three optional honesty checks.
* Leave, corrections, public holidays, online sessions, review queues, CSV reports, activity log.
* 49 automated tests, plus browser tests of the main journeys. Deployment files for Docker.

It is a **pilot-ready** system, not yet a national platform (see the roadmap).

## Why software instead of hardware

| | Biometric devices | Civil Captain |
|---|---|---|
| Equipment per office | Device(s) to buy, install, connect, power | One existing screen or tablet |
| Staff equipment | None | A smartphone they already have (supervisor entry or a shared phone as fallback) |
| Maintenance | Repairs, replacement, vendor contracts | One central application |
| Rollout to a new office | Shipping and installing | Create the office and import its staff |
| Cheating | Hard (but buddy-punching and sensor spoofing exist) | Harder than a paper register, easier than fingerprints; mitigated by rotation, checks, and flags for human review |
| Failure | No record when a device is down | Supervisor entry and corrections keep the record |

**Cost comparison to complete for your case**

```
Biometric:   [number of offices] × [devices per office] × [price per device]
           + [installation and connectivity per office] × [number of offices]
           + [yearly maintenance and replacement]

Civil Captain: [hosting per year]
             + [support staff time per year]
             + [one screen or tablet per office, if none exists]
             + [training time]
```

Add up three years for each and divide by the number of staff.

## Pilot proposal

| Phase | Length | Scope |
|---|---|---|
| Rehearsal | 1 week | Volunteers, acceptance tests |
| One office | 4 weeks | All staff of one office |
| One ministry | 8 weeks | Several offices, rules tuned |
| Report | 2 weeks | Results and decision |

**Success measures:** at least 95% of check-ins succeed first time; median check-in under 20 seconds; fewer than 5% of check-ins flagged after two weeks; records match a manual spot check on at least 95% of sampled days; at least 99% availability in working hours; staff say it is easier than the old way; cost per person known and lower than the alternative.

## What the pilot needs from the ministry

* A named sponsor and a pilot office with a motivated head.
* The staff list (name, job title, office, supervisor, start date).
* A screen or tablet and stable internet at reception.
* Approval to host the system (an agreed hosting location and domain name) and a privacy notice to staff.
* A person in HR to own the day-to-day administration.

## Risks and how they are handled

| Risk | Handling |
|---|---|
| Staff cheat | Rotation, honesty checks, review queue, supervisor spot checks. Be honest that no software is perfect. |
| Privacy concerns | No biometrics; location read only at check-in and only where enabled; staff notice; retention decided up front; activity log |
| Poor connectivity | Check-in needs internet for a few seconds; supervisor entry and correction requests as fallback; offline queue on the roadmap |
| Staff without smartphones | Shared office tablet or supervisor entry |
| One system failure stops everyone | Backups tested, rollback to paper for the day, uptime monitor |
| Resistance to change | Soft launch, training, a help person in each office, supervisors trusted to decide |

## Roadmap (not yet built)

1. Offline check-in queue for weak connectivity.
2. Move to PostgreSQL and horizontal scaling for national use.
3. Two-factor sign-in for administrators.
4. Export or connection to the government's payroll and HR systems (ask the Ministry of Public Service which applies).
5. SMS or email reminders and password reset by message.
6. Shift patterns and night shifts, part-time and half-day rules.
7. Translations (for example Luganda, Swahili).
8. Retention and anonymisation tools.
9. Optional extra proof such as office NFC tags or Bluetooth beacons.

## Who to contact

[Name, role, phone, email]
