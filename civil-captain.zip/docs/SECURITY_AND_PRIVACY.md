# Security and privacy

This page lists what the system does to protect people and data, exactly what data it keeps, a privacy notice you can adapt, and the gaps you should know about. It is not legal advice.

## Controls built into the application

| Area | What is done |
|---|---|
| **Passwords** | Stored only as salted *scrypt* hashes, never in readable form. At least 8 characters with a letter and a number; very common passwords refused. Temporary passwords (new accounts, HR resets) must be changed at first sign-in. |
| **Sign-in** | 5 wrong passwords for one username locks sign-in for that username for 15 minutes; 40 failures from one internet address do the same for that address. Unknown usernames take as long as real ones, so nobody can discover which usernames exist. |
| **Sessions** | A random 256-bit token in a cookie that scripts cannot read (*HttpOnly*), *SameSite=Lax*, and *Secure* when the site is on https. Only a hash of the token is stored on the server. Sessions end when the password changes or is reset and when an account is deactivated. |
| **Forged requests (CSRF)** | Every change must carry a per-session secret header and be sent as JSON. Pages on other websites cannot do this. |
| **Access control** | Every request is checked on the server for role **and** scope (a supervisor reaches only their own team, HR only their own organisation). The browser is never trusted. Automated tests cover this. |
| **Injection and scripts** | All database queries use parameters. All text shown on screens is escaped. A strict content security policy forbids inline scripts, other websites' scripts and framing. |
| **Spreadsheet safety** | Exported CSV cells that start with `=`, `+`, `-` or `@` are defused so a malicious name cannot run as a formula in Excel. |
| **The QR code** | Signed with HMAC-SHA256 using a secret unique to each office, valid for one short time window plus a 20-second grace. Wrong guesses of the 6-digit code are rate-limited. Comparisons are constant-time. |
| **Activity log** | Sign-in failures, account changes, password resets, decisions on requests and check-ins, manual entries, report downloads, office changes. Not editable from the app. |
| **Data minimisation** | No biometrics. Location is read once at check-in or check-out, and kept only for offices that switch the location rule on. Location is never tracked between check-ins. |
| **Headers** | `Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` and (on https) `Strict-Transport-Security`. API responses are marked `no-store`. |
| **Concurrency** | Starting several server processes at once is safe; double check-ins are blocked by the database itself. |

## What data is kept

| Data | Why | Who can see it |
|---|---|---|
| Name, username, job title, phone, email, role, office, supervisor, first day, last sign-in | To run the system | The person, their supervisor, HR of their organisation, national administrator |
| Password hash | Sign-in | Nobody (not even administrators) can read a password |
| Attendance: date, check-in and check-out time, on time or late, how it was recorded, review state, flags, notes | The purpose of the system | The person, their supervisor, HR, national administrator |
| Internet address at check-in | The network rule and investigating abuse | Kept in the database; not shown on screens or in downloads |
| Phone label (browser and phone type) and a hash of a random phone ID | The phone rule | Supervisors and HR (the label); the hash is not shown |
| Location and distance from office | The location rule, only for offices that use it | Supervisors and HR see the distance, and the data is in the database |
| Leave and correction requests and the reasons given | To decide them | The person, their supervisor, HR |
| Online session time | Online attendance | The person, planners of the session, HR |
| Activity log, sign-in sessions (address, browser) | Accountability and security | HR (their organisation), national administrator |

**Advice for staff: do not write medical details in leave reasons.** Write "sick leave", not the illness. Health information is sensitive personal data.

### Retention

Decide how long records are kept and write it down (see the go-live checklist). This version has **no automatic deletion tool**; the database is one SQLite file you control. Before long-term use, agree a schedule and either add a retention job or archive and remove old rows with a reviewed script. Failed-sign-in counters are cleared automatically after a day and expired sign-in sessions are removed whenever someone signs in.

## Privacy notice (template)

> **How we record your attendance**
>
> Your office uses *Civil Captain* to record when you arrive and leave work. This replaces the paper register and fingerprint machines.
>
> **What we record:** your name, job title, office, and the time you check in and out. The system also records which phone you used and your internet address. If your office uses the location rule, your phone's location is read **once** at the moment you check in or out, to confirm you are at the office. It is never tracked at other times.
>
> **Why:** to calculate your attendance, to help your supervisor and HR office manage the team and to prepare payroll. We do not use it for any other purpose.
>
> **Who sees it:** you, your supervisor, your HR office and the system administrators.
>
> **How long:** [your retention period].
>
> **Your rights:** you can see your own attendance at any time in the app. If something is wrong, send a correction request or tell your HR office. For questions about your personal data contact [name, email, phone of the person responsible for data protection].

## Threats and what remains

| Threat | Control | Remaining risk |
|---|---|---|
| Guessing passwords | Hashing, lockout, strength rules | A staff member who chooses a weak password in the allowed range |
| Stolen phone | Passwords reset by HR end all sessions | Between loss and report, the phone stays signed in (14 days of inactivity) |
| An administrator abusing access | Everything sensitive is logged; roles are limited | A national administrator can see everything: limit these accounts to a few trusted people |
| Server stolen or backup leaked | Passwords hashed | Attendance data is **not encrypted at rest**. Use encrypted disks and encrypted backups |
| Internet eavesdropping | Needs https, which you must set up | None if https is correct |
| Faked attendance | Rotating code, phone, location and network rules, review queue | See *What it cannot do* in HOW_IT_WORKS.md |
| Someone sharing the TV link outside the office | Short-lived codes, other rules | Anyone with the link sees the live code. Rotate the link if it leaks |
| Overloading the sign-in page | Per-address limits | Put a firewall or rate limiter in front for national scale |

## Gaps to close before a national roll-out

* **Two-factor sign-in for administrators** is not included. Until it is, give administrator accounts long, unique passwords and restrict the admin pages to the government network at the proxy if you can.
* **No email or SMS** is sent (no password-reset emails, no reminders). HR resets passwords.
* **No encryption of the database file** by the application. Use full-disk encryption.
* **No automatic retention or anonymisation job** (see above).
* **Only one database server** (SQLite). Move to PostgreSQL for several servers.
* Get an independent security review before real use.

## Reporting a problem

Decide now who staff should contact about a security or privacy problem, and put their details in the privacy notice and in the help text of the office.
