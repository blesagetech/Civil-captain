# User guide

Short, plain instructions for each kind of user. The staff section can be printed and put on the office wall.

---

## For staff

### Check in (every morning)

1. Find the screen at reception. It shows a square QR code and a 6-digit number.
2. Open your phone's **camera** and point it at the QR code. Tap the link that appears.
3. If asked, sign in. (You stay signed in on this phone for two weeks.)
4. Tap **Confirm check-in**. If your office asks, allow the phone to share its location once.
5. You see a green tick and the time. Done.

**Camera will not scan?** Open Civil Captain, tap **Check in**, and type the 6-digit number from the screen.

**Check out** when you leave: open the app, tap **Check out**.

### Know where you stand

The home page shows your attendance this month as a percentage, with a mark at the 75% minimum, and one sentence telling you what you need: *"Attend at least 10 of the next 15 working days to reach 75%."* Tap any day in the calendar to see its details.

### Leave and mistakes

* **Request leave**: *Requests > Request leave*. Choose the dates and a reason. Your supervisor decides. Approved leave is not counted against you.
* **I was at work but could not check in**: *Requests > Correct a day*. Enter when you arrived and left, and what happened. Your supervisor decides.
* Please do **not** write medical details. "Sick leave" is enough.

### New phone, lost phone

* **New phone:** the first check-in from it may be sent to your supervisor to approve. Tell them you changed phone.
* **Lost phone:** tell your HR office straight away. They reset your password, which signs the lost phone out.

### Rules

Never share your password. Never send a photo of the reception screen to anyone. A check-in from someone who is not at the office is a disciplinary matter.

### Online sessions

Open **Sessions**. When a session is live, tap **Join and track my time** and keep that page open. Your time is counted while the page is open. You need at least the minimum share shown (usually 75%). A phone that goes to sleep stops counting; the page asks your phone to stay awake.

---

## For supervisors

* **Team**: today's list, worst problems first. The counts at the top show who is in, late, not in yet, absent, on leave and what is waiting for you. Tap a name to see their month. From a person's page you can **enter attendance by hand** (for example when the office network was down); a reason is required.
* **Review**: three queues.
  * *Check-ins to review*: someone broke an office rule (new phone, outside the office area, wrong network). **Accept** if you are satisfied. **Do not accept** if not; it then stops counting for that day. Talk to the person first when in doubt.
  * *Requests*: approve or decline leave and corrections. You can leave a note.
  * *New phones*: approve a phone that you know belongs to that person.
* **Screen**: opens the reception QR display on the computer you are using. Press **Full screen**. HR can give you a **TV link** for a dedicated screen that does not need signing in.
* **Sessions** (online meetings, training, remote duty): *Plan a session*, then later *Who attended*.
* Your own attendance works like everyone's: **Home**.

A flagged check-in is a **reason to ask a question**, not proof of cheating. Phones are changed, batteries die, and GPS drifts inside buildings.

---

## For HR administrators

### Set up an office

**Offices > Add an office.** Set opening and closing times, the grace period, the working days and how often the code changes. Then the checks (recommended to start: phone = *review*, location = *review*, network = *off*). For the location rule, stand at the entrance and press **Use my position now**.

### Add people

* **People > Add a person** for one person. The screen shows a temporary password **once**. Give it to the person privately.
* **People > Import from a spreadsheet** for many people. Save the sheet as CSV with these column names in the first row: `username, full_name` (required) and `job_title, station, supervisor, role, start_date, phone, email` (optional). `station` is the exact office name and `supervisor` is that person's username (list supervisors first in the file). Download the temporary passwords list from the result window. It is not shown again.
* Every person needs a **supervisor**. Without one, nobody can see that person.
* **First day at this office** matters: days before it are never counted.

### Everyday jobs

* **Forgotten password**: People > click the person > *Reset password*.
* **Someone leaves**: People > click the person > untick *This account is active*. Their history stays.
* **Someone moves office or supervisor**: People > click the person > change the office or supervisor.
* **Reception TV**: **More > Office screen > Link for the reception TV**. Open that link on the TV's browser and press F11 / full screen.
* **Reports**: **More > Reports and downloads**. Choose the period and office. *Download summary* (one line per person), *Download every check-in*, and *Payroll eligibility* for a month. Open the CSV files in Excel.
* **Activity log**: More > Activity log shows who changed what.

### Month end

1. After the last working day, open **Reports** for the month and download **Payroll eligibility**.
2. People marked *Below minimum - refer to HR* need a human decision. Check for approved leave you forgot, outages, or corrections not yet decided (see **Review**).
3. The system never stops anyone's pay. It gives you the list.

---

## For the national administrator

* **Ministries**: add each ministry or agency, then create its first HR administrator from **People** (choose the ministry and the role *HR administrator*).
* **Public holidays**: More > Public holidays. *Add the standard holidays for the year* fills fixed holidays and Easter. Add Eid al-Fitr and Eid al-Adha when announced.
* **National settings**: the attendance minimum (default 75%) and the default online-session minimum.
* Keep the number of national administrators very small. Everything they do is logged.

---

## Frequently asked questions

**Why does it say my check-in is waiting for review?** Something about it was unusual (a new phone, you were outside the office area, or you were not on the office network). It still counts while your supervisor looks at it.

**Why does the percentage not match my count?** Only expected days count. Weekends, public holidays and approved leave are left out, and days before your first day.

**It says the code expired.** Scan the code that is on the screen *now*. Codes change every few minutes.

**I am on leave but my day shows absent.** Your leave must be approved first. Check *Requests*.

**I cannot sign in.** Check your username and password. After 5 wrong tries you must wait 15 minutes. HR can reset your password.

---

## Quick acceptance script (30 minutes)

Use this to check a new installation with a supervisor and two test staff.

1. HR adds the office and three people (one supervisor, two staff). Staff sign in and choose new passwords.
2. Supervisor opens **Screen**. Staff A scans the QR, Staff B types the code. Both appear **in** on the supervisor's **Team** page.
3. Staff B tries to check in again: refused.
4. Wait for the code to change (or set the office to rotate every minute). Staff A tries an old photo of the QR: refused.
5. Staff A requests leave for tomorrow. Supervisor approves. Staff A's calendar shows leave.
6. Staff B sends a correction for yesterday. Supervisor approves. The day shows attended.
7. HR downloads the summary and eligibility reports. Numbers match the screens.
8. HR resets Staff B's password and Staff B must choose a new one.
