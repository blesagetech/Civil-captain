"""Admin tools.

    python manage.py reset-password USERNAME     print a new temporary password
    python manage.py backup [FILE]               copy the database safely while it is in use
"""
import os
import sqlite3
import sys
import time


def main():
    from app import create_app
    from app.config import Config
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    cfg = Config()
    if cmd == "reset-password" and len(sys.argv) == 3:
        app = create_app()
        with app.app_context():
            from app.db import q1, run
            from app.security import hash_password, temp_password
            u = q1("SELECT id FROM users WHERE username=?", (sys.argv[2],))
            if not u:
                sys.exit(f"No user called {sys.argv[2]!r}.")
            pw = temp_password()
            run("UPDATE users SET pw_hash=?, must_change_pw=1, active=1 WHERE id=?", (hash_password(pw), u["id"]))
            run("DELETE FROM auth_sessions WHERE user_id=?", (u["id"],))
            print(f"Temporary password for {sys.argv[2]}: {pw}\n(They must choose a new one at next sign-in.)")
    elif cmd == "backup":
        dest = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(cfg.DB_PATH), f"backup-{time.strftime('%Y%m%d-%H%M%S')}.db")
        src, dst = sqlite3.connect(cfg.DB_PATH), sqlite3.connect(dest)
        with dst:
            src.backup(dst)
        print(f"Backup written to {dest}")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
