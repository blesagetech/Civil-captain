"""Start Civil Captain.

    python run.py --demo      try it with fictional demo data (use this first)
    python run.py             real use: creates the administrator account on first run
"""
import argparse
import os


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--demo", action="store_true", help="fill an empty database with fictional demo data")
    ap.add_argument("--host", default=os.environ.get("HOST", "0.0.0.0"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")))
    args = ap.parse_args()
    if args.demo:
        os.environ["CC_DEMO"] = "1"

    # GitHub Codespaces puts a proxy in front of the app. Work out the public address for the QR codes.
    if os.environ.get("CODESPACES") == "true":
        os.environ.setdefault("CC_TRUST_PROXY", "1")
        name, domain = os.environ.get("CODESPACE_NAME"), os.environ.get("GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN")
        if name and domain:
            os.environ.setdefault("CC_PUBLIC_URL", f"https://{name}-{args.port}.{domain}")

    from app import create_app
    app = create_app()
    print(f"\n  Civil Captain is running.  Open http://localhost:{args.port}\n", flush=True)
    app.run(host=args.host, port=args.port, threaded=True)


if __name__ == "__main__":
    main()
