/* Civil Captain: manager and administrator screens. Loaded after app.js. */
(() => {
'use strict';
const { $, $$, esc, api, post, put, del, toast, modal, field, formData, tag, stateTag, flagTags, L, hm, dayFmt, monthName, dateTime, isoDay, addMonth, role, isAdmin, view, S, nowTs, refreshBadge } = CC;
const ACT = CC.act, FORM = CC.form;
const MANAGERS = ['supervisor', 'org_admin', 'super_admin'], ADMINS = ['org_admin', 'super_admin'];

function secretModal(title, who, pw) {
  modal({ title, submit: '', cancel: 'Done', body: `<p>Give this temporary password to <b>${esc(who)}</b>. It is shown only now. They must choose their own password the first time they sign in.</p><div class="secret">${esc(pw)}</div>` });
}
function downloadText(name, text) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv' }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const stationOptions = (stations, all) => [['', all]].concat(stations.map(s => [s.id, s.name]));

/* ---------- team today ---------- */
const T = { station: '' };
view('team', async (_a, v) => {
  const st = (await api('/api/stations')).stations.filter(s => s.active);
  v.innerHTML = `<section class="sec"><div class="between"><h1>Team today</h1><a class="btn ghost sm" href="#/reports">Reports and downloads</a></div>
    <div class="filters">${field('Office', 'station', T.station, { type: 'select', opts: stationOptions(st, 'All offices') })}</div><div id="tbody"><p class="muted">Loading…</p></div></section>`;
  $('select[name=station]').addEventListener('change', e => { T.station = e.target.value; loadToday(); });
  await loadToday();
}, { wide: true, roles: MANAGERS });

async function loadToday() {
  const d = await api('/api/team/today' + (T.station ? '?station_id=' + T.station : ''));
  const c = d.counts, inn = (c.present || 0) + (c.late || 0) + (c.remote || 0);
  const order = { absent: 0, late: 1, pending: 2, rejected: 3, present: 4, remote: 5, leave: 6, off: 7, holiday: 8 };
  const rows = d.rows.slice().sort((a, b) => ((order[a.state] ?? 9) - (order[b.state] ?? 9)) || a.full_name.localeCompare(b.full_name));
  const count = (n, label, cls) => `<div class="count s-${cls}"><b>${n || 0}</b><span>${label}</span></div>`;
  $('#tbody').innerHTML = `<p class="muted">${esc(dayFmt(d.day, { weekday: 'long', day: 'numeric', month: 'long' }))}. ${d.total} people.</p>
    <div class="counts">${count(inn, 'In', 'present')}${count(c.late, 'Late', 'late')}${count(c.pending, 'Not in yet', 'pending')}${count(c.absent, 'Absent', 'absent')}${count(c.leave, 'On leave', 'leave')}${count(c.flagged, 'To review', 'flag')}</div>
    ${rows.length ? `<div class="list">${rows.map(r => `<div class="item"><a class="t" href="#/person/${r.user_id}">${esc(r.full_name)}</a><span class="side">${stateTag(r.state)}</span>
      <span class="m">${esc(r.job_title)}${r.station_name ? ', ' + esc(r.station_name) : ''}${r.check_in ? `<br>In at ${hm(r.check_in)}${r.check_out ? ', out at ' + hm(r.check_out) : ''}` : ''}${r.flags.length ? `<br>${flagTags(r.flags)}` : ''}
      <br>${r.pct == null ? 'No days counted yet' : r.pct + '% this month'}${r.month_status === 'below' ? ' ' + tag('below', 'Below minimum') : ''}</span></div>`).join('')}</div>` : '<p class="empty">Nobody is assigned to you yet. HR can set the supervisor on each person.</p>'}`;
}

/* ---------- one person ---------- */
const P = { id: null, month: null, days: [], name: '' };
view('person', async (id, v) => {
  P.id = id; P.month = null;
  await paintPerson(v, null);
}, { wide: true, roles: MANAGERS });
async function paintPerson(v, month) {
  const d = await api(`/api/team/user/${P.id}/month` + (month ? '?month=' + month : ''));
  P.month = d.month; P.days = d.summary.days; P.name = d.user.full_name; S.monthDays = P.days;
  const cur = isoDay(nowTs()).slice(0, 7);
  v = v || $('#view');
  v.innerHTML = `<section class="sec"><p><a href="#/team">Back to team</a></p><h1>${esc(d.user.full_name)}</h1><p class="muted">${esc(d.user.job_title)}</p>
    <div class="actions"><button class="btn sm" data-act="manual" data-id="${P.id}">Enter attendance by hand</button></div></section>
    <section class="sec">${CC.standingHtml(d.summary, S.me.settings.threshold_pct, d.month === cur)}</section>
    <section class="sec" id="register">${CC.registerHtml(d.summary, d.month, isoDay(nowTs()), cur, 'pmonth')}</section>`;
}
ACT.pmonth = async el => { await paintPerson(null, addMonth(P.month, +el.dataset.n)); };
ACT.manual = el => modal({ title: 'Enter attendance by hand', submit: 'Save', body:
  `<p class="muted">Use this when ${esc(P.name)} was at work but the system could not record it, for example during a network outage. The entry is logged under your name.</p>` +
  field('Day', 'day', isoDay(nowTs()), { type: 'date', req: true }) +
  `<div class="row2">${field('Arrived at', 'check_in', '08:00', { type: 'time', req: true })}${field('Left at (optional)', 'check_out', '', { type: 'time' })}</div>` +
  field('Reason', 'note', '', { type: 'textarea', req: true }),
  onSubmit: async (f, v) => { await post('/api/attendance/manual', Object.assign({ user_id: +el.dataset.id }, v)); toast('Saved.'); await paintPerson(null, P.month); } });

/* ---------- review queue ---------- */
view('review', async (_a, v) => {
  const d = await api('/api/review');
  const none = '<p class="empty">Nothing waiting. You are up to date.</p>';
  v.innerHTML = `<section class="sec"><h1>Review</h1><p class="lede">Check-ins that broke an office rule, requests from your team, and new phones.</p></section>
    <section class="sec"><h2>Check-ins to review (${d.flagged.length})</h2>${d.flagged.length ? `<div class="list">${d.flagged.map(r => `<div class="item"><span class="t">${esc(r.full_name)}</span><span class="side">${esc(dayFmt(r.day))}, ${hm(r.check_in)}</span>
      <span class="m">${esc(r.station_name || '')}<br>${flagTags(r.flags)}${r.distance_m != null ? `<br>About ${r.distance_m} m from the office` : ''}</span>
      <div class="acts"><button class="btn sm" data-act="rv-att" data-id="${r.id}" data-d="approve">Accept</button><button class="btn ghost sm" data-act="rv-att" data-id="${r.id}" data-d="reject">Do not accept</button></div></div>`).join('')}</div>` : none}</section>
    <section class="sec"><h2>Requests (${d.requests.length})</h2>${d.requests.length ? `<div class="list">${d.requests.map(r => `<div class="item"><span class="t">${esc(r.full_name)}</span><span class="side">${r.kind === 'leave' ? esc(L.leave[r.leave_type] || 'Leave') : 'Correction'}</span>
      <span class="m">${esc(dayFmt(r.start_day))}${r.end_day !== r.start_day ? ' to ' + esc(dayFmt(r.end_day)) : ''}${r.kind === 'correction' ? `, arrived ${esc(r.claim_in)}${r.claim_out ? ', left ' + esc(r.claim_out) : ''}` : ''}<br>${esc(r.reason)}</span>
      <div class="acts"><button class="btn sm" data-act="rv-req" data-id="${r.id}" data-d="approve">Approve</button><button class="btn ghost sm" data-act="rv-req" data-id="${r.id}" data-d="reject">Decline</button></div></div>`).join('')}</div>` : none}</section>
    <section class="sec"><h2>New phones (${d.devices.length})</h2>${d.devices.length ? `<div class="list">${d.devices.map(r => `<div class="item"><span class="t">${esc(r.full_name)}</span><span class="side">${esc(dateTime(r.first_seen))}</span>
      <span class="m">${esc(r.label ? r.label.slice(0, 90) : 'Unknown phone')}</span>
      <div class="acts"><button class="btn sm" data-act="rv-dev" data-id="${r.id}" data-d="approve">Approve phone</button><button class="btn ghost sm" data-act="rv-dev" data-id="${r.id}" data-d="revoke">Remove</button></div></div>`).join('')}</div>` : none}</section>`;
}, { roles: MANAGERS });
ACT['rv-att'] = async el => { await post(`/api/review/attendance/${el.dataset.id}`, { decision: el.dataset.d }); toast(el.dataset.d === 'approve' ? 'Accepted.' : 'Not accepted. It no longer counts.'); CC.route(); };
ACT['rv-dev'] = async el => { await post(`/api/review/device/${el.dataset.id}`, { decision: el.dataset.d }); toast(el.dataset.d === 'approve' ? 'Phone approved.' : 'Phone removed.'); CC.route(); };
ACT['rv-req'] = el => modal({ title: el.dataset.d === 'approve' ? 'Approve this request' : 'Decline this request', submit: el.dataset.d === 'approve' ? 'Approve' : 'Decline', danger: el.dataset.d !== 'approve',
  body: field('Note for the person (optional)', 'note', '', { type: 'textarea' }),
  onSubmit: async (f, v) => { await post(`/api/review/request/${el.dataset.id}`, { decision: el.dataset.d, note: v.note }); toast('Done.'); CC.route(); } });

/* ---------- reports ---------- */
const R = { preset: 'this', from: '', to: '', station: '' };
view('reports', async (_a, v) => {
  const st = (await api('/api/stations')).stations;
  v.innerHTML = `<section class="sec"><h1>Reports and downloads</h1>
    <div class="filters">${field('Period', 'preset', R.preset, { type: 'select', opts: [['this', 'This month so far'], ['last', 'Last month'], ['custom', 'Choose dates']] })}
      <span id="rdates" ${R.preset === 'custom' ? '' : 'hidden'} style="display:contents">${field('From', 'from', R.from, { type: 'date' })}${field('To', 'to', R.to, { type: 'date' })}</span>
      ${field('Office', 'station', R.station, { type: 'select', opts: stationOptions(st.filter(s => s.active), 'All offices') })}</div>
    <div id="rbody"><p class="muted">Loading…</p></div></section>`;
  const reload = () => { R.preset = $('[name=preset]').value; R.from = $('[name=from]').value; R.to = $('[name=to]').value; R.station = $('[name=station]').value; $('#rdates').hidden = R.preset !== 'custom'; loadReport().catch(e => toast(e.message, true)); };
  $$('.filters select, .filters input', v).forEach(el => el.addEventListener('change', reload));
  await loadReport();
}, { wide: true, roles: MANAGERS });

function rangeQuery() {
  const base = R.preset === 'custom' && R.from && R.to ? `from=${R.from}&to=${R.to}` : `preset=${R.preset === 'last' ? 'last' : 'this'}`;
  return base + (R.station ? '&station_id=' + R.station : '');
}
async function loadReport() {
  const d = await api('/api/team/summary?' + rangeQuery());
  const rows = d.rows.slice().sort((a, b) => (a.pct ?? 101) - (b.pct ?? 101) || a.full_name.localeCompare(b.full_name));
  const below = rows.filter(x => x.status === 'below').length;
  const exact = `from=${d.from}&to=${d.to}` + (R.station ? '&station_id=' + R.station : ''); // dates as the server worked them out
  const month = d.from.slice(0, 7);
  $('#rbody').innerHTML = `<p class="muted">${esc(dayFmt(d.from))} to ${esc(dayFmt(d.to))}. The minimum is ${d.threshold}%.</p>
    <p><b>${below}</b> of ${rows.length} people are below the minimum.</p>
    <div class="actions"><a class="btn sm" href="/api/reports/summary.csv?${exact}">Download summary</a><a class="btn ghost sm" href="/api/reports/records.csv?${exact}">Download every check-in</a>
      <a class="btn ghost sm" href="/api/reports/eligibility.csv?month=${month}${R.station ? '&station_id=' + R.station : ''}">Payroll eligibility for ${esc(monthName(month))}</a></div>
    ${rows.length ? `<div class="scroll"><table><thead><tr><th>Name</th><th>Office</th><th class="num">Attended</th><th class="num">Expected</th><th>Attendance</th><th>Standing</th><th class="num">Late</th><th class="num">Missing check-out</th><th class="num">To review</th></tr></thead><tbody>
      ${rows.map(x => `<tr class="click" data-act="goto" data-to="#/person/${x.user_id}"><td><b>${esc(x.full_name)}</b><br><small>${esc(x.job_title)}</small></td><td>${esc(x.station_name)}</td><td class="num">${x.attended}</td><td class="num">${x.expected}</td>
      <td>${x.pct == null ? '–' : x.pct + '%'}<span class="bargauge${x.status === 'below' ? ' below' : ''}"><i style="width:${Math.min(100, x.pct || 0)}%"></i></span></td>
      <td>${x.status === 'ok' ? tag('ok', 'Meets minimum') : x.status === 'below' ? tag('below', 'Below minimum') : tag('na', 'Nothing to count')}</td><td class="num">${x.late}</td><td class="num">${x.missing_checkout}</td><td class="num">${x.flagged}</td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">No people in this report.</p>'}
    <p class="hint">Payroll eligibility lists everyone below the minimum so HR can review before payroll is approved. Nobody is stopped automatically.</p>`;
}
ACT.goto = el => { location.hash = el.dataset.to; };

/* ---------- office screen links ---------- */
view('screen', async (_a, v) => {
  const st = (await api('/api/stations')).stations.filter(s => s.active);
  v.innerHTML = `<section class="sec"><h1>Office screen</h1><p class="lede">Show the rotating QR code on a screen at reception. Staff scan it to check in. The code changes every few minutes, so a photo of it soon stops working.</p>
    ${st.length ? `<div class="list">${st.map(s => `<div class="item"><span class="t">${esc(s.name)}</span><span class="side"></span><span class="m">${esc(s.district || '')}</span>
      <div class="acts"><a class="btn sm" href="#/display/${s.id}">Show the screen</a>${isAdmin() ? `<button class="btn ghost sm" data-act="tvlink" data-key="${esc(s.display_key)}" data-name="${esc(s.name)}">Link for the reception TV</button>` : ''}</div></div>`).join('')}</div>` : '<p class="empty">No offices yet.</p>'}
    ${isAdmin() ? '<p class="hint">The TV link needs no sign-in, so anyone who has it can see the live code. Share it only inside the office. If it leaks, change it on the Offices page.</p>' : ''}</section>`;
}, { roles: MANAGERS });
ACT.tvlink = async el => {
  const url = `${location.origin}/display?key=${el.dataset.key}`;
  try { await navigator.clipboard.writeText(url); toast('Link copied.'); } catch (e) { /* fall through to showing it */ }
  modal({ title: 'Link for ' + el.dataset.name, submit: '', cancel: 'Close', body: `<p>Open this link in the browser on the reception TV or tablet and make it full screen.</p><div class="secret" style="font-size:15px;letter-spacing:0">${esc(url)}</div>` });
};

/* ---------- people ---------- */
const U = { q: '', station: '' };
view('people', async (_a, v) => {
  const st = (await api('/api/stations')).stations;
  v.innerHTML = `<section class="sec"><div class="between"><h1>People</h1><div class="actions" style="margin:0"><button class="btn sm" data-act="u-new">Add a person</button><button class="btn ghost sm" data-act="u-import">Import from a spreadsheet</button></div></div>
    <div class="filters">${field('Search by name or username', 'q', U.q, { type: 'search' })}${field('Office', 'station', U.station, { type: 'select', opts: stationOptions(st, 'All offices') })}</div>
    <div id="ubody"></div></section>`;
  const load = () => loadPeople().catch(e => toast(e.message, true));
  $('[name=q]').addEventListener('input', debounce(() => { U.q = $('[name=q]').value; load(); }, 300));
  $('[name=station]').addEventListener('change', e => { U.station = e.target.value; load(); });
  await loadPeople();
}, { wide: true, roles: ADMINS });
async function loadPeople() {
  const d = await api('/api/users?limit=500&q=' + encodeURIComponent(U.q) + (U.station ? '&station_id=' + U.station : ''));
  S.people = d.users;
  $('#ubody').innerHTML = d.users.length ? `<p class="muted">${d.total} people${d.total > d.users.length ? ', showing the first ' + d.users.length : ''}.</p><div class="scroll"><table><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Office</th><th>Supervisor</th><th>Status</th></tr></thead><tbody>
    ${d.users.map(u => `<tr class="click" data-act="u-edit" data-id="${u.id}"><td><b>${esc(u.full_name)}</b><br><small>${esc(u.job_title)}</small></td><td>${esc(u.username)}</td><td>${esc(L.role[u.role])}</td>
    <td>${esc(u.station_name || '')}${S.me.user.role === 'super_admin' && u.org_name ? '<br><small>' + esc(u.org_name) + '</small>' : ''}</td><td>${esc(u.supervisor_name || '')}</td>
    <td>${u.active ? (u.must_change_pw ? tag('waiting', 'Not signed in yet') : tag('ok', 'Active')) : tag('off', 'Deactivated')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">No one found.</p>';
}
async function personFormParts(u) {
  const [st, sup, orgs] = await Promise.all([api('/api/stations'), api('/api/users?role=supervisor,org_admin&limit=1000'), api('/api/orgs')]);
  const sa = role() === 'super_admin', orgName = id => (orgs.orgs.find(o => o.id === id) || {}).name || '';
  const roles = (sa ? ['employee', 'supervisor', 'org_admin', 'super_admin'] : ['employee', 'supervisor', 'org_admin']).map(r => [r, L.role[r]]);
  return (u.id ? '' : field('Username', 'username', '', { req: true, hint: 'The employee number or email works well. Letters, numbers and . _ - @ only.', attrs: 'autocapitalize="none"' })) +
    field('Full name', 'full_name', u.full_name, { req: true }) +
    `<div class="row2">${field('Job title', 'job_title', u.job_title)}${field('Phone', 'phone', u.phone, { type: 'tel' })}</div>` +
    field('Email', 'email', u.email, { type: 'email' }) +
    `<div class="row2">${field('Role', 'role', u.role || 'employee', { type: 'select', opts: roles })}${field('First day at this office', 'start_date', u.start_date || isoDay(nowTs()), { type: 'date', hint: 'Days before this are never counted.' })}</div>` +
    (sa ? field('Ministry or agency', 'org_id', u.org_id, { type: 'select', opts: orgs.orgs.map(o => [o.id, o.name]) }) : '') +
    field('Office', 'station_id', u.station_id || '', { type: 'select', opts: stationOptions(st.stations, 'No office').map(o => o[0] === '' ? o : [o[0], o[1] + (sa ? ' (' + orgName(st.stations.find(s => s.id === o[0]).org_id) + ')' : '')]) }) +
    field('Supervisor', 'supervisor_id', u.supervisor_id || '', { type: 'select', opts: [['', 'No supervisor']].concat(sup.users.filter(x => x.id !== u.id && x.active).map(x => [x.id, x.full_name + (sa && x.org_name ? ' (' + x.org_name + ')' : '')])), hint: 'The supervisor sees this person on their team page and decides their requests.' });
}
ACT['u-new'] = async () => {
  const body = await personFormParts({});
  modal({ title: 'Add a person', submit: 'Create account', body, onSubmit: async (f, v) => {
    const r = await post('/api/users', v); await loadPeople(); secretModal('Account created', v.full_name, r.temp_password); return false;
  } });
};
ACT['u-edit'] = async el => {
  const u = (S.people || []).find(x => String(x.id) === el.dataset.id);
  if (!u) return;
  const body = await personFormParts(u);
  modal({ title: u.full_name, wide: true, submit: 'Save changes', body: body + field('This account is active', 'active', u.active, { type: 'checkbox' }) +
    `<div class="actions"><button type="button" class="btn ghost sm" data-act="u-reset" data-id="${u.id}" data-name="${esc(u.full_name)}">Reset password</button></div>`,
  onSubmit: async (f, v) => { await put('/api/users/' + u.id, v); toast('Saved.'); await loadPeople(); } });
};
ACT['u-reset'] = async el => {
  if (!confirm('Reset the password for ' + el.dataset.name + '? Their current password stops working.')) return;
  const r = await post(`/api/users/${el.dataset.id}/reset-password`);
  $('#dlg').close(); secretModal('New temporary password', el.dataset.name, r.temp_password);
};
ACT['u-import'] = async () => {
  const orgs = role() === 'super_admin' ? (await api('/api/orgs')).orgs : [];
  modal({ title: 'Import people from a spreadsheet', wide: true, submit: 'Import', body:
    `<p class="muted">Export your spreadsheet as CSV. The first row must be column names: <b>username, full_name</b> are required; <b>job_title, station, supervisor, role, start_date, phone, email</b> are optional. "station" is the office name and "supervisor" is the supervisor's username (list supervisors first).</p>` +
    (orgs.length ? field('Ministry or agency', 'org_id', orgs[0].id, { type: 'select', opts: orgs.map(o => [o.id, o.name]) }) : '') +
    `<div class="f"><label for="csvfile">Choose a CSV file</label><input type="file" id="csvfile" accept=".csv,text/csv"></div>` + field('Or paste the rows here', 'csv', '', { type: 'textarea', attrs: 'rows="6"' }),
  onSubmit: async (f, v) => {
    const file = $('#csvfile', f).files[0];
    const csv = file ? await file.text() : v.csv;
    if (!csv) throw new Error('Choose a file or paste the rows.');
    const r = await post('/api/users/import', { csv, org_id: v.org_id });
    await loadPeople();
    modal({ title: `${r.created.length} accounts created`, wide: true, submit: r.created.length ? 'Download passwords' : '', cancel: 'Close', body:
      `${r.created.length ? '<p>Each person has a temporary password. Download the list now. It is not shown again. Hand each password to its owner privately.</p>' : ''}${r.errors.length ? `<div class="note bad"><b>${r.errors.length} rows were not imported</b><ul>${r.errors.map(e => `<li>Row ${e.line}${e.username ? ' (' + esc(e.username) + ')' : ''}: ${esc(e.message)}</li>`).join('')}</ul></div>` : ''}`,
    onSubmit: async () => { downloadText('temporary-passwords.csv', 'username,name,temporary_password\n' + r.created.map(c => [c.username, c.full_name, c.temp_password].map(x => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\n')); return false; } });
    return false;
  } });
};

/* ---------- offices ---------- */
view('offices', async (_a, v) => {
  const [d, o] = await Promise.all([api('/api/stations'), api('/api/orgs')]);
  S.stations = d.stations; S.orgs = o.orgs;
  const sa = role() === 'super_admin';
  v.innerHTML = `<section class="sec"><div class="between"><h1>Offices</h1><button class="btn sm" data-act="o-new">Add an office</button></div>
    <p class="lede">Each office has working hours, a rotating code for its reception screen, and optional checks that keep check-ins honest.</p>
    ${d.stations.length ? `<div class="list">${d.stations.map(s => `<div class="item"><span class="t">${esc(s.name)}</span><span class="side">${s.active ? '' : tag('off', 'Switched off')}</span>
      <span class="m">${sa ? esc((o.orgs.find(x => x.id === s.org_id) || {}).name || '') + '<br>' : ''}${esc(s.district || '')} ${esc(s.work_start)} to ${esc(s.work_end)}. Code changes every ${Math.round(s.qr_interval / 60)} min.
      <br>${s.geo_policy !== 'off' ? tag('flag', 'Location: ' + (s.geo_policy === 'block' ? 'refuse' : 'review')) : ''} ${s.ip_policy !== 'off' ? tag('flag', 'Network: ' + (s.ip_policy === 'block' ? 'refuse' : 'review')) : ''} ${s.device_policy !== 'off' ? tag('flag', 'Phone: ' + (s.device_policy === 'block' ? 'refuse' : 'review')) : ''}</span>
      <div class="acts"><button class="btn ghost sm" data-act="o-edit" data-id="${s.id}">Edit</button></div></div>`).join('')}</div>` : '<p class="empty">No offices yet.</p>'}</section>`;
}, { wide: true, roles: ADMINS });
const DAYS = [[1, 'Mon'], [2, 'Tue'], [3, 'Wed'], [4, 'Thu'], [5, 'Fri'], [6, 'Sat'], [7, 'Sun']];
function officeForm(s, orgs) {
  const wd = String(s.work_days || '1,2,3,4,5').split(',').map(Number), sa = role() === 'super_admin';
  const pol = (label, name, v, hint) => field(label, name, v || 'off', { type: 'select', opts: L.policy, hint });
  return (!s.id && sa ? field('Ministry or agency', 'org_id', orgs[0] && orgs[0].id, { type: 'select', opts: orgs.map(o => [o.id, o.name]) }) : '') +
    `<div class="row2">${field('Office name', 'name', s.name, { req: true })}${field('District', 'district', s.district)}</div>` +
    `<fieldset><legend>Working hours</legend><div class="row2">${field('Opens', 'work_start', s.work_start || '08:00', { type: 'time', req: true })}${field('Closes', 'work_end', s.work_end || '17:00', { type: 'time', req: true })}</div>
      ${field('Minutes allowed after opening before someone is late', 'grace_min', s.grace_min ?? 15, { type: 'number', attrs: 'min="0" max="120"' })}
      <div class="f"><label>Working days</label><div class="days">${DAYS.map(([n, l]) => `<label class="check"><input type="checkbox" name="wd" value="${n}"${wd.includes(n) ? ' checked' : ''}>${l}</label>`).join('')}</div></div></fieldset>` +
    `<fieldset><legend>Reception screen</legend>${field('How often the code changes', 'qr_interval', s.qr_interval || 300, { type: 'select', opts: [[60, 'Every minute (strictest)'], [120, 'Every 2 minutes'], [300, 'Every 5 minutes (recommended)'], [600, 'Every 10 minutes']] })}</fieldset>` +
    `<fieldset><legend>Checks on each check-in</legend>
      ${pol('Phone rule', 'device_policy', s.device_policy ?? 'flag', 'Each person is tied to their own phone. A different phone, or one phone used by two people, is caught.')}
      ${pol('Location rule', 'geo_policy', s.geo_policy, 'Compares the phone location with the office. Needs the office position below.')}
      <div class="row2">${field('Office latitude', 'lat', s.lat ?? '', { type: 'number', attrs: 'step="any"' })}${field('Office longitude', 'lng', s.lng ?? '', { type: 'number', attrs: 'step="any"' })}</div>
      <div class="row2">${field('Allowed distance (metres)', 'radius_m', s.radius_m || 150, { type: 'number', attrs: 'min="20" max="5000"' })}<div class="f"><label>&nbsp;</label><button type="button" class="btn ghost sm" data-act="o-here">Use my position now</button></div></div>
      ${pol('Network rule', 'ip_policy', s.ip_policy, 'Only allow check-in from the office internet. Does not work if staff use mobile data.')}
      ${field('Office internet addresses', 'allowed_cidrs', s.allowed_cidrs || '', { type: 'textarea', hint: 'One per line or separated by commas, like 41.210.10.0/24 or 41.210.10.25.', attrs: 'rows="2"' })}
      <button type="button" class="btn ghost sm" data-act="o-myip">Use the address I am on now</button><p></p></fieldset>` +
    (s.id ? field('This office is switched on', 'active', s.active, { type: 'checkbox' }) + `<div class="actions"><button type="button" class="btn ghost sm danger" style="color:#fff" data-act="o-rotate" data-id="${s.id}" data-name="${esc(s.name)}">Change the TV link and code secret</button></div>` : '');
}
function officePayload(f, v) {
  v.work_days = $$('input[name=wd]:checked', f).map(x => +x.value);
  delete v.wd;
  return v;
}
ACT['o-new'] = () => modal({ title: 'Add an office', wide: true, submit: 'Create office', body: officeForm({}, S.orgs),
  onSubmit: async (f, v) => { await post('/api/stations', officePayload(f, v)); toast('Office created.'); CC.route(); } });
ACT['o-edit'] = el => {
  const s = S.stations.find(x => String(x.id) === el.dataset.id);
  modal({ title: s.name, wide: true, submit: 'Save changes', body: officeForm(s, S.orgs),
    onSubmit: async (f, v) => { await put('/api/stations/' + s.id, officePayload(f, v)); toast('Saved.'); CC.route(); } });
};
ACT['o-here'] = async () => { const p = await CC.position(); if (!p) return toast('Could not read your position. Allow location access and try again.', true); $('[name=lat]').value = p.lat.toFixed(6); $('[name=lng]').value = p.lng.toFixed(6); toast('Position filled in. Stand at the office entrance when you do this.'); };
ACT['o-myip'] = async () => { const r = await api('/api/my-ip'); const box = $('[name=allowed_cidrs]'); box.value = (box.value ? box.value.trim() + '\n' : '') + r.ip; toast('Added ' + r.ip + '. Check with your network provider if this address changes.'); };
ACT['o-rotate'] = async el => {
  if (!confirm('Change the TV link and the code secret for ' + el.dataset.name + '? The reception screen must be re-opened with the new link, and old codes stop working at once.')) return;
  await post(`/api/stations/${el.dataset.id}/rotate-key`); $('#dlg').close(); toast('Done. Share the new TV link from the Office screen page.'); CC.route();
};

/* ---------- holidays ---------- */
const H = { year: null };
view('holidays', async (_a, v) => {
  H.year = H.year || isoDay(nowTs()).slice(0, 4);
  const d = await api('/api/holidays?year=' + H.year), sa = role() === 'super_admin';
  v.innerHTML = `<section class="sec"><div class="between"><h1>Public holidays</h1><div class="seg"><button data-act="h-year" data-n="-1">${+H.year - 1}</button><button class="on">${H.year}</button><button data-act="h-year" data-n="1">${+H.year + 1}</button></div></div>
    <p class="lede">Holidays are not counted as working days for anyone.${sa ? '' : ' Only the national administrator can change this list.'}</p>
    ${sa ? `<div class="actions"><button class="btn sm" data-act="h-add">Add a holiday</button><button class="btn ghost sm" data-act="h-seed">Add the standard holidays for ${H.year}</button></div>
    <div class="note">Eid al-Fitr and Eid al-Adha follow the moon, so add them here when they are announced.</div>` : ''}
    ${d.holidays.length ? `<div class="list">${d.holidays.map(h => `<div class="item"><span class="t">${esc(h.name)}</span><span class="side">${esc(dayFmt(h.day))}</span>${sa ? `<div class="acts"><button class="btn ghost sm" data-act="h-del" data-day="${h.day}">Remove</button></div>` : ''}</div>`).join('')}</div>` : '<p class="empty">No holidays are set for this year yet.</p>'}</section>`;
}, { roles: MANAGERS });
ACT['h-year'] = el => { H.year = String(+H.year + +el.dataset.n); CC.route(); };
ACT['h-add'] = () => modal({ title: 'Add a holiday', body: field('Date', 'day', '', { type: 'date', req: true }) + field('Name', 'name', '', { req: true, ph: 'Eid al-Fitr' }),
  onSubmit: async (f, v) => { await post('/api/holidays', v); toast('Added.'); CC.route(); } });
ACT['h-seed'] = async () => { await post('/api/holidays/seed', { year: +H.year }); toast('Standard holidays added.'); CC.route(); };
ACT['h-del'] = async el => { if (!confirm('Remove this holiday?')) return; await del('/api/holidays/' + el.dataset.day); toast('Removed.'); CC.route(); };

/* ---------- activity log ---------- */
view('audit', async (_a, v) => {
  const d = await api('/api/audit?limit=300');
  v.innerHTML = `<section class="sec"><h1>Activity log</h1><p class="lede">Every sensitive change is recorded here and cannot be edited.</p>
    ${d.entries.length ? `<div class="scroll"><table><thead><tr><th>When</th><th>Who</th><th>What</th><th>About</th><th>Details</th></tr></thead><tbody>${d.entries.map(e => `<tr><td>${esc(dateTime(e.at))}</td><td>${esc(e.actor_name || 'System')}</td><td>${esc(e.action.replace(/_/g, ' '))}</td><td>${esc(e.target)}</td><td>${esc(e.detail)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">Nothing recorded yet.</p>'}</section>`;
}, { wide: true, roles: ADMINS });

/* ---------- ministries and national settings ---------- */
view('orgs', async (_a, v) => {
  const d = await api('/api/orgs');
  S.orgs = d.orgs;
  v.innerHTML = `<section class="sec"><div class="between"><h1>Ministries and agencies</h1><button class="btn sm" data-act="org-new">Add one</button></div>
    ${d.orgs.length ? `<div class="list">${d.orgs.map(o => `<div class="item"><span class="t">${esc(o.name)}</span><span class="side">${esc(o.code)}</span><div class="acts"><button class="btn ghost sm" data-act="org-edit" data-id="${o.id}">Rename</button></div></div>`).join('')}</div>` : '<p class="empty">Add the first ministry or agency, then its offices and people.</p>'}</section>`;
}, { roles: ['super_admin'] });
ACT['org-new'] = () => modal({ title: 'Add a ministry or agency', body: field('Name', 'name', '', { req: true }) + field('Short code', 'code', '', { req: true, hint: 'Two to twenty letters or numbers, like MICT.' }),
  onSubmit: async (f, v) => { await post('/api/orgs', v); toast('Added.'); CC.route(); } });
ACT['org-edit'] = el => { const o = S.orgs.find(x => String(x.id) === el.dataset.id); modal({ title: 'Rename', body: field('Name', 'name', o.name, { req: true }), onSubmit: async (f, v) => { await put('/api/orgs/' + o.id, v); toast('Saved.'); CC.route(); } }); };

view('settings', async (_a, v) => {
  const s = await api('/api/settings');
  v.innerHTML = `<section class="sec"><h1>National settings</h1><p class="lede">These apply to every ministry and agency.</p>
    <form data-form="settings">${field('Attendance minimum (percent)', 'threshold_pct', s.threshold_pct, { type: 'number', req: true, attrs: 'min="1" max="100"', hint: 'People below this share of expected working days are flagged for HR. The student attendance rule many universities use is 75%.' })}
    ${field('Online session minimum (percent)', 'session_min_pct', s.session_min_pct, { type: 'number', req: true, attrs: 'min="1" max="100"', hint: 'The default share of an online session someone must attend. Each session can set its own.' })}
    <p class="err" role="alert"></p><button class="btn">Save settings</button></form></section>`;
}, { roles: ['super_admin'] });
FORM.settings = async (f, v) => { await put('/api/settings', v); S.me = Object.assign(S.me, { settings: await api('/api/settings') }); toast('Saved.'); };

/* ---------- planning online sessions (shown under Sessions for managers) ---------- */
CC.manageSessions = async el => {
  const [d, st, orgs] = await Promise.all([api('/api/admin/online'), api('/api/stations'), role() === 'super_admin' ? api('/api/orgs') : { orgs: [] }]);
  S.mstations = st.stations; S.morgs = orgs.orgs; S.msessions = d.sessions;
  const phase = s => d.server_time < s.starts_at ? tag('pending', 'Coming up') : d.server_time <= s.ends_at ? tag('present', 'Live now') : tag('off', 'Ended');
  el.innerHTML = `<section class="sec"><div class="between"><h2>Plan and review sessions</h2><button class="btn sm" data-act="s-new">Plan a session</button></div>
    ${d.sessions.length ? `<div class="list">${d.sessions.map(s => `<div class="item"><span class="t">${esc(s.title)}</span><span class="side">${phase(s)}</span>
      <span class="m">${esc(L.kind[s.kind])}. ${esc(dateTime(s.starts_at))} to ${esc(hm(s.ends_at))}. ${esc(s.station_name || 'All offices')}${role() === 'super_admin' ? ', ' + esc(s.org_name) : ''}<br>${s.qualified} of ${s.audience} reached the ${s.min_pct}% minimum, ${s.joined} joined.</span>
      <div class="acts"><button class="btn ghost sm" data-act="s-detail" data-id="${s.id}">Who attended</button>${s.joined ? '' : `<button class="btn ghost sm" data-act="s-del" data-id="${s.id}">Delete</button>`}</div></div>`).join('')}</div>` : '<p class="empty">No sessions planned.</p>'}</section>`;
};
ACT['s-new'] = () => {
  const sa = role() === 'super_admin';
  modal({ title: 'Plan a session', wide: true, submit: 'Create session', body:
    (sa ? field('Ministry or agency', 'org_id', S.morgs[0] && S.morgs[0].id, { type: 'select', opts: S.morgs.map(o => [o.id, o.name]) }) : '') +
    field('Title', 'title', '', { req: true, ph: 'Weekly staff meeting' }) +
    `<div class="row2">${field('Type', 'kind', 'meeting', { type: 'select', opts: Object.entries(L.kind), hint: 'Remote duty counts as a day present for people who reach the minimum.' })}${field('Who', 'station_id', '', { type: 'select', opts: stationOptions(S.mstations.filter(s => s.active), 'Everyone in the organisation') })}</div>` +
    field('Date', 'day', isoDay(nowTs()), { type: 'date', req: true }) +
    `<div class="row2">${field('Starts', 'start', '09:00', { type: 'time', req: true })}${field('Ends', 'end', '10:00', { type: 'time', req: true })}</div>` +
    `<div class="row2">${field('Minimum share to attend (percent)', 'min_pct', S.me.settings.session_min_pct, { type: 'number', attrs: 'min="10" max="100"' })}${field('Meeting link (optional)', 'join_url', '', { type: 'url', ph: 'https://' })}</div>`,
  onSubmit: async (f, v) => { await post('/api/admin/online', v); toast('Session planned.'); CC.route(); } });
};
ACT['s-detail'] = async el => {
  const d = await api('/api/admin/online/' + el.dataset.id);
  modal({ title: d.session.title, wide: true, submit: '', cancel: 'Close', body: `<div class="scroll"><table><thead><tr><th>Name</th><th>Office</th><th class="num">Present</th><th>Result</th></tr></thead><tbody>${d.people.map(p => `<tr><td>${esc(p.full_name)}</td><td>${esc(p.station_name || '')}</td><td class="num">${p.pct}%</td><td>${p.attended ? tag('ok', 'Reached the minimum') : p.seconds ? tag('below', 'Below the minimum') : tag('absent', 'Did not join')}</td></tr>`).join('')}</tbody></table></div>` });
};
ACT['s-del'] = async el => { if (!confirm('Delete this session?')) return; await del('/api/admin/online/' + el.dataset.id); toast('Deleted.'); CC.route(); };

})();
