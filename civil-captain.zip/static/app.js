/* Civil Captain web app. No build step, no libraries. Staff and manager screens live here and in admin.js. */
(() => {
'use strict';

const S = { me: null, csrf: '', cfg: {}, skew: 0, offset: 180, appName: 'Civil Captain', token: null, home: null, homeMonth: null };
const CC = window.CC = { S, views: {}, metas: {}, act: {}, form: {}, cleanup: [] };

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');

const L = {
  state: { present: 'On time', late: 'Late', remote: 'Remote duty', absent: 'Absent', pending: 'Not in yet', leave: 'On leave', off: 'Day off', holiday: 'Holiday', rejected: 'Not accepted', before: '', upcoming: '' },
  flag: { ip_outside: 'Not on the office network', geo_outside: 'Outside the office area', no_location: 'Location not shared', new_device: 'New phone', shared_device: 'Phone used by someone else today', no_device: 'Phone not identified', manual: 'Entered by hand' },
  kind: { remote_duty: 'Remote duty', meeting: 'Meeting', training: 'Training' },
  leave: { annual: 'Annual leave', sick: 'Sick leave', maternity: 'Maternity leave', paternity: 'Paternity leave', study: 'Study leave', compassionate: 'Compassionate leave', official_duty: 'Official duty away', other: 'Other leave' },
  role: { employee: 'Employee', supervisor: 'Supervisor', org_admin: 'HR administrator', super_admin: 'National administrator' },
  req: { pending: 'Waiting', approved: 'Approved', rejected: 'Declined', cancelled: 'Cancelled' },
  policy: [['off', 'Off'], ['flag', 'Allow, but send to the supervisor to review'], ['block', 'Refuse the check-in']],
  review: { pending: 'Waiting for your supervisor', approved: 'Approved by your supervisor', rejected: 'Not accepted by your supervisor' },
};

/* ---------- time ---------- */
const nowTs = () => Math.floor(Date.now() / 1000) + S.skew; // corrected to the server's clock after sign-in
const localDate = ts => new Date((ts + S.offset * 60) * 1000); // read with getUTC* to get Uganda wall-clock time
const hm = ts => { const d = localDate(ts); return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); };
const isoDay = ts => localDate(ts).toISOString().slice(0, 10);
const dayFmt = (d, o) => new Date(d + 'T00:00:00Z').toLocaleDateString('en-GB', Object.assign({ weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }, o || {}));
const monthName = m => new Date(m + '-01T00:00:00Z').toLocaleDateString('en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' });
const dateTime = ts => dayFmt(isoDay(ts)) + ', ' + hm(ts);
const addMonth = (m, n) => { const [y, mo] = m.split('-').map(Number); const d = new Date(Date.UTC(y, mo - 1 + n, 1)); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1); };
const minOf = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const hoursText = secs => { const m = Math.round(secs / 60); return Math.floor(m / 60) + ' h ' + pad(m % 60) + ' min'; };

/* ---------- small bits ---------- */
const tag = (cls, text) => text ? `<span class="tag s-${cls}">${esc(text)}</span>` : '';
const stateTag = st => tag(st, L.state[st]);
const flagTags = flags => (flags || []).filter(f => L.flag[f] && f !== 'manual').map(f => tag('flag', L.flag[f])).join(' ');
const LOGO = '<svg viewBox="0 0 64 64" aria-hidden="true"><rect width="64" height="64" rx="14" fill="#2A3846"/><path d="M17 33l11 11 20-24" fill="none" stroke="#FCDC04" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/><rect x="12" y="50" width="13" height="4" fill="#000"/><rect x="25" y="50" width="13" height="4" fill="#FCDC04"/><rect x="38" y="50" width="14" height="4" fill="#D90000"/></svg>';

function deviceId() {
  const make = () => Array.from(crypto.getRandomValues(new Uint8Array(18)), b => b.toString(36).padStart(2, '0')).join('').slice(0, 30);
  try {
    let id = localStorage.getItem('cc_device');
    if (!id || !/^[A-Za-z0-9_-]{16,64}$/.test(id)) { id = make(); localStorage.setItem('cc_device', id); }
    return id;
  } catch (e) { return CC._mem || (CC._mem = make()); }
}

function position() {
  return new Promise(resolve => {
    if (!navigator.geolocation) return resolve(null);
    toast('Reading your location…');
    navigator.geolocation.getCurrentPosition(
      p => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }),
      () => resolve(null), { enableHighAccuracy: true, timeout: 12000, maximumAge: 20000 });
  });
}

/* ---------- talking to the server ---------- */
class Err extends Error { constructor(m, status, data) { super(m); this.status = status; this.data = data || {}; } }
async function api(path, opt = {}) {
  const method = opt.method || 'GET';
  const init = { method, credentials: 'same-origin', headers: {} };
  if (method !== 'GET') {
    init.headers['Content-Type'] = 'application/json';
    init.headers['X-CSRF-Token'] = S.csrf;
    init.body = JSON.stringify(opt.body || {});
  }
  let r;
  try { r = await fetch(path, init); } catch (e) { throw new Err('No connection. Check your internet and try again.', 0); }
  let data = {};
  try { data = await r.json(); } catch (e) { /* not JSON */ }
  if (!r.ok) {
    if (r.status === 401 && S.me) { S.me = null; S.csrf = ''; toast('Please sign in again.', true); route(); }
    throw new Err(data.error || 'Something went wrong. Try again.', r.status, data);
  }
  return data;
}
const post = (p, body) => api(p, { method: 'POST', body });
const put = (p, body) => api(p, { method: 'PUT', body });
const del = p => api(p, { method: 'DELETE' });

/* ---------- toast, dialog, forms ---------- */
function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'show' + (bad ? ' bad' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => { t.className = ''; }, 4500);
}

function field(label, name, value, o = {}) {
  const type = o.type || 'text', id = 'f_' + name, req = o.req ? ' required' : '';
  const hint = o.hint ? `<small class="hint">${esc(o.hint)}</small>` : '';
  if (type === 'checkbox') return `<label class="check"><input type="checkbox" name="${name}"${value ? ' checked' : ''}>${esc(label)}</label>${hint}`;
  let ctl;
  if (type === 'select') {
    ctl = `<select id="${id}" name="${name}"${req}>${o.opts.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(value ?? '') ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
  } else if (type === 'textarea') {
    ctl = `<textarea id="${id}" name="${name}" rows="3"${req}>${esc(value)}</textarea>`;
  } else {
    ctl = `<input id="${id}" name="${name}" type="${type}" value="${esc(value)}"${req}${o.attrs ? ' ' + o.attrs : ''}${o.ph ? ` placeholder="${esc(o.ph)}"` : ''} autocomplete="${o.ac || 'off'}">`;
  }
  return `<div class="f"><label for="${id}">${esc(label)}</label>${ctl}${hint}</div>`;
}

function formData(f) {
  const o = {};
  $$('input,select,textarea', f).forEach(el => {
    if (!el.name) return;
    if (el.type === 'checkbox') o[el.name] = el.checked;
    else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
    else o[el.name] = el.value.trim();
  });
  return o;
}

function modal({ title, body, submit = 'Save', cancel = 'Cancel', onSubmit, wide, danger }) {
  const d = $('#dlg');
  if (d.open) d.close();
  d.className = wide ? 'wide' : '';
  d.innerHTML = `<form id="mform"><h2>${esc(title)}</h2><div class="mbody">${body}</div><p class="err" id="merr" role="alert"></p>
    <div class="mact">${cancel ? `<button type="button" class="btn ghost" data-act="close">${esc(cancel)}</button>` : ''}${submit ? `<button class="btn${danger ? ' danger' : ''}" id="msub">${esc(submit)}</button>` : ''}</div></form>`;
  const f = $('#mform');
  f.addEventListener('submit', async e => {
    e.preventDefault();
    if (!onSubmit) return d.close();
    const btn = $('#msub'); if (btn) btn.disabled = true;
    try { if ((await onSubmit(f, formData(f))) !== false) d.close(); }
    catch (err) { $('#merr').textContent = err.message || 'Something went wrong.'; }
    finally { if (btn) btn.disabled = false; }
  });
  d.showModal();
  const first = $('input:not([type=hidden]),select,textarea', f); if (first) first.focus();
}

/* ---------- navigation ---------- */
const role = () => S.me.user.role;
const isManager = () => ['supervisor', 'org_admin', 'super_admin'].includes(role());
const isAdmin = () => ['org_admin', 'super_admin'].includes(role());
const NAV_LABEL = { home: 'Home', requests: 'Requests', sessions: 'Sessions', account: 'Account', team: 'Team', review: 'Review', screen: 'Screen', people: 'People', offices: 'Offices', orgs: 'Ministries', more: 'More' };
const NAV_BY_ROLE = {
  employee: ['home', 'requests', 'sessions', 'account'],
  supervisor: ['home', 'team', 'review', 'sessions', 'screen', 'more'],
  org_admin: ['home', 'team', 'review', 'people', 'offices', 'more'],
  super_admin: ['team', 'orgs', 'people', 'offices', 'more'],
};
const NAV_PARENT = { person: 'team', room: 'sessions', display: 'screen', checkin: 'home' };
const defaultRoute = () => role() === 'super_admin' ? 'team' : 'home';
function navActive(name) {
  const ids = NAV_BY_ROLE[role()], n = NAV_PARENT[name] || name;
  return ids.includes(n) ? n : (ids.includes('more') ? 'more' : 'account');
}

function shell(name, wide) {
  const u = S.me.user, act = navActive(name);
  $('#app').innerHTML = `
    <header class="bar"><a class="brand" href="#/">${LOGO}<span>${esc(S.appName)}</span></a><span class="who">${esc(u.full_name)}</span></header>
    <div class="stripe"></div>
    <nav class="tabs" aria-label="Main">${NAV_BY_ROLE[role()].map(id => `<a href="#/${id}"${id === act ? ' class="on" aria-current="page"' : ''}>${NAV_LABEL[id]}</a>`).join('')}</nav>
    <main class="wrap${wide ? ' wide' : ''}" id="view"><p class="muted">Loading…</p></main>`;
  paintBadge();
  return $('#view');
}

let badgeCount = 0;
function paintBadge() {
  const a = $('.tabs a[href="#/review"]');
  if (!a) return;
  $('em', a)?.remove();
  if (badgeCount > 0) a.insertAdjacentHTML('beforeend', `<em>${badgeCount}</em>`);
}
async function refreshBadge() {
  if (!S.me || !isManager()) return;
  try { const d = await api('/api/review'); badgeCount = d.flagged.length + d.requests.length + d.devices.length; paintBadge(); } catch (e) { /* ignore */ }
}

function view(name, fn, meta = {}) { CC.views[name] = fn; CC.metas[name] = meta; }

async function route() {
  CC.cleanup.splice(0).forEach(f => { try { f(); } catch (e) { /* ignore */ } });
  document.body.className = '';
  if (!S.me) return viewLogin();
  if (S.me.user.must_change_pw) return viewForcedPassword();
  const [seg, arg] = location.hash.replace(/^#\/?/, '').split('/');
  const name = S.token ? 'checkin' : (seg || defaultRoute());
  const meta = CC.metas[name];
  if (!meta || (meta.roles && !meta.roles.includes(role()))) { location.hash = '#/' + defaultRoute(); return; }
  const v = shell(name, meta.wide);
  window.scrollTo(0, 0);
  try { await CC.views[name](decodeURIComponent(arg || ''), v); }
  catch (e) { v.innerHTML = `<div class="note bad"><b>${esc(e.message)}</b></div><p><button class="btn" data-act="reload">Try again</button></p>`; }
  if (name !== 'review') refreshBadge();
}

/* ---------- clicks and forms ---------- */
const ACT = CC.act, FORM = CC.form;
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el || !ACT[el.dataset.act]) return;
  e.preventDefault();
  Promise.resolve(ACT[el.dataset.act](el, e)).catch(err => toast(err.message || 'Something went wrong.', true));
});
document.addEventListener('submit', e => {
  const f = e.target.closest('form[data-form]');
  if (!f || !FORM[f.dataset.form]) return;
  e.preventDefault();
  const btn = $('button:not([type=button])', f); if (btn) btn.disabled = true;
  Promise.resolve(FORM[f.dataset.form](f, formData(f))).catch(err => { const m = $('.err', f); if (m) m.textContent = err.message; else toast(err.message, true); })
    .finally(() => { if (btn) btn.disabled = false; });
});
ACT.close = () => $('#dlg').close();
ACT.reload = () => route();

Object.assign(CC, { standingHtml, registerHtml, $, $$, esc, api, post, put, del, toast, modal, field, formData, tag, stateTag, flagTags, L, hm, dayFmt, monthName, dateTime, isoDay, addMonth, hoursText, minOf, role, isManager, isAdmin, shell, route, deviceId, nowTs, view, refreshBadge, position });

/* ---------- sign in ---------- */
function setMe(d) { S.me = d; S.csrf = d.csrf; S.offset = d.offset_min; S.appName = d.app_name || S.appName; S.skew = d.server_time - Math.floor(Date.now() / 1000); }

function viewLogin() {
  $('#app').innerHTML = `<div class="stripe"></div><div class="login-in">
    <h1>${esc(S.appName)}</h1>
    <p class="lede">Attendance for government offices. Check in with your phone. No fingerprint machine needed.</p>
    <form data-form="login">
      ${field('Username', 'username', '', { req: true, ac: 'username', attrs: 'autocapitalize="none" spellcheck="false"' })}
      ${field('Password', 'password', '', { type: 'password', req: true, ac: 'current-password' })}
      <p class="err" role="alert"></p>
      <button class="btn wide">Sign in</button>
    </form>
    <p class="hint" style="margin-top:14px">Forgot your password? Ask your HR office to reset it.</p>
    ${S.cfg.demo ? `<div class="demo"><h2>Demo mode</h2><p class="muted">Every demo account uses the password <b>${esc(S.cfg.demo_password)}</b>. Tap a role to fill in the form.</p>
      ${(S.cfg.demo_logins || []).map(d => `<button class="btn ghost sm" data-act="demo" data-u="${esc(d.username)}">${esc(d.label)}</button>`).join('')}</div>` : ''}
  </div>`;
  $('input[name=username]').focus();
}
ACT.demo = el => { $('input[name=username]').value = el.dataset.u; $('input[name=password]').value = S.cfg.demo_password; $('form[data-form=login] button').focus(); };
FORM.login = async (f, v) => {
  const d = await post('/api/login', { username: v.username, password: v.password });
  setMe(d);
  S.home = null;
  if (!S.token && !location.hash.startsWith('#/')) location.hash = '#/' + defaultRoute();
  route();
};

function viewForcedPassword() {
  $('#app').innerHTML = `<div class="stripe"></div><div class="login-in"><h1>Choose your own password</h1>
    <p class="lede">The password you were given is temporary. Pick one only you know.</p>
    <form data-form="forced">
      ${field('Temporary password', 'current', '', { type: 'password', req: true, ac: 'current-password' })}
      ${field('New password', 'new', '', { type: 'password', req: true, ac: 'new-password', hint: 'At least 8 characters, with a letter and a number.' })}
      ${field('Type the new password again', 'again', '', { type: 'password', req: true, ac: 'new-password' })}
      <p class="err" role="alert"></p><button class="btn wide">Save and continue</button>
    </form><p style="margin-top:14px"><button class="linkbtn" data-act="logout">Sign out</button></p></div>`;
}
FORM.forced = async (f, v) => {
  if (v.new !== v.again) throw new Error('The two new passwords are different.');
  await post('/api/password', { current: v.current, new: v.new });
  setMe(await api('/api/me'));
  toast('Password saved.');
  location.hash = '#/' + defaultRoute();
  route();
};
ACT.logout = async () => { try { await post('/api/logout'); } catch (e) { /* already out */ } S.me = null; S.csrf = ''; S.home = null; location.hash = ''; route(); };

/* ---------- home: today, standing, register ---------- */
function standingHtml(sum, th, current) {
  const has = sum.pct != null, below = has && sum.status === 'below';
  let msg;
  if (!has) msg = 'There are no working days to count yet.';
  else if (!current) msg = sum.status === 'ok' ? `You met the ${th}% minimum.` : `You finished below the ${th}% minimum.`;
  else if (sum.outlook === 'secured') msg = `You have already secured the ${th}% minimum for this month.`;
  else if (sum.outlook === 'lost') msg = `You can no longer reach ${th}% this month. Your HR office will see this on the month-end report.`;
  else if (sum.status === 'ok') msg = `You are above the ${th}% minimum. Attend at least ${sum.need_more} of the next ${sum.remaining} working days to finish the month at ${th}% or more.`;
  else msg = `Attend at least ${sum.need_more} of the next ${sum.remaining} working days to reach ${th}%.`;
  const w = has ? Math.min(100, sum.pct) : 0;
  return `<h2>${current ? 'Attendance this month' : 'Attendance in ' + esc(monthName(sum.from.slice(0, 7)))}</h2>
    <p class="pct" aria-label="${has ? sum.pct + ' percent' : 'no percentage yet'}">${has ? String(sum.pct).replace(/\.0$/, '') : '–'}${has ? '<sup>%</sup>' : ''}</p>
    <div class="gauge${below ? ' below' : ''}" role="img" aria-label="Attendance ${has ? sum.pct : 0} percent, minimum ${th} percent"><i style="width:${w}%"></i><b style="left:calc(${th}% - 1.5px)"></b></div>
    <div class="gkey"><span style="left:${th}%">${th}% minimum</span></div>
    <p>${esc(msg)}</p>
    <div class="stats"><span><b>${sum.attended}</b> of ${sum.expected} days attended</span><span><b>${sum.late}</b> late</span><span><b>${sum.hours}</b> hours worked</span></div>`;
}

function todayHtml(d) {
  const r = d.record, item = d.summary.days.find(x => x.day === d.day) || {}, st = d.today_status;
  let h = `<h2>Today, ${esc(dayFmt(d.day, { weekday: 'long', day: 'numeric', month: 'long' }))}</h2>`;
  if (r) {
    h += `<p class="big">Checked in at ${hm(r.check_in)}</p><div class="mini">${r.status === 'late' ? tag('late', 'Late') : tag('present', 'On time')}${flagTags(r.flags)}</div>`;
    if (L.review[r.review]) h += `<p class="muted">${esc(L.review[r.review])}.</p>`;
    h += r.check_out ? `<p>Checked out at <b>${hm(r.check_out)}</b>. ${hoursText(r.check_out - r.check_in)} today.</p>`
      : '<button class="btn wide" data-act="checkout">Check out</button>';
  } else if (!d.station) {
    h += '<div class="note bad">You are not assigned to an office yet. Ask your HR office to assign you.</div>';
  } else if (['holiday', 'off', 'leave', 'remote'].includes(st)) {
    const why = { holiday: `Today is a public holiday${item.note ? ': ' + item.note : ''}.`, off: 'Today is not a working day at your office.', leave: 'You are on approved leave today.', remote: 'You are counted present today through remote duty.' }[st];
    h += `<p>${esc(why)}</p><a class="btn ghost" href="#/checkin">I am working today</a>`;
  } else {
    h += `<p class="muted">${esc(d.station.name)} opens at ${esc(d.station.work_start)}.</p><a class="btn go" href="#/checkin">Check in</a>`;
  }
  return h;
}

function registerHtml(sum, month, today, cur, act = 'month') {
  cur = cur || (S.home ? S.home.month : month);
  const first = new Date(month + '-01T00:00:00Z').getUTCDay(); // 0 = Sunday
  const blanks = (first + 6) % 7;
  const short = { present: 'In', late: 'Late', remote: 'Remote', absent: 'Absent', leave: 'Leave', rejected: 'No', holiday: 'Holiday', pending: 'Today' };
  const cells = sum.days.map(d => `<button class="d s-${d.status}${d.day === today ? ' today' : ''}" data-act="day" data-day="${d.day}" aria-label="${esc(dayFmt(d.day) + ': ' + (L.state[d.status] || 'no attendance expected'))}"><b>${+d.day.slice(8)}</b><small>${short[d.status] || ''}</small></button>`);
  return `<div class="mnav"><button class="btn ghost sm" data-act="${act}" data-n="-1" aria-label="Previous month">Earlier</button><h2>${esc(monthName(month))}</h2>
      <button class="btn ghost sm" data-act="${act}" data-n="1"${month >= cur ? ' disabled' : ''} aria-label="Next month">Later</button></div>
    <div class="reg">${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(w => `<div class="wd">${w}</div>`).join('')}${'<div class="blank"></div>'.repeat(blanks)}${cells.join('')}</div>
    <div class="legend">${[['present', 'On time'], ['late', 'Late'], ['remote', 'Remote duty'], ['absent', 'Absent'], ['leave', 'Leave']].map(([c, t]) => `<span class="s-${c}"><i></i>${t}</span>`).join('')}</div>`;
}

view('home', async (_a, v) => {
  const d = await api('/api/my/home');
  S.home = d; S.homeMonth = d.month;
  S.monthDays = d.summary.days;
  const u = S.me.user, hr = localDate(d.server_time).getUTCHours();
  v.innerHTML = `<section class="sec"><p class="hello">${hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening'}</p><h1>${esc(u.full_name)}</h1>
      <p class="muted">${esc(d.station ? d.station.name : 'No office assigned')}${u.job_title ? '<br>' + esc(u.job_title) : ''}</p></section>
    <section class="today" id="today">${todayHtml(d)}</section>
    <section class="sec" id="standing">${standingHtml(d.summary, S.me.settings.threshold_pct, true)}</section>
    <section class="sec" id="register">${registerHtml(d.summary, d.month, d.day)}</section>`;
}, { roles: ['employee', 'supervisor', 'org_admin'] });

ACT.month = async el => {
  const m = addMonth(S.homeMonth, +el.dataset.n);
  const r = await api('/api/my/month?month=' + m);
  S.homeMonth = m; S.monthDays = r.summary.days;
  $('#register').innerHTML = registerHtml(r.summary, m, S.home.day);
  $('#standing').innerHTML = standingHtml(r.summary, S.me.settings.threshold_pct, m === S.home.month);
};
ACT.day = el => {
  const d = (S.monthDays || []).find(x => x.day === el.dataset.day);
  if (!d) return;
  const rows = [['Status', L.state[d.status] || 'No attendance expected'], d.note ? ['Holiday', d.note] : null,
    d.check_in ? ['Checked in', hm(d.check_in)] : null, d.check_out ? ['Checked out', hm(d.check_out)] : null,
    d.review && d.review !== 'ok' ? ['Review', ({ pending: 'Waiting for review', approved: 'Approved', rejected: 'Not accepted' })[d.review]] : null,
    d.method && d.method !== 'qr' ? ['Recorded by', ({ code: 'Typed code', manual: 'Your supervisor', correction: 'Approved correction' })[d.method] || d.method] : null,
    d.missing_checkout ? ['Note', 'No check-out was recorded'] : null].filter(Boolean);
  modal({ title: dayFmt(d.day, { weekday: 'long', day: 'numeric', month: 'long' }), submit: '', cancel: 'Close',
    body: `<dl class="kv">${rows.map(([k, val]) => `<dt>${esc(k)}</dt><dd>${esc(val)}</dd>`).join('')}</dl>${flagTags(d.flags ? d.flags.split(',') : []) ? `<div class="mini">${flagTags(d.flags.split(','))}</div>` : ''}` });
};
ACT.checkout = async el => {
  const st = S.home && S.home.station;
  el.disabled = true;
  try {
    const pos = st && st.geo_policy !== 'off' ? await position() : null;
    const r = await post('/api/checkout', Object.assign({ device_id: deviceId() }, pos || {}));
    toast('Checked out at ' + hm(r.record.check_out) + '.');
    route();
  } finally { el.disabled = false; }
};

/* ---------- check in ---------- */
const checkinPage = body => `<section class="sec"><h1>Check in</h1>${body}</section>`;

view('checkin', async (_a, v) => {
  const home = await api('/api/my/home');
  S.home = home;
  if (S.token) {
    const pv = await api('/api/checkin/preview?token=' + encodeURIComponent(S.token));
    if (!pv.valid) {
      S.token = null;
      v.innerHTML = checkinPage(`<div class="note bad">${esc(pv.message)}</div><p>Scan the code that is on the office screen right now.</p><a class="btn" href="#/checkin">Try again</a>`);
      return;
    }
    v.innerHTML = checkinPage(`<p class="lede">${esc(pv.station.name)}</p><p class="muted">Code accepted. Confirm to record your arrival${pv.station.geo_policy !== 'off' ? '. Your phone will share its location once' : ''}.</p>
      <button class="btn go" data-act="confirm">Confirm check-in</button><p style="margin-top:12px"><button class="linkbtn" data-act="cancel-scan">Cancel</button></p><p class="err" id="cerr" role="alert"></p>`);
    return;
  }
  if (home.record) {
    v.innerHTML = checkinPage(`<p class="lede">You already checked in today at <b>${hm(home.record.check_in)}</b>.</p><a class="btn" href="#/home">Back to home</a>`);
    return;
  }
  const canScan = 'BarcodeDetector' in window && !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  v.innerHTML = checkinPage(`<p class="lede">Point your phone camera at the code on the office screen. It opens this page by itself.</p>
    ${canScan ? '<div id="scanbox"><button class="btn ghost wide" data-act="scan">Scan with the camera in this app</button></div>' : ''}
    <section class="sec"><h2>Camera not working? Type the code</h2>
      <form data-form="code"><div class="f"><label for="f_code">6-digit code shown under the QR</label>
      <input id="f_code" class="codebox" name="code" inputmode="numeric" pattern="[0-9 ]*" maxlength="7" autocomplete="one-time-code" placeholder="000 000" required></div>
      <p class="err" role="alert"></p><button class="btn wide">Check in</button></form></section>`);
}, { roles: ['employee', 'supervisor', 'org_admin'] });

async function sendCheckin(payload, stationInfo) {
  const pos = stationInfo && stationInfo.geo_policy !== 'off' ? await position() : null;
  const r = await post('/api/checkin', Object.assign({ device_id: deviceId() }, pos || {}, payload));
  S.token = null; S.home = null;
  const rec = r.record, st = r.station, late = rec.status === 'late';
  const mins = minOf(hm(rec.check_in)) - minOf(st.work_start);
  const tick = '<svg class="tick" viewBox="0 0 88 88" aria-hidden="true"><circle cx="44" cy="44" r="42" fill="#17794A"/><path d="M26 45l12 12 24-27" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  $('#view').innerHTML = `<section class="done">${tick}<h1>You are checked in</h1><p class="clock">${hm(rec.check_in)}</p>
    <div class="mini">${late ? tag('late', 'Late') : tag('present', 'On time')}</div>
    <p>${esc(st.name)}${late ? `. You arrived ${mins} minutes after ${esc(st.work_start)}.` : '.'}</p>
    ${rec.flags.length ? `<div class="note">Your check-in is recorded and your supervisor will review it:<div class="mini" style="justify-content:flex-start">${flagTags(rec.flags)}</div></div>` : ''}
    <p style="margin-top:18px"><a class="btn" href="#/home">Back to home</a></p></section>`;
  history.replaceState(null, '', '/#/checkin');
}
ACT.confirm = async el => {
  el.disabled = true;
  try { await sendCheckin({ token: S.token }, (await api('/api/checkin/preview?token=' + encodeURIComponent(S.token))).station); }
  catch (e) { const m = $('#cerr'); if (m) m.textContent = e.message; else toast(e.message, true); el.disabled = false; }
};
ACT['cancel-scan'] = () => { S.token = null; location.hash = '#/home'; route(); };
FORM.code = async (f, v) => {
  const code = v.code.replace(/\D/g, '');
  await sendCheckin({ code }, S.home && S.home.station);
};
ACT.scan = async () => {
  const box = $('#scanbox');
  box.innerHTML = '<video class="cam" playsinline muted></video><p class="muted">Point the camera at the code on the office screen.</p>';
  const video = $('video', box);
  let stream = null, stop = false;
  CC.cleanup.push(() => { stop = true; if (stream) stream.getTracks().forEach(t => t.stop()); });
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    video.srcObject = stream; await video.play();
    const det = new BarcodeDetector({ formats: ['qr_code'] });
    while (!stop) {
      const found = await det.detect(video).catch(() => []);
      const m = found.length && /\/c\/([^/?#\s]+)/.exec(found[0].rawValue);
      if (m) { stop = true; stream.getTracks().forEach(t => t.stop()); S.token = decodeURIComponent(m[1]); route(); return; }
      await new Promise(r => setTimeout(r, 300));
    }
  } catch (e) {
    box.innerHTML = '<div class="note bad">The camera could not start. Allow camera access, or use your phone\'s camera app, or type the code below.</div>';
  }
};

/* ---------- leave and corrections ---------- */
view('requests', async (_a, v) => {
  const d = await api('/api/my/requests');
  v.innerHTML = `<section class="sec"><h1>Leave and corrections</h1>
    <p class="lede">Approved leave is not counted against your attendance. A correction fixes a day you were at work but could not check in.</p>
    <div class="actions"><button class="btn" data-act="req-leave">Request leave</button><button class="btn ghost" data-act="req-corr">Correct a day</button></div></section>
    <section class="sec"><h2>Your requests</h2>${d.requests.length ? `<div class="list">${d.requests.map(r => `<div class="item">
      <span class="t">${r.kind === 'leave' ? esc(L.leave[r.leave_type] || 'Leave') : 'Correction'}: ${esc(dayFmt(r.start_day))}${r.end_day !== r.start_day ? ' to ' + esc(dayFmt(r.end_day)) : ''}</span>
      <span class="side">${tag(r.status === 'pending' ? 'waiting' : r.status, L.req[r.status])}</span>
      <span class="m">${esc(r.reason)}${r.kind === 'correction' ? ` (arrived ${esc(r.claim_in)}${r.claim_out ? ', left ' + esc(r.claim_out) : ''})` : ''}${r.decision_note ? '<br>Reply: ' + esc(r.decision_note) : ''}${r.decided_by_name && r.status !== 'cancelled' ? '<br>Decided by ' + esc(r.decided_by_name) : ''}</span>
      ${r.status === 'pending' ? `<div class="acts"><button class="btn ghost sm" data-act="req-cancel" data-id="${r.id}">Cancel request</button></div>` : ''}</div>`).join('')}</div>` : '<p class="empty">You have not made any requests.</p>'}</section>`;
}, { roles: ['employee', 'supervisor', 'org_admin'] });

const today = () => isoDay(nowTs());
ACT['req-leave'] = () => modal({ title: 'Request leave', submit: 'Send request', body:
  field('Type of leave', 'leave_type', 'annual', { type: 'select', opts: Object.entries(L.leave) }) +
  `<div class="row2">${field('First day', 'start_day', today(), { type: 'date', req: true })}${field('Last day', 'end_day', today(), { type: 'date', req: true })}</div>` +
  field('Reason', 'reason', '', { type: 'textarea', req: true }),
  onSubmit: async (f, v) => { await post('/api/my/requests', Object.assign({ kind: 'leave' }, v)); toast('Request sent to your supervisor.'); route(); } });
ACT['req-corr'] = () => modal({ title: 'Correct a day', submit: 'Send request', body:
  '<p class="muted">Use this when you were at work but could not check in. Your supervisor decides.</p>' +
  field('Day', 'start_day', isoDay(nowTs() - 86400), { type: 'date', req: true }) +
  `<div class="row2">${field('Arrived at', 'claim_in', '08:00', { type: 'time', req: true })}${field('Left at (if you know)', 'claim_out', '', { type: 'time' })}</div>` +
  field('What happened', 'reason', '', { type: 'textarea', req: true }),
  onSubmit: async (f, v) => { await post('/api/my/requests', Object.assign({ kind: 'correction' }, v)); toast('Correction sent to your supervisor.'); route(); } });
ACT['req-cancel'] = async el => { await post(`/api/my/requests/${el.dataset.id}/cancel`); toast('Request cancelled.'); route(); };

/* ---------- online sessions ---------- */
const phaseTag = s => s.phase === 'live' ? tag('present', 'Live now') : s.phase === 'upcoming' ? tag('pending', 'Coming up') : (s.seconds ? (s.attended ? tag('present', 'Attended') : tag('absent', 'Below minimum')) : tag('off', 'Ended'));

view('sessions', async (_a, v) => {
  const d = await api('/api/online');
  v.innerHTML = `<section class="sec"><h1>Online sessions</h1>
    <p class="lede">Remote duty, meetings and training. While you keep the session page open, your time is counted. You need at least the minimum share of the session.</p>
    ${d.sessions.length ? `<div class="list">${d.sessions.map(s => `<div class="item"><span class="t">${esc(s.title)}</span><span class="side">${phaseTag(s)}</span>
      <span class="m">${esc(L.kind[s.kind])}. ${esc(dateTime(s.starts_at))} to ${esc(hm(s.ends_at))}. Minimum ${s.min_pct}%.${s.seconds ? ` You were present ${s.pct}%.` : ''}</span>
      ${s.phase === 'live' ? `<div class="acts"><a class="btn sm" href="#/room/${s.id}">Join and track my time</a></div>` : ''}</div>`).join('')}</div>` : '<p class="empty">No sessions are planned for you.</p>'}</section>
    <div id="manage"></div>`;
  if (isManager() && CC.manageSessions) await CC.manageSessions($('#manage'));
}, {});

view('room', async (id, v) => {
  const d = await api('/api/online');
  const s = d.sessions.find(x => String(x.id) === id);
  if (!s) { v.innerHTML = '<section class="sec"><h1>Session not found</h1><a class="btn" href="#/sessions">Back</a></section>'; return; }
  const dur = s.ends_at - s.starts_at;
  v.innerHTML = `<section class="sec"><h1>${esc(s.title)}</h1><p class="lede">${esc(L.kind[s.kind])} until ${esc(hm(s.ends_at))}</p>
    ${s.join_url ? `<p><a class="btn ghost" href="${esc(s.join_url)}" target="_blank" rel="noopener noreferrer">Open the meeting link</a></p><p class="hint">Keep this page open too, in another window or tab. Your time is counted while this page is open.</p>` : ''}
    <div id="roomstate"></div><p class="err" id="roomerr" role="alert"></p></section>`;
  const paint = r => {
    $('#roomstate').innerHTML = `<p class="pct" style="font-size:54px">${r.pct}<sup>%</sup></p>
      <div class="progress"><i style="width:${r.pct}%"></i><b style="left:calc(${s.min_pct}% - 1.5px)"></b></div>
      <p>${hoursText(r.seconds)} counted of ${hoursText(dur)}. You need ${s.min_pct}%.</p>
      ${r.attended ? '<div class="note" style="border-left-color:#17794A">You have reached the minimum. You can stay for the rest of the session.</div>' : ''}`;
  };
  paint(s);
  if (s.phase !== 'live') { $('#roomerr').textContent = s.phase === 'upcoming' ? 'This session has not started yet.' : 'This session has ended.'; return; }
  let wake = null, stopped = false;
  const tick = async () => {
    if (stopped) return;
    try { paint(await post(`/api/online/${id}/beat`)); $('#roomerr').textContent = ''; }
    catch (e) { $('#roomerr').textContent = e.message; if (e.status === 409) stopped = true; }
  };
  try { if (navigator.wakeLock) wake = await navigator.wakeLock.request('screen'); } catch (e) { /* optional */ }
  tick();
  const iv = setInterval(tick, 30000), onVis = () => { if (document.visibilityState === 'visible') tick(); };
  document.addEventListener('visibilitychange', onVis);
  CC.cleanup.push(() => { stopped = true; clearInterval(iv); document.removeEventListener('visibilitychange', onVis); if (wake) wake.release().catch(() => {}); });
}, {});

/* ---------- account / more ---------- */
const phoneName = ua => (/Android/.test(ua) ? 'Android phone' : /iPhone|iPad/.test(ua) ? 'iPhone or iPad' : /Windows/.test(ua) ? 'Windows computer' : /Mac/.test(ua) ? 'Mac' : 'Phone or computer');

async function accountHtml() {
  const u = S.me.user;
  const dv = await api('/api/my/devices').catch(() => ({ devices: [] }));
  return `<section class="sec"><h2>Your details</h2><dl class="kv"><dt>Name</dt><dd>${esc(u.full_name)}</dd><dt>Username</dt><dd>${esc(u.username)}</dd>
      <dt>Role</dt><dd>${esc(L.role[u.role])}</dd>${u.org_name ? `<dt>Ministry or agency</dt><dd>${esc(u.org_name)}</dd>` : ''}${u.station_name ? `<dt>Office</dt><dd>${esc(u.station_name)}</dd>` : ''}${u.job_title ? `<dt>Job title</dt><dd>${esc(u.job_title)}</dd>` : ''}</dl>
      <div class="actions"><button class="btn ghost" data-act="pw">Change password</button><button class="btn ghost" data-act="logout">Sign out</button></div></section>
    ${u.role !== 'super_admin' ? `<section class="sec"><h2>Your phones</h2><p class="muted">Check-ins are tied to the phone you use. A new phone may need your supervisor's approval.</p>
      ${dv.devices.length ? `<div class="list">${dv.devices.map(d => `<div class="item"><span class="t">${esc(phoneName(d.label || ''))}</span><span class="side">${d.approved === 1 ? tag('approved', 'Approved') : d.approved === 0 ? tag('waiting', 'Waiting for approval') : tag('rejected', 'Removed')}</span><span class="m">First used ${esc(dateTime(d.first_seen))}</span></div>`).join('')}</div>` : '<p class="empty">No phone has been used yet.</p>'}
      <p class="hint">Tip: in your browser menu choose "Add to Home screen" to open ${esc(S.appName)} like an app.</p></section>` : ''}`;
}
view('account', async (_a, v) => { v.innerHTML = '<h1>Account</h1>' + await accountHtml(); }, {});
view('more', async (_a, v) => {
  const r = role(), links = [
    ['#/requests', 'Leave and corrections', 'Your own requests', r !== 'super_admin'],
    ['#/reports', 'Reports and downloads', 'Attendance summaries, payroll eligibility', true],
    ['#/sessions', 'Online sessions', 'Plan and review remote duty, meetings, training', r !== 'supervisor'],
    ['#/screen', 'Office screen', 'The rotating QR code for the reception screen', r !== 'supervisor'],
    ['#/holidays', 'Public holidays', 'Days that are not counted against attendance', r !== 'supervisor'],
    ['#/audit', 'Activity log', 'Who changed what, and when', isAdmin()],
    ['#/settings', 'National settings', 'The attendance minimum for all ministries', r === 'super_admin'],
  ].filter(l => l[3]);
  v.innerHTML = `<h1>More</h1><nav class="menu" aria-label="More">${links.map(l => `<a href="${l[0]}">${esc(l[1])}<small>${esc(l[2])}</small></a>`).join('')}</nav>` + await accountHtml();
}, {});
ACT.pw = () => modal({ title: 'Change password', submit: 'Save password', body:
  field('Current password', 'current', '', { type: 'password', req: true, ac: 'current-password' }) +
  field('New password', 'new', '', { type: 'password', req: true, ac: 'new-password', hint: 'At least 8 characters, with a letter and a number.' }) +
  field('New password again', 'again', '', { type: 'password', req: true, ac: 'new-password' }),
  onSubmit: async (f, v) => { if (v.new !== v.again) throw new Error('The two new passwords are different.'); await post('/api/password', { current: v.current, new: v.new }); toast('Password changed.'); } });

/* ---------- the office screen (shared by the sign-in-free link and the signed-in page) ---------- */
function runDisplay(root, load, embed) {
  let exp = 0, total = 300, alive = true, busy = false, retryAt = 0;
  root.innerHTML = `<div class="kiosk${embed ? ' embed' : ''}" id="kroot"><h1 class="kname" id="kn"></h1><p class="kdist" id="kd"></p><div class="frame" id="kf" role="img" aria-label="Check-in QR code"></div>
    <div class="kcode" id="kc" aria-label="Check-in code"></div><div class="kbar"><i id="kb"></i></div><p class="ktime" id="kt"></p>
    <p class="khelp" id="kh"></p><div id="kw"></div></div>`;
  $('#kh').textContent = `Scan with your phone camera, or open ${S.appName} and type the code.`;
  async function refresh() {
    if (!alive || busy) return;
    busy = true;
    try {
      const p = await load();
      $('#kn').textContent = p.station.name; $('#kd').textContent = p.station.district || '';
      $('#kf').innerHTML = p.svg; $('#kc').textContent = p.code.slice(0, 3) + ' ' + p.code.slice(3);
      total = p.interval; exp = Date.now() + p.expires_in * 1000; $('#kw').innerHTML = '';
    } catch (e) {
      retryAt = Date.now() + 5000;
      $('#kw').innerHTML = `<p class="kwarn">${esc(e.status === 404 ? e.message : 'No connection. The code on this screen may be out of date.')}</p>`;
      if (e.status === 404) alive = false;
    }
    busy = false;
  }
  function tick() {
    const left = Math.max(0, Math.round((exp - Date.now()) / 1000));
    $('#kt').textContent = exp ? 'Changes in ' + Math.floor(left / 60) + ':' + pad(left % 60) : '';
    $('#kb').style.width = exp ? Math.min(100, (left / total) * 100) + '%' : '0%';
    if (exp && left <= 0 && Date.now() >= retryAt) refresh();
  }
  refresh();
  const t1 = setInterval(tick, 1000), t2 = setInterval(refresh, 20000);
  CC.cleanup.push(() => { alive = false; clearInterval(t1); clearInterval(t2); });
}
function kioskPage() {
  document.body.className = 'kiosk-body';
  const key = new URLSearchParams(location.search).get('key') || '';
  runDisplay($('#app'), () => api('/api/display?key=' + encodeURIComponent(key)), false);
}
view('display', async (id, v) => {
  v.innerHTML = '<div class="between"><h1>Office screen</h1><button class="btn ghost sm" data-act="fullscreen">Full screen</button></div><p class="muted">Show this on the screen at reception. The code changes by itself.</p><div id="kslot"></div>';
  runDisplay($('#kslot'), () => api('/api/stations/' + encodeURIComponent(id) + '/code'), true);
}, { roles: ['supervisor', 'org_admin', 'super_admin'] });
ACT.fullscreen = () => { const el = $('#kroot'); if (el && el.requestFullscreen) el.requestFullscreen(); };

/* ---------- start ---------- */
CC.start = async () => {
  try { S.cfg = await api('/api/config'); S.offset = S.cfg.offset_min ?? 180; S.appName = S.cfg.app_name || S.appName; document.title = S.appName; } catch (e) { /* offline */ }
  if (location.pathname === '/display') return kioskPage();
  try { const d = await api('/api/me'); if (d.user) setMe(d); } catch (e) { /* offline */ }
  if (location.pathname.startsWith('/c/')) {
    S.token = decodeURIComponent(location.pathname.slice(3));
    history.replaceState(null, '', '/#/checkin');
  }
  window.addEventListener('hashchange', route);
  route();
};
document.addEventListener('DOMContentLoaded', () => CC.start());
})();
