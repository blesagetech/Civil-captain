"""Shared test fixtures: a fresh database, a frozen clock and two ministries with a few people."""
import os
import re
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import clock, create_app  # noqa: E402
from app.db import q1, run  # noqa: E402
from app.security import hash_password  # noqa: E402

PW = "Civil2026x"
ADMIN_PW = "Natl2026pass"
OFFSET = 180


def at(day, hhmm):
    """Local (Uganda) day + time -> epoch seconds."""
    return clock.to_ts(day, hhmm, OFFSET)


class Api:
    """A browser-like client: keeps the cookie and sends the CSRF header."""

    def __init__(self, app, **environ):
        self.c = app.test_client()
        self.csrf = ""
        self.environ = environ

    def login(self, username, password=PW):
        r = self.c.post("/api/login", json={"username": username, "password": password}, environ_overrides=self.environ)
        if r.status_code == 200:
            self.csrf = r.json["csrf"]
        return r

    def get(self, url, **kw):
        return self.c.get(url, environ_overrides=self.environ, **kw)

    def _send(self, method, url, json, headers=None):
        h = {"X-CSRF-Token": self.csrf, **(headers or {})}
        return getattr(self.c, method)(url, json={} if json is None else json, headers=h, environ_overrides=self.environ)

    def post(self, url, json=None, headers=None):
        return self._send("post", url, json, headers)

    def put(self, url, json=None):
        return self._send("put", url, json)

    def delete(self, url):
        return self._send("delete", url, None)


class World(unittest.TestCase):
    """Tuesday 13 Oct 2026, 08:05 in Kampala. Ministry A has a supervisor, two staff and an HR admin; Ministry B has two people."""
    NOW = ("2026-10-13", "08:05")
    CONFIG = {}

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()

    def setUp(self):
        clock.set_fake(at(*self.NOW))
        path = os.path.join(self.tmp, f"{self.id()}.db")
        self.app = create_app(DB_PATH=path, TESTING=True, ADMIN_USERNAME="admin", ADMIN_PASSWORD=ADMIN_PW, **self.CONFIG)
        with self.app.app_context():
            run("UPDATE users SET must_change_pw=0")
        self.admin = self.client("admin", ADMIN_PW)
        a = self.admin.post("/api/orgs", {"name": "Ministry A", "code": "MA"}).json["id"]
        b = self.admin.post("/api/orgs", {"name": "Ministry B", "code": "MB"}).json["id"]
        self.org_a, self.org_b = a, b
        self.st_a = self.admin.post("/api/stations", {"org_id": a, "name": "A Headquarters", "device_policy": "off"}).json["id"]
        self.st_b = self.admin.post("/api/stations", {"org_id": b, "name": "B Headquarters", "device_policy": "off"}).json["id"]
        self.hr = self.make("hr1", "Hanna HR", "org_admin", a, self.st_a)
        self.sup = self.make("sup1", "Sam Supervisor", "supervisor", a, self.st_a, supervisor=self.hr)
        self.e1 = self.make("emp1", "Ella Employee", "employee", a, self.st_a, supervisor=self.sup)
        self.e2 = self.make("emp2", "Eli Employee", "employee", a, self.st_a, supervisor=self.sup)
        self.supb = self.make("supb", "Bea Supervisor", "supervisor", b, self.st_b)
        self.empb = self.make("empb", "Ben Employee", "employee", b, self.st_b, supervisor=self.supb)

    def tearDown(self):
        clock.set_fake(None)

    # -- helpers
    def make(self, username, name, role, org, station, supervisor=None):
        r = self.admin.post("/api/users", {"username": username, "full_name": name, "role": role, "org_id": org,
                                           "station_id": station, "supervisor_id": supervisor, "start_date": "2026-09-01"})
        self.assertEqual(r.status_code, 201, r.json)
        with self.app.app_context():
            run("UPDATE users SET pw_hash=?, must_change_pw=0 WHERE id=?", (hash_password(PW), r.json["id"]))
        return r.json["id"]

    def client(self, username, password=PW, **environ):
        c = Api(self.app, **environ)
        r = c.login(username, password)
        self.assertEqual(r.status_code, 200, r.json)
        return c

    def token(self, station=None, who="sup1"):
        """The token currently shown on the station screen (read the way a supervisor's screen would)."""
        r = self.client(who).get(f"/api/stations/{station or self.st_a}/code")
        self.assertEqual(r.status_code, 200, r.json)
        return re.search(r"/c/(.+)$", r.json["url"]).group(1), r.json["code"]

    def station(self, **changes):
        """Change the main office's settings (full set sent, as the screen does)."""
        cur = {"name": "A Headquarters", "device_policy": "off"}
        cur.update(changes)
        r = self.admin.put(f"/api/stations/{self.st_a}", cur)
        self.assertEqual(r.status_code, 200, r.json)

    def db(self, sql, args=()):
        with self.app.app_context():
            return q1(sql, args)

    def month(self, client, month="2026-10"):
        return client.get(f"/api/my/month?month={month}").json["summary"]

    def day(self, client, day, month="2026-10"):
        return next(d for d in self.month(client, month)["days"] if d["day"] == day)

    def check_in(self, client, **extra):
        token, _ = self.token()
        return client.post("/api/checkin", {"token": token, **extra})
