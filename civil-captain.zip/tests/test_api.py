import os
import re
import unittest

from helpers import ADMIN_PW, PW, World, at  # noqa: E402  (helpers fixes sys.path)

from app import clock, codes  # noqa: E402
from app.db import q1, run  # noqa: E402

CIDR_NOT_ME = "10.1.0.0/16"
DEV_A, DEV_B = "device-aaaaaaaaaaaaaaaa", "device-bbbbbbbbbbbbbbbb"


class AuthTests(World):
    def test_wrong_password_and_lockout(self):
        c = self.app.test_client()
        for _ in range(5):
            self.assertEqual(c.post("/api/login", json={"username": "emp2", "password": "nope-nope-1"}).status_code, 401)
        r = c.post("/api/login", json={"username": "emp2", "password": PW})  # right password, but locked out
        self.assertEqual(r.status_code, 429)
        self.assertEqual(self.app.test_client().post("/api/login", json={"username": "emp1", "password": PW}).status_code, 200)

    def test_unauthenticated_and_csrf(self):
        self.assertEqual(self.app.test_client().get("/api/my/home").status_code, 401)
        c = self.client("emp1")
        r = c.c.post("/api/checkout", json={})  # no CSRF header
        self.assertEqual(r.status_code, 403)
        r = c.c.post("/api/checkout", data="x", headers={"X-CSRF-Token": c.csrf})  # not JSON
        self.assertEqual(r.status_code, 400)

    def test_forced_password_change(self):
        with self.app.app_context():
            run("UPDATE users SET must_change_pw=1 WHERE username='emp2'")
        c = self.client("emp2")
        self.assertTrue(c.get("/api/me").json["user"]["must_change_pw"])
        r = c.get("/api/my/home")
        self.assertEqual((r.status_code, r.json.get("must_change_pw")), (403, True))
        self.assertEqual(c.post("/api/password", {"current": "wrong-pass-1", "new": "Brand-new-2026"}).status_code, 403)
        self.assertEqual(c.post("/api/password", {"current": PW, "new": "short1"}).status_code, 400)
        self.assertEqual(c.post("/api/password", {"current": PW, "new": "allletters"}).status_code, 400)
        self.assertEqual(c.post("/api/password", {"current": PW, "new": "password123"}).status_code, 400)
        self.assertEqual(c.post("/api/password", {"current": PW, "new": "Brand-new-2026"}).status_code, 200)
        self.assertEqual(c.get("/api/my/home").status_code, 200)
        self.assertEqual(self.app.test_client().post("/api/login", json={"username": "emp2", "password": PW}).status_code, 401)

    def test_logout_and_deactivation_end_sessions(self):
        c = self.client("emp1")
        c.post("/api/logout")
        self.assertIsNone(c.get("/api/me").json["user"])
        c2 = self.client("emp2")
        r = self.admin.put(f"/api/users/{self.e2}", {"full_name": "Eli Employee", "active": False, "role": "employee",
                                                     "org_id": self.org_a, "station_id": self.st_a})
        self.assertEqual(r.status_code, 200, r.json)
        self.assertIsNone(c2.get("/api/me").json["user"])
        self.assertEqual(c2.get("/api/my/home").status_code, 401)
        self.assertEqual(self.app.test_client().post("/api/login", json={"username": "emp2", "password": PW}).status_code, 401)


class CheckInTests(World):
    def test_on_time_then_late_and_duplicate(self):
        e1, e2 = self.client("emp1"), self.client("emp2")
        r = self.check_in(e1)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual((r.json["record"]["status"], r.json["record"]["flags"], r.json["record"]["review"]), ("present", [], "ok"))
        again = self.check_in(e1)
        self.assertEqual((again.status_code, again.json.get("already")), (409, True))
        clock.set_fake(at("2026-10-13", "08:20"))
        r = self.check_in(e2)
        self.assertEqual(r.json["record"]["status"], "late")
        home = e1.get("/api/my/home").json
        self.assertEqual((home["today_status"], home["record"]["status"]), ("present", "present"))

    def test_typed_code(self):
        e1 = self.client("emp1")
        _, code = self.token()
        bad = e1.post("/api/checkin", {"code": "000000" if code != "000000" else "111111"})
        self.assertEqual(bad.status_code, 400)
        self.assertEqual(e1.post("/api/checkin", {"code": code}).status_code, 200)
        self.assertEqual(self.db("SELECT method FROM attendance WHERE user_id=?", (self.e1,))["method"], "code")

    def test_too_many_wrong_codes(self):
        e1 = self.client("emp1")
        for _ in range(8):
            self.assertEqual(e1.post("/api/checkin", {"code": "123456"}).status_code, 400)
        self.assertEqual(e1.post("/api/checkin", {"code": "123456"}).status_code, 429)

    def test_code_expiry_and_grace(self):
        token, code = self.token()
        e1 = self.client("emp1")
        clock.set_fake(at("2026-10-13", "08:09") + 59)  # last second of the window: still the same code
        self.assertEqual(e1.get(f"/api/checkin/preview?token={token}").json["valid"], True)
        clock.set_fake(at("2026-10-13", "08:10") + 10)  # just rotated: previous code survives a few seconds
        self.assertEqual(e1.get(f"/api/checkin/preview?token={token}").json["valid"], True)
        clock.set_fake(at("2026-10-13", "08:10") + 30)  # grace over
        p = e1.get(f"/api/checkin/preview?token={token}").json
        self.assertEqual((p["valid"], p["reason"]), (False, "expired"))
        r = e1.post("/api/checkin", {"token": token})
        self.assertEqual((r.status_code, r.json["reason"]), (400, "expired"))
        self.assertEqual(e1.post("/api/checkin", {"code": code}).status_code, 400)

    def test_tampered_and_foreign_tokens(self):
        token, _ = self.token()
        e1 = self.client("emp1")
        sid, win, sig = token.split(".")
        for bad in (f"{sid}.{int(win) + 1}.{sig}", f"{sid}.{win}.{'a' * 16}", "garbage", "9999.1.aaaaaaaaaaaaaaaa"):
            r = e1.post("/api/checkin", {"token": bad})
            self.assertEqual((r.status_code, r.json["reason"]), (400, "bad_code"), bad)
        other, _ = self.token(self.st_b, who="supb")
        r = e1.post("/api/checkin", {"token": other})
        self.assertEqual(r.status_code, 403)  # a code from another ministry's office

    def test_checkout(self):
        e1 = self.client("emp1")
        self.assertEqual(e1.post("/api/checkout").status_code, 409)  # not checked in yet
        self.check_in(e1)
        self.assertEqual(e1.post("/api/checkout").status_code, 409)  # too soon
        clock.set_fake(at("2026-10-13", "17:05"))
        r = e1.post("/api/checkout")
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(e1.post("/api/checkout").status_code, 409)
        self.assertEqual(self.day(e1, "2026-10-13")["status"], "present")
        self.assertGreater(self.month(e1)["hours"], 8.9)

    def test_unassigned_person_cannot_use_code(self):
        r = self.admin.post("/api/users", {"username": "nostation", "full_name": "No Station", "role": "employee", "org_id": self.org_a})
        with self.app.app_context():
            run("UPDATE users SET pw_hash=?, must_change_pw=0 WHERE id=?", (__import__("app.security", fromlist=["x"]).hash_password(PW), r.json["id"]))
        _, code = self.token()
        self.assertEqual(self.client("nostation").post("/api/checkin", {"code": code}).status_code, 409)


class PolicyTests(World):
    def test_network_rule_block_and_spoofing(self):
        self.station(ip_policy="block", allowed_cidrs=CIDR_NOT_ME)
        e1 = self.client("emp1")
        r = self.check_in(e1)
        self.assertEqual((r.status_code, r.json["reason"]), (403, "ip_outside"))
        r = e1.post("/api/checkin", {"token": self.token()[0]}, headers={"X-Forwarded-For": "10.1.2.3"})
        self.assertEqual(r.status_code, 403)  # header ignored unless the proxy setting is on
        self.station(ip_policy="block", allowed_cidrs="127.0.0.0/8")
        self.assertEqual(self.check_in(e1).status_code, 200)

    def test_network_rule_flag(self):
        self.station(ip_policy="flag", allowed_cidrs=CIDR_NOT_ME)
        r = self.check_in(self.client("emp1"))
        self.assertEqual((r.status_code, r.json["record"]["flags"], r.json["record"]["review"]), (200, ["ip_outside"], "pending"))

    def test_location_rule(self):
        self.station(geo_policy="block", lat=0.3136, lng=32.5811, radius_m=150)
        e1 = self.client("emp1")
        r = self.check_in(e1)
        self.assertEqual((r.status_code, r.json["reason"]), (403, "no_location"))
        r = self.check_in(e1, lat=0.3236, lng=32.5811, accuracy=20)
        self.assertEqual((r.status_code, r.json["reason"]), (403, "geo_outside"))
        self.assertIn("A Headquarters", r.json["error"])
        r = self.check_in(e1, lat=0.3140, lng=32.5812, accuracy=20)
        self.assertEqual(r.status_code, 200, r.json)
        row = self.db("SELECT lat, distance_m FROM attendance WHERE user_id=?", (self.e1,))
        self.assertTrue(0 < row["distance_m"] < 100 and row["lat"] is not None)

    def test_location_rule_flag_and_privacy(self):
        self.station(geo_policy="flag", lat=0.3136, lng=32.5811)
        r = self.check_in(self.client("emp1"), lat=0.40, lng=32.60, accuracy=10)
        self.assertEqual(r.json["record"]["flags"], ["geo_outside"])
        self.assertEqual(r.json["record"]["review"], "pending")
        r = self.check_in(self.client("emp2"))
        self.assertEqual(r.json["record"]["flags"], ["no_location"])
        # when the office does not use location checks, any location sent is thrown away
        self.station(geo_policy="off", lat=None, lng=None)
        clock.set_fake(at("2026-10-14", "08:05"))
        self.check_in(self.client("emp1"), lat=0.40, lng=32.60, accuracy=10)
        self.assertIsNone(self.db("SELECT lat FROM attendance WHERE user_id=? AND day='2026-10-14'", (self.e1,))["lat"])

    def test_phone_rule_flag_approve_and_shared(self):
        self.station(device_policy="flag")
        e1, e2, sup = self.client("emp1"), self.client("emp2"), self.client("sup1")
        r = self.check_in(e1, device_id=DEV_A)
        self.assertEqual(r.json["record"]["flags"], [])  # the first phone is trusted automatically
        r = self.check_in(e2, device_id=DEV_A)  # same phone, different person, same day
        self.assertEqual(r.json["record"]["flags"], ["shared_device"])
        clock.set_fake(at("2026-10-14", "08:05"))
        r = self.check_in(e1, device_id=DEV_B)
        self.assertEqual(r.json["record"]["flags"], ["new_device"])
        devices = sup.get("/api/review").json["devices"]
        self.assertEqual([d["full_name"] for d in devices], ["Ella Employee"])
        self.assertEqual(sup.post(f"/api/review/device/{devices[0]['id']}", {"decision": "approve"}).status_code, 200)
        clock.set_fake(at("2026-10-15", "08:05"))
        self.assertEqual(self.check_in(e1, device_id=DEV_B).json["record"]["flags"], [])

    def test_phone_rule_block(self):
        self.station(device_policy="block")
        e1, sup = self.client("emp1"), self.client("sup1")
        self.assertEqual(self.check_in(e1).status_code, 400)  # phone could not be identified
        self.assertEqual(self.check_in(e1, device_id=DEV_A).status_code, 200)
        clock.set_fake(at("2026-10-14", "08:05"))
        r = self.check_in(e1, device_id=DEV_B)
        self.assertEqual((r.status_code, r.json["reason"]), (403, "new_device"))
        dev = sup.get("/api/review").json["devices"][0]  # the blocked phone waits for the supervisor
        sup.post(f"/api/review/device/{dev['id']}", {"decision": "approve"})
        self.assertEqual(self.check_in(e1, device_id=DEV_B).status_code, 200)


class ProxyTests(World):
    CONFIG = {"TRUST_PROXY": True}

    def test_forwarded_address_is_used_when_behind_a_proxy(self):
        self.station(ip_policy="block", allowed_cidrs=CIDR_NOT_ME)
        e1 = self.client("emp1")
        ok = e1.post("/api/checkin", {"token": self.token()[0]}, headers={"X-Forwarded-For": "1.2.3.4, 10.1.2.3"})
        self.assertEqual(ok.status_code, 200, ok.json)  # the proxy's own entry is the last one
        e2 = self.client("emp2")
        spoof = e2.post("/api/checkin", {"token": self.token()[0]}, headers={"X-Forwarded-For": "10.1.2.3, 8.8.8.8"})
        self.assertEqual(spoof.status_code, 403)  # a self-declared address at the front is ignored


class ReviewAndRequestTests(World):
    def flagged_checkin(self):
        self.station(geo_policy="flag", lat=0.3136, lng=32.5811)
        e1 = self.client("emp1")
        self.check_in(e1, lat=0.40, lng=32.60, accuracy=10)
        return e1

    def test_reject_removes_credit_approve_keeps_it(self):
        e1, sup = self.flagged_checkin(), self.client("sup1")
        self.assertEqual(self.month(e1)["attended"], 1)  # counts while waiting for review
        item = sup.get("/api/review").json["flagged"][0]
        self.assertEqual((item["flags"], item["full_name"]), (["geo_outside"], "Ella Employee"))
        self.assertEqual(self.client("emp1").post(f"/api/review/attendance/{item['id']}", {"decision": "reject"}).status_code, 403)
        self.assertEqual(self.client("supb").post(f"/api/review/attendance/{item['id']}", {"decision": "reject"}).status_code, 404)
        self.assertEqual(sup.post(f"/api/review/attendance/{item['id']}", {"decision": "reject", "note": "Was in town"}).status_code, 200)
        self.assertEqual(self.day(e1, "2026-10-13")["status"], "rejected")
        self.assertEqual(self.month(e1)["attended"], 0)
        sup.post(f"/api/review/attendance/{item['id']}", {"decision": "approve"})
        self.assertEqual(self.day(e1, "2026-10-13")["status"], "present")
        self.assertEqual(sup.get("/api/review").json["flagged"], [])

    def test_leave_request_approval_and_scope(self):
        e1, sup = self.client("emp1"), self.client("sup1")
        body = {"kind": "leave", "leave_type": "annual", "start_day": "2026-10-14", "end_day": "2026-10-15", "reason": "Family"}
        before = self.month(e1)["expected"] + self.month(e1)["remaining"]
        rid = e1.post("/api/my/requests", body).json["id"]
        self.assertEqual(e1.post("/api/my/requests", {**body, "start_day": "2026-10-15", "end_day": "2026-10-16"}).status_code, 400)
        self.assertEqual(self.client("supb").post(f"/api/review/request/{rid}", {"decision": "approve"}).status_code, 404)
        self.assertEqual(e1.post(f"/api/review/request/{rid}", {"decision": "approve"}).status_code, 403)
        self.assertEqual(sup.post(f"/api/review/request/{rid}", {"decision": "approve"}).status_code, 200)
        self.assertEqual(sup.post(f"/api/review/request/{rid}", {"decision": "approve"}).status_code, 409)
        self.assertEqual(self.day(e1, "2026-10-14")["status"], "leave")
        m = self.month(e1)
        self.assertEqual(m["expected"] + m["remaining"], before - 2)  # leave days are not expected days
        # cancel a waiting request, but not a decided one
        r2 = e1.post("/api/my/requests", {**body, "start_day": "2026-10-20", "end_day": "2026-10-20"}).json["id"]
        self.assertEqual(e1.post(f"/api/my/requests/{r2}/cancel").status_code, 200)
        self.assertEqual(e1.post(f"/api/my/requests/{rid}/cancel").status_code, 409)
        self.assertEqual(e1.post("/api/my/requests", {**body, "end_day": "2026-10-01"}).status_code, 400)
        self.assertEqual(e1.post("/api/my/requests", {**body, "leave_type": "party"}).status_code, 400)

    def test_correction_creates_the_record(self):
        e1, sup = self.client("emp1"), self.client("sup1")
        body = {"kind": "correction", "start_day": "2026-10-12", "reason": "Phone battery died", "claim_in": "08:30", "claim_out": "17:00"}
        self.assertEqual(e1.post("/api/my/requests", {**body, "start_day": "2026-10-14"}).status_code, 400)  # future
        self.assertEqual(e1.post("/api/my/requests", {**body, "claim_in": ""}).status_code, 400)
        rid = e1.post("/api/my/requests", body).json["id"]
        self.assertEqual(self.day(e1, "2026-10-12")["status"], "absent")
        self.assertEqual(sup.post(f"/api/review/request/{rid}", {"decision": "approve"}).status_code, 200)
        d = self.day(e1, "2026-10-12")
        self.assertEqual((d["status"], d["method"], d["review"]), ("late", "correction", "approved"))
        self.assertIn("manual", d["flags"])
        self.assertEqual(e1.post("/api/my/requests", body).status_code, 400)  # the day is already complete

    def test_manual_entry_by_supervisor(self):
        sup = self.client("sup1")
        body = {"user_id": self.e2, "day": "2026-10-12", "check_in": "08:00", "check_out": "17:00", "note": "Office network was down"}
        self.assertEqual(self.client("emp1").post("/api/attendance/manual", body).status_code, 403)
        self.assertEqual(sup.post("/api/attendance/manual", {**body, "day": "2026-10-14"}).status_code, 400)
        self.assertEqual(sup.post("/api/attendance/manual", {**body, "day": "2026-08-31"}).status_code, 400)
        self.assertEqual(sup.post("/api/attendance/manual", {**body, "check_out": "07:00"}).status_code, 400)
        self.assertEqual(sup.post("/api/attendance/manual", {**body, "note": ""}).status_code, 400)
        self.assertEqual(sup.post("/api/attendance/manual", {**body, "user_id": self.empb}).status_code, 404)
        self.assertEqual(sup.post("/api/attendance/manual", body).status_code, 200)
        self.assertEqual(self.db("SELECT method FROM attendance WHERE user_id=?", (self.e2,))["method"], "manual")


class RoleTests(World):
    def test_who_can_see_whom(self):
        self.assertEqual(self.client("emp1").get("/api/team/today").status_code, 403)
        sup = self.client("sup1").get("/api/team/today").json
        self.assertEqual(sorted(r["full_name"] for r in sup["rows"]), ["Eli Employee", "Ella Employee"])
        hr = self.client("hr1").get("/api/team/today").json
        self.assertEqual(hr["total"], 4)  # org A: hr, sup, two staff; nobody from org B
        self.assertEqual(self.admin.get("/api/team/today").json["total"], 6)
        self.assertEqual(self.client("supb").get(f"/api/team/user/{self.e1}/month").status_code, 404)
        self.assertEqual(self.client("sup1").get(f"/api/team/user/{self.e1}/month").status_code, 200)
        self.assertEqual(self.client("emp1").get("/api/users").status_code, 403)
        self.assertEqual(self.client("sup1").get("/api/audit").status_code, 403)

    def test_org_admin_stays_inside_their_organisation(self):
        hr = self.client("hr1")
        self.assertEqual([s["name"] for s in hr.get("/api/stations").json["stations"]], ["A Headquarters"])
        self.assertEqual(hr.get("/api/orgs").json["orgs"][0]["name"], "Ministry A")
        self.assertEqual(hr.put(f"/api/users/{self.empb}", {"full_name": "Hacked", "role": "employee"}).status_code, 404)
        self.assertEqual(hr.post(f"/api/users/{self.empb}/reset-password").status_code, 404)
        self.assertEqual(hr.put(f"/api/stations/{self.st_b}", {"name": "x"}).status_code, 404)
        self.assertEqual(hr.post("/api/users", {"username": "root2", "full_name": "Root", "role": "super_admin"}).status_code, 400)
        self.assertEqual(hr.post("/api/orgs", {"name": "Ministry C", "code": "MC"}).status_code, 403)
        self.assertEqual(hr.post("/api/holidays", {"day": "2026-11-02", "name": "x"}).status_code, 403)
        self.assertEqual(hr.put("/api/settings", {"threshold_pct": 10, "session_min_pct": 10}).status_code, 403)
        # a new person created by HR always lands in HR's own organisation
        r = hr.post("/api/users", {"username": "newbie", "full_name": "New Person", "role": "employee", "org_id": self.org_b})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(self.db("SELECT org_id FROM users WHERE username='newbie'")["org_id"], self.org_a)

    def test_audit_is_scoped(self):
        hr = self.client("hr1")
        hr.post("/api/users", {"username": "newbie", "full_name": "New Person", "role": "employee"})
        mine = [e["action"] for e in hr.get("/api/audit").json["entries"]]
        self.assertIn("user_created", mine)
        everything = self.admin.get("/api/audit").json["entries"]
        self.assertGreater(len(everything), len(mine))


class AdminTests(World):
    def test_office_validation(self):
        base = {"name": "Field Office", "org_id": self.org_a}
        for bad in ({"geo_policy": "block"}, {"ip_policy": "flag"}, {"ip_policy": "block", "allowed_cidrs": "not-an-ip"},
                    {"work_start": "17:00", "work_end": "08:00"}, {"work_start": "25:00"}, {"lat": 1.0}, {"work_days": []},
                    {"qr_interval": 5}, {"name": "A Headquarters"}, {"geo_policy": "maybe"}):
            r = self.admin.post("/api/stations", {**base, **bad})
            self.assertEqual(r.status_code, 400, bad)
        ok = self.admin.post("/api/stations", {**base, "geo_policy": "flag", "lat": 0.5, "lng": 32.1, "ip_policy": "flag",
                                               "allowed_cidrs": "41.210.10.0/24, 2001:db8::/32", "work_days": "1,2,3,4,5,6"})
        self.assertEqual(ok.status_code, 201, ok.json)

    def test_rotating_the_key_locks_out_old_screens_and_codes(self):
        st = next(s for s in self.admin.get("/api/stations").json["stations"] if s["id"] == self.st_a)
        old_key = st["display_key"]
        anon = self.app.test_client()
        shown = anon.get(f"/api/display?key={old_key}").json
        token = re.search(r"/c/(.+)$", shown["url"]).group(1)
        self.assertEqual(shown["code"], self.token()[1])
        self.assertTrue(shown["svg"].startswith("<svg") and 0 < shown["expires_in"] <= 300)
        self.assertEqual(anon.get("/api/display?key=nope").status_code, 404)
        self.assertNotIn("display_key", self.client("sup1").get("/api/stations").json["stations"][0])  # only admins see keys
        self.assertEqual(self.admin.post(f"/api/stations/{self.st_a}/rotate-key").status_code, 200)
        self.assertEqual(anon.get(f"/api/display?key={old_key}").status_code, 404)
        r = self.client("emp1").post("/api/checkin", {"token": token})
        self.assertEqual((r.status_code, r.json["reason"]), (400, "bad_code"))

    def test_switching_an_office_off(self):
        self.station(active=False)
        self.assertEqual(self.client("sup1").get(f"/api/stations/{self.st_a}/code").status_code, 404)

    def test_people_management(self):
        hr = self.client("hr1")
        good = {"username": "new.person", "full_name": "New Person", "role": "employee", "station_id": self.st_a, "supervisor_id": self.sup}
        r = hr.post("/api/users", good)
        self.assertEqual(r.status_code, 201)
        temp = r.json["temp_password"]
        self.assertEqual(hr.post("/api/users", good).status_code, 400)  # duplicate
        for bad in ({"username": "has space"}, {"username": "ab"}, {"full_name": ""}, {"email": "nope"}, {"supervisor_id": self.empb},
                    {"station_id": self.st_b}, {"start_date": "31-12-2026"}, {"username": "x2.person", "supervisor_id": self.e1}):
            self.assertEqual(hr.post("/api/users", {**good, "username": "u" + os.urandom(3).hex(), **bad}).status_code, 400, bad)
        c = self.app.test_client()
        r = c.post("/api/login", json={"username": "new.person", "password": temp})
        self.assertTrue(r.json["user"]["must_change_pw"])
        r = hr.post(f"/api/users/{r.json['user']['id']}/reset-password")
        self.assertNotEqual(r.json["temp_password"], temp)
        self.assertEqual(self.app.test_client().post("/api/login", json={"username": "new.person", "password": temp}).status_code, 401)
        self.assertEqual(hr.put(f"/api/users/{self.hr}", {"full_name": "Hanna", "role": "employee"}).status_code, 400)  # own role
        self.assertEqual(hr.put(f"/api/users/{self.hr}", {"full_name": "Hanna", "role": "org_admin", "active": False}).status_code, 400)

    def test_csv_import(self):
        hr = self.client("hr1")
        csv_text = ("username,full_name,job_title,station,supervisor,role,start_date\n"
                    "imp.one,Import One,Clerk,A Headquarters,sup1,employee,2026-09-15\n"
                    "imp.two,Import Two,Clerk,Nowhere Office,sup1,employee,\n"
                    "emp1,Duplicate Person,Clerk,A Headquarters,sup1,employee,\n"
                    "imp.three,Import Three,Clerk,A Headquarters,ghost,employee,\n"
                    "imp.four,Import Four,,,,supervisor,\n")
        r = hr.post("/api/users/import", {"csv": csv_text}).json
        self.assertEqual([c["username"] for c in r["created"]], ["imp.one", "imp.four"])
        self.assertEqual([e["line"] for e in r["errors"]], [3, 4, 5])
        self.assertTrue(all(len(c["temp_password"]) == 10 for c in r["created"]))
        self.assertEqual(self.db("SELECT supervisor_id, start_date FROM users WHERE username='imp.one'")["supervisor_id"], self.sup)
        self.assertEqual(hr.post("/api/users/import", {"csv": "name\nx"}).status_code, 400)

    def test_holidays_and_threshold_change_the_maths(self):
        e1 = self.client("emp1")
        self.assertEqual(self.day(e1, "2026-10-12")["status"], "absent")
        self.assertEqual(self.admin.post("/api/holidays", {"day": "2026-10-12", "name": "Special holiday"}).status_code, 201)
        d = self.day(e1, "2026-10-12")
        self.assertEqual((d["status"], d["note"]), ("holiday", "Special holiday"))
        self.assertEqual(self.admin.delete("/api/holidays/2026-10-12").status_code, 200)
        self.assertEqual(self.month(e1)["threshold"], 75)
        self.assertEqual(self.admin.put("/api/settings", {"threshold_pct": 60, "session_min_pct": 70}).status_code, 200)
        self.assertEqual(self.month(e1)["threshold"], 60)
        self.assertEqual(self.admin.put("/api/settings", {"threshold_pct": 0, "session_min_pct": 70}).status_code, 400)
        self.assertEqual(self.admin.post("/api/holidays/seed", {"year": 2028}).status_code, 200)
        self.assertGreaterEqual(len(self.admin.get("/api/holidays?year=2028").json["holidays"]), 11)


class OnlineSessionTests(World):
    def create(self, **kw):
        body = {"title": "Staff meeting", "kind": "meeting", "day": "2026-10-13", "start": "08:00", "end": "09:00"}
        r = self.client("sup1").post("/api/admin/online", {**body, **kw})
        self.assertEqual(r.status_code, 201, r.json)
        return r.json["id"]

    def test_time_is_counted_only_while_pinging(self):
        sid = self.create()
        e1 = self.client("emp1")
        s = e1.get("/api/online").json["sessions"][0]
        self.assertEqual((s["phase"], s["attended"]), ("live", False))
        self.assertEqual(self.client("empb").post(f"/api/online/{sid}/beat").status_code, 404)  # other ministry
        clock.set_fake(at("2026-10-13", "07:50"))
        self.assertEqual(e1.post(f"/api/online/{sid}/beat").status_code, 409)  # not started
        clock.set_fake(at("2026-10-13", "08:05"))
        self.assertEqual(e1.post(f"/api/online/{sid}/beat").json["seconds"], 0)
        clock.set_fake(at("2026-10-13", "08:05") + 30)
        self.assertEqual(e1.post(f"/api/online/{sid}/beat").json["seconds"], 30)
        self.assertEqual(e1.post(f"/api/online/{sid}/beat").json["seconds"], 30)  # pinging faster earns nothing extra
        clock.set_fake(at("2026-10-13", "08:05") + 60)
        self.assertEqual(e1.post(f"/api/online/{sid}/beat").json["seconds"], 60)
        clock.set_fake(at("2026-10-13", "08:05") + 60 + 200)  # went quiet for over a minute: that gap is not counted
        r = e1.post(f"/api/online/{sid}/beat").json
        self.assertEqual((r["seconds"], r["attended"]), (60, False))
        for _ in range(48):  # then stays for the rest of the hour
            clock.set_fake(clock.now() + 60)
            r = e1.post(f"/api/online/{sid}/beat").json
        self.assertTrue(r["attended"], r)
        self.assertGreaterEqual(r["pct"], 75)
        clock.set_fake(at("2026-10-13", "09:02"))
        self.assertEqual(e1.post(f"/api/online/{sid}/beat").status_code, 409)  # over
        detail = self.client("sup1").get(f"/api/admin/online/{sid}").json
        self.assertEqual({p["full_name"]: p["attended"] for p in detail["people"]}["Ella Employee"], True)
        listing = self.client("sup1").get("/api/admin/online").json["sessions"][0]
        self.assertEqual((listing["joined"], listing["qualified"], listing["audience"]), (1, 1, 4))
        self.assertEqual(self.client("sup1").delete(f"/api/admin/online/{sid}").status_code, 409)  # people already joined

    def test_remote_duty_counts_as_a_day_present(self):
        e1 = self.client("emp1")
        self.assertEqual(self.day(e1, "2026-10-12")["status"], "absent")
        sid = self.create(kind="remote_duty", day="2026-10-12", start="08:00", end="17:00", title="Field duty")
        with self.app.app_context():
            run("INSERT INTO online_attendance(session_id,user_id,first_join,last_beat,seconds) VALUES (?,?,0,0,?)", (sid, self.e1, 8 * 3600))
            run("INSERT INTO online_attendance(session_id,user_id,first_join,last_beat,seconds) VALUES (?,?,0,0,?)", (sid, self.e2, 3 * 3600))
        self.assertEqual(self.day(e1, "2026-10-12")["status"], "remote")  # 8 of 9 hours
        self.assertEqual(self.day(self.client("emp2"), "2026-10-12")["status"], "absent")  # only 3 of 9 hours

    def test_session_rules(self):
        c = self.client("sup1")
        for bad in ({"end": "07:00"}, {"kind": "party"}, {"title": ""}, {"start": "8am"}, {"start": "01:00", "end": "20:00"},
                    {"join_url": "http://insecure.example"}, {"station_id": self.st_b}):
            self.assertEqual(c.post("/api/admin/online", {"title": "T", "kind": "meeting", "day": "2026-10-13", "start": "08:00",
                                                        "end": "09:00", **bad}).status_code, 400 if "station_id" not in bad else 404, bad)
        sid = self.create(join_url="https://meet.example.org/abc")
        self.assertEqual(self.client("emp1").post("/api/admin/online", {}).status_code, 403)
        self.assertEqual(self.client("supb").get(f"/api/admin/online/{sid}").status_code, 404)
        self.assertEqual(self.client("emp1").get("/api/online").json["sessions"][0]["join_url"], "https://meet.example.org/abc")


class ReportTests(World):
    def test_csv_exports(self):
        self.admin.put(f"/api/users/{self.e1}", {"full_name": "=HYPERLINK(\"http://evil\")", "role": "employee",
                                                 "org_id": self.org_a, "station_id": self.st_a, "supervisor_id": self.sup})
        sup = self.client("sup1")
        r = sup.get("/api/reports/summary.csv?from=2026-10-01&to=2026-10-13")
        self.assertEqual(r.status_code, 200)
        text = r.data.decode("utf-8")
        self.assertTrue(text.startswith("\ufeffOrganisation"))
        self.assertIn("'=HYPERLINK", text)  # spreadsheet formulas are defused
        self.assertIn("Eli Employee", text)
        self.assertNotIn("Ben Employee", text)  # other ministry
        self.assertIn("attachment", r.headers["Content-Disposition"])
        elig = sup.get("/api/reports/eligibility.csv?month=2026-10").data.decode("utf-8")
        self.assertIn("Below minimum - refer to HR", elig)
        self.assertIn("No (month still open)", elig)
        self.assertEqual(sup.get("/api/reports/records.csv?from=2026-10-01&to=2026-10-13").status_code, 200)
        self.assertEqual(self.client("emp1").get("/api/reports/summary.csv").status_code, 403)
        self.assertEqual(sup.get("/api/reports/summary.csv?from=2026-10-13&to=2026-10-01").status_code, 400)
        self.assertEqual(sup.get("/api/reports/eligibility.csv?month=oct").status_code, 400)

    def test_periods_come_from_the_server_calendar(self):
        sup = self.client("sup1")
        this = sup.get("/api/team/summary?preset=this").json
        self.assertEqual((this["from"], this["to"]), ("2026-10-01", "2026-10-13"))
        last = sup.get("/api/team/summary?preset=last").json
        self.assertEqual((last["from"], last["to"]), ("2026-09-01", "2026-09-30"))
        self.assertEqual(sup.get("/api/reports/summary.csv?preset=last").status_code, 200)

    def test_summary_and_today_numbers(self):
        self.check_in(self.client("emp1"))
        sup = self.client("sup1")
        today = sup.get("/api/team/today").json
        self.assertEqual((today["counts"]["present"], today["counts"]["pending"]), (1, 1))
        s = sup.get("/api/team/summary?from=2026-10-01&to=2026-10-13").json
        by = {r["full_name"]: r for r in s["rows"]}
        self.assertEqual(by["Ella Employee"]["attended"], 1)
        self.assertEqual(by["Ella Employee"]["expected"], 8)  # 1, 2, 5, 6, 7, 8, 12 Oct and today
        self.assertEqual(by["Eli Employee"]["attended"], 0)
        self.assertEqual(s["threshold"], 75)


class SiteTests(World):
    def test_headers_pages_and_files(self):
        c = self.app.test_client()
        r = c.get("/healthz")
        self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")
        self.assertEqual(c.get("/api/config").headers["Cache-Control"], "no-store")
        self.assertEqual(c.get("/api/nothing-here").status_code, 404)
        for path in ("/app/config.py", "/data/civilcaptain.db", "/..%2fapp%2fconfig.py", "/static/../run.py", "/tests/helpers.py"):
            self.assertEqual(c.get(path).status_code, 404, path)
        if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "index.html")):
            for path in ("/", "/display", "/c/12.34.abcdefghijklmnop"):
                r = c.get(path)
                self.assertEqual(r.status_code, 200, path)
                self.assertIn(b"<html", r.data.lower())
                r.close()
            self.assertEqual(c.get("/app.js").status_code, 200)

    def test_first_run_creates_only_an_admin_when_not_demo(self):
        with self.app.app_context():
            self.assertEqual(q1("SELECT COUNT(*) AS c FROM users WHERE role='super_admin'")["c"], 1)
        self.assertEqual(self.app.test_client().get("/api/config").json["demo"], False)
        self.assertNotIn("demo_password", self.app.test_client().get("/api/config").json)


if __name__ == "__main__":
    unittest.main()
