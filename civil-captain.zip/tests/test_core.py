import os
import random
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import calc, qrmatrix  # noqa: E402


class QrTests(unittest.TestCase):
    def test_tables_and_constants(self):
        totals = {1: 26, 2: 44, 3: 70, 4: 100, 5: 134, 6: 172, 7: 196, 8: 242, 9: 292, 10: 346}
        for level in "LMQH":
            for v in range(1, 11):
                ec, groups = qrmatrix._BLOCKS[level][v]
                self.assertEqual(sum(n * (d + ec) for n, d in groups), totals[v], (level, v))
        self.assertEqual(qrmatrix._format_bits("M", 0), 0b101010000010010)
        self.assertEqual(qrmatrix._format_bits("L", 0), 0b111011111000100)
        self.assertEqual(qrmatrix._version_bits(7), 0b000111110010010100)

    def test_decodes_with_a_real_reader(self):
        try:
            import cv2
            import numpy as np
        except ImportError:
            self.skipTest("OpenCV not installed")
        det = cv2.QRCodeDetector()

        def readable(m, text):
            n = len(m)
            for scale, border in ((8, 6), (6, 6), (10, 4), (8, 4), (12, 6), (5, 4)):  # detector is picky about framing
                img = np.full(((n + 2 * border) * scale,) * 2, 255, np.uint8)
                for y in range(n):
                    for x in range(n):
                        if m[y][x]:
                            img[(y + border) * scale:(y + border + 1) * scale, (x + border) * scale:(x + border + 1) * scale] = 0
                if det.detectAndDecode(img)[0] == text:
                    return True
            return False

        rnd = random.Random(7)
        alphabet = "abcdefghijklmnopqrstuvwxyz0123456789./:-_"
        versions = set()
        for level in "LMQH":
            for length in (5, 20, 45, 80, 130, 200):
                text = "".join(rnd.choice(alphabet) for _ in range(length))
                try:
                    m = qrmatrix.encode(text, level)
                except ValueError:
                    continue
                versions.add((len(m) - 17) // 4)
                self.assertTrue(readable(m, text), (level, length))
        self.assertGreaterEqual(len(versions), 8)
        url = "https://civil-captain-demo-8000.app.github.dev/c/12.5896422.k3j2n4m5p6q7r8s9"
        self.assertTrue(readable(qrmatrix.encode(url), url))

    def test_too_long_is_rejected_and_svg_is_valid(self):
        with self.assertRaises(ValueError):
            qrmatrix.encode("x" * 400)
        svg = qrmatrix.to_svg(qrmatrix.encode("hello"))
        self.assertTrue(svg.startswith("<svg") and svg.endswith("</svg>") and "<path" in svg)


def ctx(**kw):
    base = dict(start="2026-10-01", end="2026-10-31", today="2026-10-31", now_min=18 * 60, hire="2026-01-01",
                work_days={1, 2, 3, 4, 5}, work_end_min=17 * 60, att={}, leave=set(), holidays={}, remote=set(), threshold=75)
    base.update(kw)
    return base


def row(status="present", review="ok", out=True):
    return {"status": status, "review": review, "check_in": 1, "check_out": 2 if out else None, "flags": "", "method": "qr", "id": 1}


class CalcTests(unittest.TestCase):
    def test_easter_and_holidays(self):
        self.assertEqual(calc.easter(2026).isoformat(), "2026-04-05")
        self.assertEqual(calc.easter(2027).isoformat(), "2027-03-28")
        self.assertEqual(calc.easter(2025).isoformat(), "2025-04-20")
        h = calc.uganda_holidays(2026)
        self.assertEqual(h["2026-04-03"], "Good Friday")
        self.assertEqual(h["2026-04-06"], "Easter Monday")
        self.assertEqual(h["2026-10-09"], "Independence Day")

    def test_percentage_and_threshold_boundary(self):
        working = [d for d in calc.days("2026-10-01", "2026-10-30") if calc.parse(d).isoweekday() <= 5]  # 22 days
        self.assertEqual(len(working), 22)
        # 75% of 20 days = exactly 15 -> meets the minimum; 14 does not
        two_weeks = working[:20]
        ok = calc.compute(**ctx(end="2026-10-28", today="2026-10-28", att={d: row() for d in two_weeks[:15]}))
        self.assertEqual((ok["attended"], ok["expected"], ok["status"]), (15, 20, "ok"))
        low = calc.compute(**ctx(end="2026-10-28", today="2026-10-28", att={d: row() for d in two_weeks[:14]}))
        self.assertEqual((low["attended"], low["status"], low["pct"]), (14, "below", 70.0))

    def test_exclusions_holiday_leave_weekend_and_hire_date(self):
        att = {"2026-10-01": row()}
        r = calc.compute(**ctx(end="2026-10-09", today="2026-10-09", att=att, holidays={"2026-10-09": "Independence Day"},
                               leave={"2026-10-07", "2026-10-08"}, hire="2026-10-02"))
        by = {d["day"]: d["status"] for d in r["days"]}
        self.assertEqual(by["2026-10-01"], "before")  # before the start date: never counted
        self.assertEqual(by["2026-10-03"], "off")
        self.assertEqual(by["2026-10-07"], "leave")
        self.assertEqual(by["2026-10-09"], "holiday")
        self.assertEqual(r["expected"], 3)  # 2, 5, 6 Oct: absent every one of them
        self.assertEqual(r["attended"], 0)

    def test_today_is_pending_until_work_ends_then_absent(self):
        r = calc.compute(**ctx(start="2026-10-13", end="2026-10-13", today="2026-10-13", now_min=10 * 60))
        self.assertEqual((r["days"][0]["status"], r["expected"], r["remaining"]), ("pending", 0, 1))
        r = calc.compute(**ctx(start="2026-10-13", end="2026-10-13", today="2026-10-13", now_min=18 * 60))
        self.assertEqual((r["days"][0]["status"], r["expected"]), ("absent", 1))
        r = calc.compute(**ctx(start="2026-10-13", end="2026-10-13", today="2026-10-13", now_min=10 * 60,
                               att={"2026-10-13": row(out=False)}))
        self.assertEqual((r["attended"], r["expected"]), (1, 1))

    def test_rejected_remote_and_late(self):
        att = {"2026-10-01": row("late"), "2026-10-02": row(review="rejected"), "2026-10-05": row(review="pending")}
        r = calc.compute(**ctx(end="2026-10-05", today="2026-10-05", now_min=18 * 60, att=att, remote={"2026-10-06"}))
        by = {d["day"]: d["status"] for d in r["days"]}
        self.assertEqual((by["2026-10-01"], by["2026-10-02"], by["2026-10-05"]), ("late", "rejected", "present"))
        self.assertEqual((r["attended"], r["late"], r["flagged"]), (2, 1, 1))
        r = calc.compute(**ctx(end="2026-10-06", today="2026-10-06", att=att, remote={"2026-10-06"}))
        self.assertEqual({d["day"]: d["status"] for d in r["days"]}["2026-10-06"], "remote")

    def test_outlook_what_you_still_need(self):
        # 21 working days in the month, so 16 attended days are needed. 6 attended so far with 15 days to go.
        att = {d: row() for d in ("2026-10-01", "2026-10-02", "2026-10-05", "2026-10-06", "2026-10-07", "2026-10-08")}
        r = calc.compute(**ctx(today="2026-10-08", now_min=18 * 60, att=att, holidays={"2026-10-09": "Independence Day"}))
        self.assertEqual((r["attended"], r["remaining"], r["need_more"], r["outlook"]), (6, 15, 10, "achievable"))
        r = calc.compute(**ctx(today="2026-10-30", att={d: row() for d in list(att)[:2]}, holidays={"2026-10-09": "x"}))
        self.assertEqual(r["outlook"], "lost")
        full = {d: row() for d in calc.days("2026-10-01", "2026-10-30") if calc.parse(d).isoweekday() <= 5}
        r = calc.compute(**ctx(today="2026-10-30", att=full))
        self.assertEqual((r["pct"], r["outlook"]), (100.0, "secured"))

    def test_nothing_expected(self):
        r = calc.compute(**ctx(start="2026-10-03", end="2026-10-04", today="2026-10-31"))
        self.assertEqual((r["status"], r["pct"], r["outlook"]), ("na", None, "na"))


if __name__ == "__main__":
    unittest.main()
